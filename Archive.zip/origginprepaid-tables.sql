SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `account_verifications` (
  `verify_id` int(11) NOT NULL,
  `verify_customer` int(11) NOT NULL,
  `verify_contact` varchar(30) NOT NULL,
  `is_verified` tinyint(4) DEFAULT '0',
  `is_expired` tinyint(4) DEFAULT '0',
  `verify_code` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `blocked_lists` (
  `block_id` int(11) NOT NULL,
  `blocked_customer` int(11) NOT NULL,
  `blocked_contact` varchar(30) NOT NULL,
  `block_status` tinyint(4) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `type_id` int(11) NOT NULL DEFAULT '1',
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-',
  `phone` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `phone_alt` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `user_type_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `customer_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `block_exception` tinyint(1) NOT NULL DEFAULT '0',
  `account_verified` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `denied_requests` (
  `id` int(10) UNSIGNED NOT NULL,
  `type_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `meter_code` varchar(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `amount` decimal(9,2) NOT NULL DEFAULT '0.00',
  `location` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `meter_owner` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `reject_reason` varchar(50) NOT NULL DEFAULT '',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `districts` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `ecg_region_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:10',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `ecg_regions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `region_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:09',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `ecg_regions` (`id`, `name`, `description`, `region_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Accra', 'Greater Accra', 1, NULL, '2018-01-03 23:53:00', '2018-08-03 16:53:59');

CREATE TABLE `ecg_statuses` (
  `id` int(10) UNSIGNED NOT NULL,
  `status` tinyint(1) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:02',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `locations` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `region_id` int(10) UNSIGNED NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `locations` (`id`, `name`, `description`, `region_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Osu', 'Osu Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(2, 'Ridge', 'Ridge, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(3, 'New Town', 'Accra New Town', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(4, 'Achimota', 'Achimota, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(5, 'East Legon', 'East Legon, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(6, 'West Legon', 'West Legon, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(7, 'North Legon', 'North Legon, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(8, 'Dodowa', 'Dodowa, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(9, 'Prampram', 'Prampram, Tema', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(10, 'Madina', 'Madina, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(11, 'Oyarifa', 'Oyarifa, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(12, 'Airport Residential Area', 'Airport Residential Area, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(13, 'Ashaley Botwey', 'Ashaley Botwey, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(14, 'Adenta', 'Adenta, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(15, 'Dowenhya', 'Dowenhya, Tema', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(16, 'Kpone', 'Kpone, Tema', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(17, 'Dzorwulu', 'Dzorwulu, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(18, 'Kwabenya', 'Kwabenya, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(19, 'Community 25', ' Tema Community 25', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(20, 'Abokobi', 'Abokobi, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(21, 'Ashongman', 'Ashongman Estate, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(22, 'Ogbojo', 'Ogbojo, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(23, 'Abelenkpe', 'Abelenkpe, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(24, 'Ebony junction', 'Ebony junction, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(25, 'Kokomlemle', 'Kokomlemle, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(26, 'Menpeasem', 'Menpeasem, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(27, 'Okponglo', 'Okponglo, Legon', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(28, 'Amanhia', 'Amanhia, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(29, 'Old Ningo', 'Old Ningo, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(30, 'Paraku', 'Paraku Estate, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(31, 'Katamanso', 'Katamanso, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(32, 'Otinshie', 'Otinshie, Accra', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(33, 'Team', 'Team Community', 1, NULL, '2018-01-10 16:11:00', '2018-08-07 08:26:00'),
(34, 'Agbogba', 'Agbogba, Accra', 0, NULL, '2018-01-10 16:11:00', '2018-09-10 13:29:53'),
(35, 'Agbogba', 'Agbogba, Accra', 1, NULL, '2018-01-10 20:30:00', '2018-09-10 13:30:48');

CREATE TABLE `momo_transations` (
  `id` int(10) UNSIGNED NOT NULL,
  `amount` decimal(9,2) DEFAULT '0.00',
  `pay_number` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `charges` decimal(9,2) DEFAULT '0.00',
  `ecg_amount` decimal(9,2) DEFAULT '0.00',
  `origgin_charge` decimal(9,2) DEFAULT '0.00',
  `amount_after_charges` decimal(9,2) DEFAULT '0.00',
  `transaction_id` varchar(124) COLLATE utf8_unicode_ci NOT NULL,
  `response_code` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `client_refrence` varchar(124) COLLATE utf8_unicode_ci NOT NULL,
  `external_transaction_id` varchar(124) COLLATE utf8_unicode_ci NOT NULL,
  `requst_id` int(10) UNSIGNED NOT NULL,
  `is_sold` tinyint(1) NOT NULL,
  `sold_at` datetime NOT NULL,
  `is_refunded` tinyint(1) NOT NULL DEFAULT '0',
  `refunded_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:07',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `payment_type` int(11) NOT NULL DEFAULT '1',
  `network` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'mtn'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `password_ressets` (
  `resset_id` int(11) NOT NULL,
  `resset_customer` int(11) NOT NULL,
  `resset_contact` varchar(30) NOT NULL,
  `resset_token` varchar(240) NOT NULL,
  `is_resset` tinyint(4) DEFAULT '0',
  `is_verified` tinyint(4) DEFAULT '0',
  `verify_code` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `payment_types` (
  `payment_id` int(11) NOT NULL,
  `payment_name` varchar(50) NOT NULL,
  `provider` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `payment_verifications` (
  `verify_id` int(11) NOT NULL,
  `verify_customer` int(11) NOT NULL,
  `verify_contact` varchar(30) NOT NULL,
  `is_verified` tinyint(4) DEFAULT '0',
  `is_expired` tinyint(4) DEFAULT '0',
  `verify_code` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `regions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:01',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `regions` (`id`, `name`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Accra', 'Greater Accra', NULL, '2018-08-07 04:58:00', '2018-08-06 21:59:53');

CREATE TABLE `requsts` (
  `id` int(10) UNSIGNED NOT NULL,
  `request_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `meter_code` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `amount` decimal(9,2) NOT NULL DEFAULT '0.00',
  `location` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `meter_owner` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `location_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `customer_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `is_confirmed` tinyint(1) NOT NULL,
  `confirmed_at` datetime NOT NULL,
  `is_rejected` tinyint(1) NOT NULL,
  `rejected_at` datetime NOT NULL,
  `is_paid` tinyint(1) NOT NULL,
  `paid_at` datetime NOT NULL,
  `is_sold` tinyint(1) NOT NULL,
  `sold_at` datetime NOT NULL,
  `sold_by_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `vendor_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:02',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `partner` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `towns` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `type_id` int(11) NOT NULL,
  `username` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `user_type_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `balance` double NOT NULL DEFAULT '0',
  `recustomer_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `user_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2017-08-28 15:07:31',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `vendors` (
  `id` int(10) UNSIGNED NOT NULL,
  `ecg_region_id` int(11) NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `telephone_alt` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `balance` double NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2017-08-28 15:07:37',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `vendors` (`id`, `ecg_region_id`, `name`, `address`, `telephone`, `telephone_alt`, `email`, `balance`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'East Legon Woman', 'American House, East Legon, Accra', '0502369854', '0244715689', 'vendor1@gmail.com', 0, NULL, '2017-08-28 15:07:47', '2017-08-28 15:07:47');


ALTER TABLE `account_verifications`
  ADD PRIMARY KEY (`verify_id`),
  ADD KEY `verify_customer` (`verify_customer`);

ALTER TABLE `blocked_lists`
  ADD PRIMARY KEY (`block_id`),
  ADD KEY `blocked_customer` (`blocked_customer`);

ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customers_email_unique` (`email`),
  ADD KEY `customers_user_type_id_index` (`user_type_id`);

ALTER TABLE `denied_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`);

ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `districts_ecg_region_id_index` (`ecg_region_id`);

ALTER TABLE `ecg_regions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ecg_regions_region_id_index` (`region_id`);

ALTER TABLE `ecg_statuses`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `locations_region_id_index` (`region_id`);

ALTER TABLE `momo_transations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `momo_transations_transaction_id_unique` (`transaction_id`),
  ADD KEY `momo_transations_requst_id_index` (`requst_id`);

ALTER TABLE `password_ressets`
  ADD PRIMARY KEY (`resset_id`),
  ADD KEY `resset_customer` (`resset_customer`);

ALTER TABLE `payment_types`
  ADD PRIMARY KEY (`payment_id`);

ALTER TABLE `payment_verifications`
  ADD PRIMARY KEY (`verify_id`),
  ADD KEY `verify_customer` (`verify_customer`);

ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `requsts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requsts_type_id_index` (`type_id`),
  ADD KEY `requsts_location_id_index` (`location_id`),
  ADD KEY `requsts_customer_id_index` (`customer_id`),
  ADD KEY `requsts_sold_by_id_index` (`sold_by_id`),
  ADD KEY `requsts_vendor_id_index` (`vendor_id`);

ALTER TABLE `towns`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_user_type_id_index` (`user_type_id`);

ALTER TABLE `user_types`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vendors_name_unique` (`name`);


ALTER TABLE `account_verifications`
  MODIFY `verify_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=322;

ALTER TABLE `blocked_lists`
  MODIFY `block_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=635;

ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3109;

ALTER TABLE `denied_requests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2886;

ALTER TABLE `districts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `ecg_regions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `ecg_statuses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=240;

ALTER TABLE `locations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

ALTER TABLE `momo_transations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55913;

ALTER TABLE `password_ressets`
  MODIFY `resset_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

ALTER TABLE `payment_types`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `payment_verifications`
  MODIFY `verify_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=164;

ALTER TABLE `regions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `requsts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66513;

ALTER TABLE `towns`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

ALTER TABLE `user_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `vendors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
