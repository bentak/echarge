<?php

/**
 * Description of MoMo Payment process
 *
 * @author Kwarteng
 */

const MAZZUMA_API_KEY = "419c1abdbbaa83cf2b21f15563f24edabc7f40a9";

$MazzumaRequestOptions = array(
        'price'=>'',
        'network'=>'',
        'recipient_number'=>'0245612176',
        'sender'=>'',
        'option'=>'',
        'apikey'=>'',        
        'orderID'=>''        
        );

/**
 * This is the entry point for payment API call from app.
 * @referenceid is a unique request id which is generated when 
 * user makes request to buy credit
 * @return JSON
 */
function CompletePayment($referenceid) { 
            
            $data = Input::all(); //this line gets all the post variables;
            
            
            $validator = Validator::make($data, $payment_rules); //checks if all data required are suplied
            
            if ($validator->fails())
            {
                return json_encode(array('success'=>'no','status'=>400,'errors'=>$validator->messages()));
            }
            
            //retrieves particular request from database by the $referenceid passed
            $request = Request::where('request_id',$referenceid)->first();
            
            if($request != NULL) {                
                
                $pay_exists = $this->PaymentExists($referenceid); //checks if transaction exists on Mazzuma with order id
                    
                if($pay_exists['exists'] == TRUE && $pay_exists['status']=='Successful') {
                    
                        //return success response
                        return json_encode(array(
                         'success'=>'yes',                    
                         'status'=>200,
                         'message'=> 'Payment successful.'
                     ));

                    } else if($pay_exists['exists'] == TRUE && $pay_exists['status']=='Pending') {

                        return json_encode(array(
                             'success'=>'no',
                             'status'=>300,
                             'message'=> 'Payment pending.'
                                 ));
                    }
               
            // get the appropriate network option for the user selected network
              $option= $this->getNetworkOption();
              
              
              //this creates an invoice to be sent to mazzuma.
              $invoice = array (
                  'sender'=> $data['mm_number'],
                  'network'=>$data['mm_network'],
                  'option'=>$option,
                  'price'=>$request->amount,
                  'id'=>$referenceid
                  );
              
              //process the invoice and populate request payload with 
              //appropriate values. returns an array
            $payment_response = processMazzumaPayment($invoice);           
           
            
            if(strlen($payment_response['error'])>0) { //check if the error value of the response is not empty
                return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=>$payment_response['error']
                                    )
                                    );
            } else if(is_object($payment_response['data']) || strlen($payment_response['data'])>0){ //check if data value is not empty
                
                return $this->CheckAndSendResponse($payment_response, $request, 'MazzumaCallback');
                
            } else { //this is called when "data" value of response is empty.                
               
                $pay_status = $this->CheckPaymentStatus($request->request_id);
                    
                   if($pay_status['status'] == TRUE) {
                       
                       
                       return json_encode(array(
                        'success'=>'yes',                    
                        'status'=>200,
                        'message'=> 'Payment successful.'
                    ));
                       
                   } else {
                       
                      return  json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=> 'Payment Unapproved.'
                                ));
                   } 
            }
              
              
            } else {
                
                return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=> 'Invalid request token.'
                                    ));
                
            }
                        
                
        } 

        /**
        * This function is called to check from mazzuma if transaction
         * with the particular order Id exists.
        * @referenceid is the request id
        * @return array
        */
        function PaymentExists($referenceid) {
                  
            // check if payment is successfull
            $paid_response = CheckMazzumaPaymentStatus($referenceid);
            
            if(strlen($paid_response['data'])>0){
                
                $paid = json_decode($paid_response['data']);

                return property_exists($paid, 'id')? 
                        array('exists'=>TRUE,'status'=>$paid->status):
                        array('exists'=>FALSE,'message'=>$paid->message);
                
            }            
                    
        }
        
        /**
        * This function returns the appropriate network option
         * to be sent with payload based on network user selected.
        * @referenceid is the request id
        * @return array
        */
        function getNetworkOption() {
            $option = '';
            
            switch (Input::get('mm_network')){
                case 'airtel': 
                    $option = 'ratm';                  
                    break;
                case 'voda': 
                    $option = 'rvtm';                  
                    break;
                case 'tigo': 
                    $option = 'rttm';                  
                    break;
                default :
                    $option = 'rmtm';
                    break;
              }
              
              return $option;
        }
        
        
        function processMazzumaPayment($invoice) {
            
            $price_less_charges = doubleval($invoice['price']) - (0.03*doubleval($invoice['price']));
        
            $MazzumaRequestOptions['sender'] = $invoice['sender'];
            
            $MazzumaRequestOptions['network'] = $invoice['network'];
           
            $MazzumaRequestOptions['option'] = $invoice['option'];
            
            $MazzumaRequestOptions['price'] = $price_less_charges;           
                        
            $MazzumaRequestOptions['apikey'] = self::MAZZUMA_API_KEY;
            
            $MazzumaRequestOptions['orderID'] = $invoice['id'];
            
            
            //send request
            $response = sendMazzumaRequest();
            
            return $response;
            
        }
        
        
        function sendMazzumaRequest() {
            
            $request_url = "https://client.teamcyst.com/api_call.php";
       
            $curl = curl_init($request_url);
            
            curl_setopt( $curl, CURLOPT_CUSTOMREQUEST, "POST" );  
            curl_setopt( $curl, CURLOPT_POSTFIELDS, json_encode(self::$MazzumaRequestOptions) );  
            curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
            curl_setopt( $curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
              ));

       
        curl_setopt($curl, CURLOPT_CAINFO, $_SERVER['DOCUMENT_ROOT'] ."/cacert.pem");
        //Execute the request.
        $results = curl_exec($curl);
        
        $error = curl_error($curl);

        //Close the cURL handle.
        curl_close($curl);
        
        return array('data'=>$results,'error'=>$error);
    }
    
    
    function CheckMazzumaPaymentStatus($paymentid) {           
            
            
            $request_url = "https://client.teamcyst.com/checktransaction.php?orderID=$paymentid";
       
            $curl = curl_init($request_url);            
           
            curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
            curl_setopt( $curl, CURLOPT_HTTPHEADER, array(                
                'Cache-Control: no-cache',
                'Content-Type: application/json',
              ));

        //disable SSL check CURLOPT_SSL_VERIFYPEER => false
        curl_setopt($curl, CURLOPT_CAINFO, $_SERVER['DOCUMENT_ROOT'] ."/cacert.pem");
        //Execute the request.
        $results = curl_exec($curl);
        
        $error = curl_error($curl);

        //Close the cURL handle.
        curl_close($curl);
        
        return array('data'=>$results,'error'=>$error);
    }
    
    
    function CheckAndSendResponse($payment_response,$request) {
            
             $response_data = json_decode($payment_response['data']);

                if(is_object($response_data) && !is_null($response_data)) {
                    
                    if($response_data->code!=1) {

                    return json_encode(array(
                        'success'=>'no',
                        'status'=>400,
                        'message'=>'Payment failed.'
                            ));
                    }
                    
                    $pay_status = $this->CheckPaymentStatus($request->request_id);
                    
                   if($pay_status['status'] == TRUE) {
                       
                        return Response::json(array(
                         'success'=>'yes',                    
                         'status'=>200,
                         'message'=> 'Payment successful.'
                     ));
                       
                   } else {
                       
                       return json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=> 'Payment Unapproved.'
                                ));
                   }
                
                     
                
                } else {
                
                    return json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=> 'Payment failed.'
                                ));
                }  
        }
        
        
        function CheckPaymentStatus($referenceid) {
                  
            // check if payment is successfull
            $paid_response = CheckMazzumaPaymentStatus($referenceid);

            $paid = json_decode($paid_response['data']);

           return $paid->status =='Successful'? 
                   array('status'=>TRUE,'message'=>$paid_response['data']):
                   array('status'=>FALSE,'message'=>$paid_response['data']);
                    
        }