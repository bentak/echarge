<?php

class Partner extends \Eloquent {

	// Add your validation rules here
	public static $rules = array(
		'partner_name' => 'required|min:4',		
		'api_key' =>'required|min:20|max:250',
		'partner_phone' =>'required|min:8|max:22|unique:partners',
		'partner_email' =>'required|min:8|max:100|unique:partners'
	);	

	public static $apiUpdateRules1 = array(
                'name' => 'required|min:4',
		'password' =>'min:6|max:32',
		'phone' =>'required|min:8|max:22|unique',
		'phone_alt' =>'min:8|max:22|phone_alt|unique'
	);

	public static $apiUpdateRules2 = array(
                'name' => 'required|min:4',
		'password' =>'min:6|max:32',
		'phone' =>'min:8|max:22|phone|unique:customers',
		'phone_alt' =>'min:8|max:22:phone_alt'
	);



	// Don't forget to fill this array
	protected $fillable = array('partner_name','api_key','partner_phone','partner_email','quota_bal','is_reseller','is_active');

	protected $hidden = array('password');

	public function setPasswordAttribute($pass){
		$this->attributes['password'] = md5($pass . 'KANE->2018.Worla');
	}

	public function getRefAttribute($pass){
		return $this->attributes['email'];
	}

	public function checkPassword($pass)
	{
		if($this->password == md5($pass . 'KANE->2018.Worla'))
			return true;
		return false;
	}

	public static function createToken(){
        do{
            $token = str_random(24);
            $temp = Partner::where('api_key',$token)->get();
        }while(count($temp) > 0);
        
        return $token;
        }
    
	public static function createRessetToken(){
        do{
            $token = str_random(64);           
            $temp = Partner::where('api_key',$token)->get();
        }while(count($temp) > 0);
        
        return $token;
        }
    
    public function transactions(){
		return $this->hasMany('MomoTransation','payment_type','payment_id');
	}
        
    public function requests(){
		return $this->hasMany('Requst','id','request_id');
	}
        
    public static function customerExceptionStatus()
    {
            
          return $this->block_exception == "1" ? TRUE : FALSE;
           
    }
    
    private function NumericToken($length=6)
      {
          $chars = "1234567890";
          $clen   = strlen( $chars )-1;
          $id  = '';

          for ($i = 0; $i < $length; $i++) {
                  $id .= $chars[mt_rand(0,$clen)];
          }
          return ($id);
      }

}