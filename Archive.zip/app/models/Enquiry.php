<?php

class Enquiry extends \Eloquent {

	// Add your validation rules here
	public static $rules = array(
		'meter_code'  => 'required',
		//'balance'  => 'required',
		'customer_token'  => 'required',
		//'is_confirmed'  => 'required',
		//'confirmed_at'  => 'required',
		//'confirmed_by_id'  => 'required',
	);

	// Don't forget to fill this array
	protected $fillable = array('meter_code','balance','customer_token','is_confirmed','confirmed_at','confirmed_by_id','type');

	public function customer()
    {
        return $this->belongsTo('Customer','customer_token','customer_token');
    }

}