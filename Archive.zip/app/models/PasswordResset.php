<?php

class PasswordResset extends \Eloquent {

	// Add your validation rules here
	public static $rules = array(
		'name' => 'required|min:4',		
		'password' =>'required|min:6|max:32',
		'phone' =>'required|min:8|max:22|unique:customers',
		'phone_alt' =>'min:8|max:22'
	);

	public static $signinRules = array(
		'phone' => 'required|min:8|max:20',
		'password' =>'required'
	);

	public static $apiUpdateRules1 = array(
                'name' => 'required|min:4',
		'password' =>'min:6|max:32',
		'phone' =>'required|min:8|max:22|unique',
		'phone_alt' =>'min:8|max:22|phone_alt|unique'
	);

	public static $apiUpdateRules2 = array(
                'name' => 'required|min:4',
		'password' =>'min:6|max:32',
		'phone' =>'min:8|max:22|phone|unique:customers',
		'phone_alt' =>'min:8|max:22:phone_alt'
	);



	// Don't forget to fill this array
	protected $fillable = array('resset_customer','resset_contact','resset_token','is_resset','is_verified','verify_code','created_at');

	protected $hidden = array('password');

	
	public static function generateVerificationCode(){
        do{
            $token = PasswordResset::NumericToken();
            
            $temp = PasswordResset::where('verify_code',$token)->get();
        }while(count($temp) > 0);
        
        return $token;
        }
        
	public static function generateAccountVerificationCode(){
        do{
            $token = PasswordResset::NumericToken();
            
            $temp = PasswordResset::where('verify_code',$token)->get();
        }while(count($temp) > 0);
        
        return $token;
        }
        
	public static function createRessetToken(){
        do{
            $token = str_random(64);
            
            $temp = PasswordResset::where('resset_token',$token)->get();
        }while(count($temp) > 0);
        
        return $token;
        }
        
        private static function NumericToken($length=6)
        {
            $chars = "1234567890";
            $clen   = strlen( $chars )-1;
            $id  = '';

            for ($i = 0; $i < $length; $i++) {
                    $id .= $chars[mt_rand(0,$clen)];
            }
            return ($id);
        }

}