<?php

class PartnerBranche extends \Eloquent {

	// Add your validation rules here
	public static $rules = array(
		'branch_name' => 'required|min:4',
		'branch_location' =>'min:4|max:32'		
	);

	// Don't forget to fill this array
	protected $fillable = ['branch_name','branch_location','branch_partner','is_active'];
        
        public function partner(){
            return $this->belongsTo('Partner','branch_partner');
        }

}