<?php

class PartnerTopup extends \Eloquent {

	// Add your validation rules here
	public static $rules = array(
		'topup_partner' => 'required',		
		'amount_paid' =>'required',
		'ecg_quota' =>'required'		
	);	

	// Don't forget to fill this array
	protected $fillable = ['topup_partner','amount_paid','ecg_quota','quota_commission','vendor_commission','origgin_commission','partner_commission'];
        
        public function partner(){
            return $this->belongsTo('Partner','topup_partner');
    }

}