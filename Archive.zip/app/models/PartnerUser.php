<?php

class PartnerUser extends \Eloquent {

	// Add your validation rules here
	public static $rules = array(
		'user_name' => 'required|min:4',
		'user_password' =>'required|min:6',	
		'user_phone' =>'required|min:10',	
		'user_branch' =>'required'		
	);
        
	public static $updaterules = array(
		'user_name' => 'required|min:4',		
		'user_phone' =>'required|min:10',	
		'user_branch' =>'required'		
	);

	public static $signinRules = array(
		'user_name' => 'required|min:8|max:20|unique',
		'user_password' =>'required'
	);
        
	// Don't forget to fill this array
	protected $fillable = array('user_name','user_password','user_partner','user_branch','user_phone','account_level','is_active');

	protected $hidden = array('user_password');

	public function setPasswordAttribute($pass){
		$this->attributes['user_password'] = md5($pass . 'KANE->2018.Worla');
	}

	public function getRefAttribute($pass){
		return $this->attributes['email'];
	}

	public function checkPassword($pass)
	{
		if($this->user_password == md5($pass . 'KANE->2018.Worla'))
			return true;
		return false;
	}

	public static function createToken(){
        do{
            $token = str_random(64);
            $temp = Partner::where('api_key',$token)->get();
        }while(count($temp) > 0);
        
        return $token;
        }
    
	public static function createRessetToken(){
        do{
            $token = str_random(64);           
            $temp = Partner::where('api_key',$token)->get();
        }while(count($temp) > 0);
        
        return $token;
        }
    
    public function transactions(){
		return $this->hasMany('MomoTransation','payment_type','payment_id');
	}
        
    public function requests(){
	return $this->hasMany('Requst','id','request_id');
    }
        
    public function partner(){
            return $this->belongsTo('Partner','user_partner');
    }
    
    public function branch(){
            return $this->belongsTo('PartnerBranche','user_branch','branch_id');
    }
        
    public static function customerExceptionStatus()
    {
            
          return $this->block_exception == "1" ? TRUE : FALSE;
           
    }
    
    private function NumericToken($length=6)
      {
          $chars = "1234567890";
          $clen   = strlen( $chars )-1;
          $id  = '';

          for ($i = 0; $i < $length; $i++) {
                  $id .= $chars[mt_rand(0,$clen)];
          }
          return ($id);
      }

}