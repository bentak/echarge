<?php

class PartnerUserPermission extends \Eloquent {

	// Add your validation rules here
	public static $rules = array(
		'user_account' => 'required'			
	);

	public static $signinRules = array(
		'user_name' => 'required|min:8|max:20|unique',
		'user_password' =>'required'
	);
        
	// Don't forget to fill this array
	protected $fillable = array('user_account','can_add_sales',
            'can_view_transactions','can_view_branches',
            'can_edit_branches','can_delete_branches',
            'can_view_report','can_view_topups',
            'can_view_users','can_edit_users',
            'can_add_users','can_delete_users',
            'can_update_all','can_add_branches');
    
    public function user(){
            return $this->belongsTo('PartnerUser','user_account','user_id');
    }
    

}