<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of deliveryPayment
 *
 * @author Kwarteng
 */
class MomoPayment {
    //put your code here
    
    const MERCHANT_NUMBER = "HM0408170017";
    
    const CLIENT_ID = "btlnwlpg";
    
    const CLIENT_SECRET = "kymwrhox";
    
    //myghPay credentials
    
    
    
    const MAZZUMA_API_KEY = "419c1abdbbaa83cf2b21f15563f24edabc7f40a9";
    
    const MyGHPAY_CLIENT_ID = "fd930554-93e7-46ec-881a-8ca41656d4af";
    
    const MyGHPAY_CLIENT_SECRET = "fd8210d4-e832-46e0-8d56-212b44cc819c";
    
    const MyGHPAY_BASE_URL = "https://myghpay.com/myghpayclient/";
    
    private static $callback_ur = "http://eprepaid.origgin.net/successful_momo_transaction";
    
    public static $invoicecallback_url = "http://eprepaid.origgin.net/api/momo_callback";
    public static $invoiceBalancecallback_url = "http://eprepaid.origgin.net/api/balance_momo_callback";
    public static $invoicereturn_url = "http://eprepaid.origgin.net/api/momo_return/";
    public static $invoicecancel_url = "http://eprepaid.origgin.net/api/momo_cancel/";
   public static $invoicesuccess_url = "http://eprepaid.origgin.net/api/payments/status/";
    
   public static $MyGHPayCallback_url = "http://eprepaid.origgin.net/api/momo_callback/myghpay";
   public static $MyGHPayBalancecallback_url = "http://eprepaid.origgin.net/api/balance_momo_callback/myghpay";
   
   public static $MazzumaPrepaidCheckout_url = "http://eprepaid.origgin.net/api/payments/checkout/";
   public static $MazzumaBalanceCheckout_url = "http://eprepaid.origgin.net/api/payments/checkout/";
   public static $MazzumaPay_url = "http://eprepaid.origgin.net/api/payments/pay_mazzuma/";
   public static $MazzumaBalancePay_url = "http://eprepaid.origgin.net/api/payments/checkout/";
    
    private static $paymentRequest = array('Amount'=>'',
        'CustomerName'=>'',
        'CustomerEmail'=>'',
        'CustomerMsisdn'=>'',
        'Channel'=>'',
        'PrimaryCallbackURL '=>'',
        'SecondaryCallbackURL'=>'',
        'ClientReference'=>'',
        'Description'=>'Payment of Delivery service.',
        'Token'=>'',
        'FeesOnCustomer'=>True,
        );
    
    private static $MazzumaRequestOptions = array(
        'price'=>'',
        'network'=>'',
        'recipient_number'=>'0245612176',
        'sender'=>'',
        'option'=>'',
        'apikey'=>'',        
        'orderID'=>''        
        );
    
    
    private static  $MomoPaymentInvoice =  array (
          'items' => array(),
          'totalAmount' => 100,
          'description' => 'Origgin E-Prepaid Checkout',
          'callbackUrl' => 'http://eprepaid.origgin.net/momo_callback',
          'returnUrl' => 'http://eprepaid.origgin.net/momo_return',
          'merchantBusinessLogoUrl' => 'http://eprepaid.origgin.net/assets/dashboard/img/logo.png',
          'merchantAccountNumber' => self::MERCHANT_NUMBER,
          'cancellationUrl' => 'http://eprepaid.origgin.net/momo_cancel',
          'clientReference' => '',
        );
    
        public static function processPayment($referenceid, $details) {
            
            self::$paymentRequest['ClientReference'] = $referenceid;
            self::$paymentRequest['CustomerName'] = $details['name'];
            self::$paymentRequest['CustomerMsisdn'] = $details['number'];
            self::$paymentRequest['Channel'] = $details['operator'];
            self::$paymentRequest['Amount'] = $details['cost'];
            self::$paymentRequest['PrimaryCallbackURL'] = self::$callback_ur;
            self::$paymentRequest['SecondaryCallbackURL'] = self::$callback_ur;
            
            //send request
            $request = self::sendRequest();
            
            return $request;
            
        }
        
        private static function sendRequest() {
            
            $basic_auth_key =  'Basic ' . base64_encode(self::CLIENT_ID . ':' . self::CLIENT_SECRET);
            
            $request_url = "https://api.hubtel.com/v1/merchantaccount/merchants/".self::MERCHANT_NUMBER."/receive/mobilemoney";
       
            $curl = curl_init($request_url);
            
            curl_setopt( $curl, CURLOPT_POST, true );  
            curl_setopt( $curl, CURLOPT_POSTFIELDS, json_encode(self::$paymentRequest) );  
            curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
            curl_setopt( $curl, CURLOPT_HTTPHEADER, array(
                'Authorization: '.$basic_auth_key,
                'Cache-Control: no-cache',
                'Content-Type: application/json',
              ));

        //Execute the request.
        $results = curl_exec($curl);
        
        $error = curl_error($curl);

        //Close the cURL handle.
        curl_close($curl);
        
        return array('data'=>$results,'error'=>$error);
    }
    
    
        public static function processInvoice($invoice) {
            
            self::$MomoPaymentInvoice['clientReference'] = $invoice['reference'];
            
            self::$MomoPaymentInvoice['callbackUrl'] = self::$invoicecallback_url;
            self::$MomoPaymentInvoice['returnUrl'] = self::$invoicereturn_url.$invoice['reference'];
            self::$MomoPaymentInvoice['cancellationUrl'] = self::$invoicecancel_url.$invoice['reference'];
            
            self::$MomoPaymentInvoice['totalAmount'] = $invoice['cost'];           
                        
            self::$MomoPaymentInvoice['items'] = $invoice['items'];
            
            
            //send request
            $response = self::sendInvoiceRequest();
            
            return $response;
            
        }
        
        public static function processBalanceInvoice($invoice) {
            
            self::$MomoPaymentInvoice['clientReference'] = $invoice['reference'];
            
            self::$MomoPaymentInvoice['callbackUrl'] = self::$invoiceBalancecallback_url;
            self::$MomoPaymentInvoice['returnUrl'] = self::$invoicereturn_url.$invoice['reference'];
            self::$MomoPaymentInvoice['cancellationUrl'] = self::$invoicecancel_url.$invoice['reference'];
            
            self::$MomoPaymentInvoice['totalAmount'] = $invoice['cost'];           
                        
            self::$MomoPaymentInvoice['items'] = $invoice['items'];
            
            
            //send request
            $response = self::sendInvoiceRequest();
            
            return $response;
            
        }
        
        private static function sendInvoiceRequest() {
            
            $basic_auth_key =  'Basic ' . base64_encode(self::CLIENT_ID . ':' . self::CLIENT_SECRET);
            
            $request_url = "https://api.hubtel.com/v2/pos/onlinecheckout/items/initiate";
       
            $curl = curl_init($request_url);
            
            curl_setopt( $curl, CURLOPT_POST, true );  
            curl_setopt( $curl, CURLOPT_POSTFIELDS, json_encode(self::$MomoPaymentInvoice) );  
            curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
            curl_setopt( $curl, CURLOPT_HTTPHEADER, array(
                'Authorization: '.$basic_auth_key,
                'Cache-Control: no-cache',
                'Content-Type: application/json',
              ));

        //disable SSL check CURLOPT_SSL_VERIFYPEER => false
        curl_setopt($curl, CURLOPT_CAINFO, $_SERVER['DOCUMENT_ROOT'] ."/cacert.pem");
        //Execute the request.
        $results = curl_exec($curl);
        
        $error = curl_error($curl);

        //Close the cURL handle.
        curl_close($curl);
        
        return array('data'=>$results,'error'=>$error);
    }
    
    
    public static function processMazzumaPayment($invoice) {
            
        $price_less_charges = doubleval($invoice['price']) - (0.03*doubleval($invoice['price']));
        
            self::$MazzumaRequestOptions['sender'] = $invoice['sender'];
            
            self::$MazzumaRequestOptions['network'] = $invoice['network'];
           
            self::$MazzumaRequestOptions['option'] = $invoice['option'];
            
            self::$MazzumaRequestOptions['price'] = $price_less_charges;           
                        
            self::$MazzumaRequestOptions['apikey'] = self::MAZZUMA_API_KEY;
            
            self::$MazzumaRequestOptions['orderID'] = $invoice['id'];
            
            
            //send request
            $response = self::sendMazzumaRequest();
            
            return $response;
            
        }
    public static function TestMazzumaPayment($invoice) {
            
            self::$MazzumaRequestOptions['sender'] = $invoice['sender'];
            
            self::$MazzumaRequestOptions['network'] = $invoice['network'];
           
            self::$MazzumaRequestOptions['option'] = $invoice['option'];
            
            self::$MazzumaRequestOptions['price'] = $invoice['price'];           
                        
            self::$MazzumaRequestOptions['apikey'] = self::MAZZUMA_API_KEY;
            
            self::$MazzumaRequestOptions['orderID'] = $invoice['id'];
            
            
            //send request
            //$response = self::sendMazzumaRequest();
            
            return self::$MazzumaRequestOptions; //return $response;
            
        }
        
        private static function sendMazzumaRequest() {           
            
            
            $request_url = "https://client.teamcyst.com/api_call.php";
       
            $curl = curl_init($request_url);
            
            curl_setopt( $curl, CURLOPT_CUSTOMREQUEST, "POST" );  
            curl_setopt( $curl, CURLOPT_POSTFIELDS, json_encode(self::$MazzumaRequestOptions) );  
            curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
            curl_setopt( $curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
              ));

        //disable SSL check CURLOPT_SSL_VERIFYPEER => false
        //curl_setopt($curl, CURLOPT_CAINFO, $_SERVER['DOCUMENT_ROOT'] ."/cacert.pem");
        //Execute the request.
        $results = curl_exec($curl);
        
        $error = curl_error($curl);

        //Close the cURL handle.
        curl_close($curl);
        
        return array('data'=>$results,'error'=>$error);
    }
    public static function CheckMazzumaPaymentStatus($paymentid) {           
            
            
            $request_url = "https://client.teamcyst.com/checktransaction.php?orderID=$paymentid";
       
            $curl = curl_init($request_url);
            
            //curl_setopt( $curl, CURLOPT_POST, true );  
            //curl_setopt( $curl, CURLOPT_POSTFIELDS, json_encode(self::$MazzumaRequestOptions) );  
            curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
            curl_setopt( $curl, CURLOPT_HTTPHEADER, array(                
                'Cache-Control: no-cache',
                'Content-Type: application/json',
              ));

        //disable SSL check CURLOPT_SSL_VERIFYPEER => false
        curl_setopt($curl, CURLOPT_CAINFO, $_SERVER['DOCUMENT_ROOT'] ."/cacert.pem");
        //Execute the request.
        $results = curl_exec($curl);
        
        $error = curl_error($curl);

        //Close the cURL handle.
        curl_close($curl);
        
        return array('data'=>$results,'error'=>$error);
    }
}
