<?php

class EcgStatus extends \Eloquent {

	// Add your validation rules here
	public static $rules = [
		// 'title' => 'required'
	];

	// Don't forget to fill this array
	protected $fillable = array('status');

	public static function currentStatus()
	{
		$temp = EcgStatus::orderBy('created_at','DESC');

		if(count($temp->get())>0)
			return $temp->first()->status;

		return 0;
	}

}