<?php

class DeniedRequest extends \Eloquent {
    

    public static function customerBlockedStatus($customerid)
    {
            $temp = BlockedList::where('blocked_customer',$customerid)->orderBy('block_id','DESC');

            if(count($temp->get())>0) {
                return $temp->first()->block_status == "1" ? TRUE : FALSE;
            }		

            return FALSE;
    }   
    
    
    public function customer(){
            return $this->belongsTo('Customer','customer_id','id');
    }

}