<?php

use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;

class User extends Eloquent implements UserInterface, RemindableInterface {

	use UserTrait, RemindableTrait;

	protected $softDelete = true;
	
	protected $fillable = array('username','password' ,'email','user_type_id');
	
	public static $rules = array(
		'username' => 'required|min:2',
		'email' => 'required|email|unique:users',
		'password'=>'required|between:6,20|confirmed',
		'password_confirmation'=>'required|between:6,20'
	);

	public static $update_rules1 = array(
		'username' => 'required|min:2',
		'email' => 'required|email|unique:users'
	);

	public static $update_rules2 = array(
		'username' => 'required|min:2'
	);

	public static $profile_rules = array(
		'username' => 'required|min:2',
		'email' => 'required|email|unique:users'
	);

	public static $profile_rules2 = array(
		'username' => 'required|min:2'
	);

	public static $pc_rules = array(
		'password'=>'required|between:6,20|confirmed',
		'password_confirmation'=>'required|between:6,20'
	);

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'users';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	protected $hidden = array('password');

	/**
	 * Get the unique identifier for the user.
	 *
	 * @return mixed
	 */
	public function getAuthIdentifier()
	{
		return $this->getKey();
	}

	/**
	 * Get the password for the user.
	 *
	 * @return string
	 */
	public function getAuthPassword()
	{
		return $this->password;
	}

	/**
	 * Get the token value for the "recustomer me" session.
	 *
	 * @return string
	 */
	public function getRecustomerToken()
	{
		return $this->recustomer_token;
	}

	/**
	 * Set the token value for the "recustomer me" session.
	 *
	 * @param  string  $value
	 * @return void
	 */
	public function setRecustomerToken($value)
	{
		$this->recustomer_token = $value;
	}

	/**
	 * Get the column name for the "recustomer me" token.
	 *
	 * @return string
	 */
	public function getRecustomerTokenName()
	{
		return 'recustomer_token';
	}

	/**
	 * Get the e-mail address where password reminders are sent.
	 *
	 * @return string
	 */
	public function getReminderEmail()
	{
		return $this->email;
	}
	
	public function setPasswordAttribute($pass){
		$this->attributes['password'] = Hash::make($pass);
	}

	public function type()
    {
        return $this->belongsTo('UserType','user_type_id');
    }

}
