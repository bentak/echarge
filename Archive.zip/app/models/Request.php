<?php

class Request extends \Eloquent {

	// Add your validation rules here
	public static $initiateRules = array(
		// 'title' => 'required'
		'meter_code' => 'required|numeric',
        'amount' => 'required|numeric',
        'location' => 'required',
        'meter_owner' => 'required',
        'location_id' => 'required|numeric',
        'customer_id' => 'required|numeric'
	);

	// Don't forget to fill this array
	protected $fillable = array('type_id','meter_code','amount','location','meter_owner','location_id','customer_id','is_confirmed','confirmed_at','is_rejected','rejected_at','is_paid','paid_at');

}
