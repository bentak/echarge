<?php

class Location extends \Eloquent {

	// Add your validation rules here
	public static $rules = [
		'name' => 'required|min:4',
		'description' => 'required|min:4'
	];

	// Don't forget to fill this array
	protected $fillable = ['name','description','region_id','created_at','updated_at'];
        
        public function region(){
            return $this->belongsTo('EcgRegion','region_id','id');
    }

}