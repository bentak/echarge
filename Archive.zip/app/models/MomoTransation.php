<?php

include_once 'MomoPayment.php';

class MomoTransation extends \Eloquent {

	// Add your validation rules here
	public static $payment_rules = array(
		'mm_name' => 'required|min:6',
		'mm_network' => 'required',
		'mm_number' => 'required|min:10',
	);
        
	public static $callback_rules = array(
		'reference' => 'required|min:6',
		'code' => 'required',
		'transactionID' => 'required|min:8',
	);

	// Don't forget to fill this array
	protected $fillable = array('amount','charges','amount_after_charges','transaction_id','response_code','description','client_refrence','external_transaction_id','requst_id','is_sold','sold_at','is_refunded','refunded_at','pay_number','payment_type','network','origgin_charge','ecg_amount');

	public function requst(){
		return $this->belongsTo('Requst','requst_id');
	}       
	
        
	public function payment(){
		return $this->belongsTo('PaymentType','payment_type','payment_id');
	}

	public function customer(){
		return $this->requst?($this->requst->customer?$this->requst->customer->phone:''):'';
	}
        
	public function partner(){
		return $this->requst?($this->requst->partnerobj?$this->requst->partnerobj->partner_name:''):'';
	}
	public function partner_obj(){
		return $this->requst?($this->requst->partnerobj?$this->requst->partnerobj:NULL):NULL;
	}
        
	public function branch(){
		return $this->requst?($this->requst->request_branch?$this->requst->request_branch->branch_name:'-'):'';
	}
        
	public function customer_id(){
		return $this->requst?$this->requst->customer_id:'';
	}

	public static function getOrigginCharge($amount){
		return number_format($amount,2,'.',',');
	}


	public function getAmountAttribute($value){
		return number_format($this->attributes['amount'],2,'.',',');
	}
	
	public function getLocationAttribute($value){
		if($this->requst && $this->requst->location!='')
			if($this->requst->location=='nan')
				return '-';
			return $this->requst->location;
		return '-';
	}
        
        
        public static function getOrigginRate($amount) {
            $rate = 0.1;
            if($amount<=10){
                $rate = 0.1;
            } elseif($amount>10 && $amount<=50) {                 
                $rate = 0.07;
            }
            elseif($amount>50 && $amount<=100) {                 
                $rate = 0.05;
            }
            elseif($amount>100 && $amount<=1000) {                 
                $rate = 0.02;
            }
            elseif($amount>1000 && $amount<=2000) {                 
                $rate = 0.01;
            }
            elseif($amount>2000 ) {                 
                $rate = 0.005;
            }
            return $rate;

        }
        
        
        public static function getOrigginFee($amount) {
            $rate = MomoTransation::getOrigginRate($amount);           
            $fee = $rate * $amount;
            return $fee;
        }

        public static function generatePrepaidInvoice($request) {            
           
            $origgin_fee = MomoTransation::getOrigginFee($request['amount']);
            
              $invoice = array(
                  'items'=> array(
                      array (
                        'name' => 'Prepaid Credit',
                        'quantity' => 1,
                        'unitPrice' => $request['amount'],
                        ),
                      array (
                        'name' => 'Service Charge',
                        'quantity' => 1,
                        'unitPrice' => $origgin_fee,
                      )
                      ),
                  'reference'=>$request['request_id'],
                  'cost'=>$request['amount'] + $origgin_fee
                  );
              
            //send payment request
            $payment = MomoPayment::processInvoice($invoice);
            
            if(strlen($payment['error'])==0){
                $payment['cancelurl']= MomoPayment::$invoicecancel_url.$request['request_id'];
                $payment['returnurl']= MomoPayment::$invoicereturn_url.$request['request_id'];
                $payment['statusurl']= MomoPayment::$invoicesuccess_url.$request['request_id'];
            }
        
            return  $payment;
           
        }
        
        
        public static function MyGHPayPrepaidInvoice($request) {
           $prepaid_invoice = array('data'=> json_encode(array(
               'status'=>'success',
               'checkoutUrl'=>'http://eprepaid.origgin.net/api/momo_pay/'.$request['request_id']
           )),
               'error'=>'',
               'cancelurl'=>MomoPayment::$invoicecancel_url.$request['request_id'],
               'returnurl'=>MomoPayment::$invoicereturn_url.$request['request_id'],
               'statusurl'=>MomoPayment::$invoicesuccess_url.$request['request_id']);                     
        
            return  $prepaid_invoice;
           
        }
        
        public static function MyGHPayBalanceInvoice($request) {
           
            $balance_invoice = array('data'=> json_encode(array(
               'status'=>'success',
               'checkoutUrl'=>'http://eprepaid.origgin.net/api/momo_pay_balance/'.$request['request_id']
           )),
               'error'=>'',
               'cancelurl'=>MomoPayment::$invoicecancel_url.$request['request_id'],
               'returnurl'=>MomoPayment::$invoicereturn_url.$request['request_id'],
               'statusurl'=>MomoPayment::$invoicesuccess_url.$request['request_id']);                     
        
            return  $balance_invoice;
           
        }
        
        
        public static function generateBalanceInvoice($request) {            
           
            $origgin_fee = MomoTransation::getOrigginFee($request['amount']);
            
              $invoice = array(
                  'items'=> array(
                      array (
                        'name' => 'Credit Balance',
                        'quantity' => 1,
                        'unitPrice' => $request['amount'],
                        )
                      ),
                  
                  'reference'=>$request['request_id'],
                  'cost'=>$request['amount']
                  );
              
            //send payment request
            $payment = MomoPayment::processBalanceInvoice($invoice);
            
            if(strlen($payment['error'])==0){
                $payment['cancelurl']= MomoPayment::$invoicecancel_url.$request['request_id'];
                $payment['returnurl']= MomoPayment::$invoicereturn_url.$request['request_id'];
                $payment['statusurl']= MomoPayment::$invoicesuccess_url.$request['request_id'];
            }
        
            return  $payment;
           
        }
        
        
        public static function MazzumaPrepaidInvoice($request) {
           $prepaid_invoice = array('data'=> json_encode(array(
                    'data'=>array(
                        'checkoutUrl'=>MomoPayment::$MazzumaPay_url.$request['request_id']),
                   'status'=>'success'           
               )
                   ),
               'error'=>'',
               'cancelurl'=>MomoPayment::$invoicecancel_url.$request['request_id'],
               'returnurl'=>MomoPayment::$invoicereturn_url.$request['request_id'],
               'statusurl'=>MomoPayment::$invoicesuccess_url.$request['request_id']);                     
        
            return  $prepaid_invoice;
           
        }
        
        public static function MazzumaBalanceInvoice($request) {
           
            $balance_invoice = array('data'=> json_encode(array(
                    'data'=>array(
                        'checkoutUrl'=>MomoPayment::$MazzumaBalancePay_url.$request['request_id']),
                   'status'=>'success'           
                )
                    ),
               'error'=>'',
               'cancelurl'=>MomoPayment::$invoicecancel_url.$request['request_id'],
               'returnurl'=>MomoPayment::$invoicereturn_url.$request['request_id'],
               'statusurl'=>MomoPayment::$invoicesuccess_url.$request['request_id']);                     
        
            return  $balance_invoice;
           
        }

}
