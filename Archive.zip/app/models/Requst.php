<?php

class Requst extends \Eloquent {

	// Add your validation rules here
	public static $initiateRules = array(
		// 'title' => 'required'
		'meter_code' => 'required|numeric',
                'amount' => 'required|numeric',
                'location' => 'required',
                'meter_owner' => 'required',
//                'request_id' => 'required',
                'customer_id' => 'required|numeric'
                );

	// Don't forget to fill this array
	protected $fillable =  array('request_id','type_id','meter_code','amount','location','meter_owner','location_id','customer_id','is_confirmed','confirmed_at','is_rejected','rejected_at','is_paid','paid_at','partner','user_id','branch_id');

	public static function createID(){
        do{
            $id = str_random(8);
            $temp = Requst::where('request_id',$id)->get();
        }while(count($temp) > 0);
        
        return $id;
    }
    
    private function AlphaNumeric($length){
          $chars = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
          $clen   = strlen( $chars )-1;
          $id  = '';

          for ($i = 0; $i < $length; $i++) {
                  $id .= $chars[mt_rand(0,$clen)];
          }
          return ($id);
      }

    public function customer(){
        return $this->belongsTo('Customer');
    }
    
    public function partnerobj(){
        return $this->belongsTo('Partner','partner');
    }
    
    public function request_branch(){
        return $this->belongsTo('PartnerBranche','branch_id','branch_id');
    }
    
    public function transaction(){
		return $this->belongsTo('MomoTransation');
	}

    public function getStatusAttribute(){
        return ($this->attributes['paid_at'] <> "0000-00-00 00:00:00")?'PAID':'NOT PAID';
    }

    public function getStatusStrClassAttribute(){
         return ($this->attributes['paid_at'] <> "0000-00-00 00:00:00")?'success':'warning';
    }

    public function getAmountAttribute($value){
        return number_format($this->attributes['amount'],2,'.',',');
    }

}