<?php

class PaymentVerification extends \Eloquent {

	// Add your validation rules here
	



	// Don't forget to fill this array
	protected $fillable = array('verify_customer','verify_contact','is_expired','is_verified','verify_code','created_at');

	protected $hidden = array('password');

	
	public static function generateVerificationCode(){
        do{
            $token = PaymentVerification::NumericToken();
            
            $temp = PaymentVerification::where('verify_code',$token)->get();
        }while(count($temp) > 0);
        
        return $token;
        }
        
        private static function NumericToken($length=6)
        {
            $chars = "1234567890";
            $clen   = strlen( $chars )-1;
            $id  = '';

            for ($i = 0; $i < $length; $i++) {
                    $id .= $chars[mt_rand(0,$clen)];
            }
            return ($id);
        }

}