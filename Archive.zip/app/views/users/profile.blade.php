
@extends('layouts.main')

@section('contentarea') 



<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">User Profile</h1>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-user"></i>
                Edit profile
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-12">
                        {{ Form::model($user, array('route' => array('user.update_profile'),'method' => 'POST')) }}
                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('username', 'Username') }}

                                {{ Form::text('username',Input::old('username'),array('class'=>'form-control','placeholder'=>'')) }}
                                <span class="text-danger">{{$errors->first('username')}}</span>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('email', 'Email') }}

                                {{ Form::text('email',Input::old('email'),array('class'=>'form-control','placeholder'=>'')) }}
                                <span class="text-danger">{{$errors->first('email')}}</span>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <button type="submit" class="btn btn-success btn-block">Update Profile</button>
                        </div>
                        <div class="col-md-4">
                            <button type="reset" class="btn btn-warning btn-block">Cancel Changes</button>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-key"></i>
                Change Password
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-12">
                        {{ Form::open(array('url' => 'user/change_password','role'=>'form')) }}
                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('password', 'New Password') }}

                                <input class="form-control" placeholder="" name="password" type="password" value="">
                                <span class="text-danger">{{$errors->first('password')}}</span>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                {{ Form::label('password_confirmation', 'Password Confirmation') }}

                                <input class="form-control" placeholder="" name="password_confirmation" type="password" value="">
                                <span class="text-danger">{{$errors->first('password_confirmation')}}</span>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <button type="submit" class="btn btn-success btn-block">Submit</button>
                        </div>
                        <div class="col-md-4">
                            <button type="reset" class="btn btn-warning btn-block">Clear</button>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>

 @stop