<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="utf-8">
    <title>User Access | Origgin Prepaid</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
<link href="assets/dashboard/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="assets/dashboard/css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

<link href="assets/dashboard/css/font-awesome.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    
<link href="assets/dashboard/css/style.css" rel="stylesheet" type="text/css">
<link href="assets/dashboard/css/pages/signin.css" rel="stylesheet" type="text/css">

</head>

<body>
    
<div class="navbar navbar-fixed-top">
    
    <div class="navbar-inner" style="padding: 2.5em;">
            
    </div> <!-- /navbar-inner -->
    
</div> <!-- /navbar -->

@if(Session::has('ms'))
    <div class="alert alert-{{ Session::get('mt') }} alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        {{ Session::get('ms') }}</a>.
    </div>
@endif



<div class="account-container">
    
        <div class="content clearfix">
        {{ Form::open(array('url' => 'signin','role' => 'form')) }}   
            <div style="margin-top: 10px; margin-bottom: 10px;">
                <center>
                    {{ HTML::image("assets/dashboard/img/orrigin_logo.png", "Logo") }}
                </center>
            </div>
            <div class="login-fields">
            
                <div class="field">
                    <label for="email">Email</label>
                    <input type="text" id="username" name="email" value="" placeholder="Email" class="login username-field" />
                </div> <!-- /field -->
                
                <div class="field">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" value="" placeholder="Password" class="login password-field"/>
                </div> <!-- /password -->
                
            </div> <!-- /login-fields -->
            
            <div class="login-actions">
                
                <span class="login-checkbox">
                    <input id="Field" name="Field" type="checkbox" class="field login-checkbox" value="First Choice" tabindex="4" />
                    <label class="choice" for="Field">
                       <span class="text-danger">Remember me</span>
                    </label>
                </span>
                                    
                <button class="button btn btn-default btn-large">Log In</button>
                
            </div> <!-- .actions -->
            
            
            
        </form>
        
    </div> <!-- /content -->
    
</div> <!-- /account-container -->



<div class="login-extra text-center">
    <center>
        <a href="#" class="text-danger">Forgot Password?</a>
    </center>
</div> <!-- /login-extra -->



<div class="navbar navbar-fixed-bottom">
    
    <div class="navbar-inner" style="padding: 0.3em;">
            <p>
                <center>
                    <span class="text-white">
                        Copyright &copy; <?= date('Y') ?> Origgin Ltd. All Rights Reserved.
                    </span>
                </center>
            </p>
    </div> <!-- /navbar-inner -->
    
</div> <!-- /navbar -->
<script src="assets/dashboard/js/jquery-1.7.2.min.js"></script>
<script src="assets/dashboard/js/bootstrap.js"></script>

<script src="assets/dashboard/js/signin.js"></script>

</body>

</html>
