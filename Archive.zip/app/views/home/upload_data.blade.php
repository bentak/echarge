

{{ Form::open(array('url' => 'upload_data','role'=>'form','files'=>'true')) }}

{{Form::file('data_file')}}

<div class="col-md-8">
    <button type="submit" class="btn btn-success btn-block">Upload</button>
</div>

{{ Form::close() }}

