<?php 
   
   

?>

<html>
    
    <body>
        
        <form name='form' action='<?php echo MomoPayment::MyGHPAY_BASE_URL; ?>' method='post'id="myghpayform">
            <input type='hidden' name='clientid' value='<?php echo MomoPayment::MyGHPAY_CLIENT_ID; ?>'>
            <input  type='hidden'  name='itemname'  value='{{$itemname}}'>
            <input type='hidden' name='clientref' value='{{$clientref}}'>
            <input type='hidden' name='clientsecret' value='<?php echo MomoPayment::MyGHPAY_CLIENT_SECRET; ?>'>
            <input type='hidden' name='returnurl' value='{{returnurl}}'>
            <input type='hidden' name='amount' value='{{$amount}}'>
        </form> 
        
        <script type="text/javascript">
            document.getElementById('myghpayform').submit();
        </script>
        
    </body>
    
</html>