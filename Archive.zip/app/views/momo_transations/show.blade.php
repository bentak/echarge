<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Portal | Origgin Prepaid</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="{{URL::asset('assets/dashboard/css/bootstrap.min.css')}}" rel="stylesheet">
<link href="{{URL::asset('assets/dashboard/css/bootstrap-responsive.min.css')}}" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="{{URL::asset('assets/dashboard/css/font-awesome.css')}}" rel="stylesheet">
<link href="{{URL::asset('assets/dashboard/css/style.css')}}" rel="stylesheet">
<link href="{{URL::asset('assets/dashboard/css/pages/dashboard.css')}}" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>

@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">
    
    <div class="widget">
        <div class="widget-header">
            <i class="icon-list-alt"></i>
            <h3>Transactions </h3>
        </div>
        <!-- /widget-header -->
        <div class="widget-content">
        	<div class="span5">
        		<table class="table ">
		          	<tr>
		          		<th style="text-align: right;width: 120px;">ID</th>
		          		<td>{{$transaction->id}}</td>
		          	</tr>
		          	<tr>
		          		<th style="text-align: right;width: 120px;">Meter Code</th>
		          		<td>{{{$transaction->requst
		          		?$transaction->requst->meter_code:''}}}</td>
		          	</tr>
		          	<tr>
		          		<th style="text-align: right;width: 120px;">Date Time</th>
		          		<td>{{{$transaction->requst
		          		?$transaction->requst->created_at:''}}}</td>
		          	</tr>
		          	<tr>
		          		<th style="text-align: right;width: 120px;">Location</th>
		          		<td>{{{$transaction->requst
		          		?$transaction->requst->location:''}}}</td>
		          	</tr>
		          	<tr>
		          		<th style="text-align: right;width: 120px;">Meter Owner</th>
		          		<td>{{{$transaction->requst
		          		?$transaction->requst->meter_owner:''}}}</td>
		          	</tr>
		          	<tr>
		          		<th style="text-align: right;width: 120px;">Customer</th>
		          		<td class="">{{$transaction->customer()
		          		?$transaction->customer()->email:''}}</td>
		          	</tr>
		        </table>
        	</div>
        	<div class="span6">
        		<table class="table ">
		          	<tr>
		          		<th style="text-align: right;width: 140px;">Amount</th>
		          		<td>{{$transaction->amount}}</td>
		          	</tr>
		          	<tr>
		          		<th style="text-align: right;width: 140px;">Charge</th>
		          		<td>{{$transaction->charges}}</td>
		          	</tr>
		          	<tr>
		          		<th style="text-align: right;width: 140px;">Amount after charge</th>
		          		<td>{{$transaction->charges+$transaction->amount}}</td>
		          	</tr>
		          	<tr>
		          		<th style="text-align: right;width: 140px;">External Transaction ID</th>
		          		<td>{{$transaction->external_transaction_id}}</td>
		          	</tr>
		          	<tr>
		          		<th style="text-align: right;width: 140px;">Client Reference</th>
		          		<td>{{$transaction->client_reference}}</td>
		          	</tr>
		          	<tr>
		          		<th style="text-align: right;width: 140px;">Status</th>
		          		<td class=""><span class="label label-{{$transaction->requst
		          		?$transaction->requst->status_str_class:''}}">{{$transaction->requst
		          		?$transaction->requst->status:''}}</span></td>
		          	</tr>
		        </table>
        	</div>
          
        
      </div>
    </div>
      
    
  </div> <!-- /row -->
	
	    </div> <!-- /container -->
    
	</div> <!-- /main-inner -->
	    
</div>
<!-- /main -->

<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="span12"> &copy; {{date('Y')}} <a href="http://www.origgin.net/">Origgin</a>. </div>
        <!-- /span12 --> 
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /footer-inner --> 
</div>
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="assets/dashboard/js/jquery-1.7.2.min.js"></script> 
<script src="assets/dashboard/js/excanvas.min.js"></script> 
<script src="assets/dashboard/js/chart.min.js" type="text/javascript"></script> 
<script src="assets/dashboard/js/bootstrap.js"></script>
<script language="javascript" type="text/javascript" src="assets/dashboard/js/full-calendar/fullcalendar.min.js"></script>
 
<script src="assets/dashboard/js/base.js"></script> 

</body>
</html>
