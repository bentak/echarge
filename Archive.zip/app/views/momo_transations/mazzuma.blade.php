<?php
include_once DIR_SYS.'/dbconnect.php';

$head['title'] = 'Edit Item';


?>

<html>
<head>
<title> </title>    

<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 

<style type="text/css">
header {
    height: 8%;background-color: #E9E9EB;position: fixed;width: 100%; padding-top: 5px;border-bottom: 1px solid #4DBCEB;z-index: 19;top: 0;left: 0;max-height: 60px;
}
nav {
    height: 100%;
}

.profile-view {
    height: 400px auto; margin:0 auto;padding: 30 10; position: relative;background: #FFF;
}
.input-form {
    position: relative;padding: 10px 30;
}

.input-form table {
    width: 100%;
}
.heading {
    position: absolute;
     color:#167CAC;
    font-size: 25px;
    font-weight: 500;
/*    letter-spacing: -0.016em;*/
    width: auto;display: inline;
    text-align: center;
}
.center-x{left: 50%; -webkit-transform: translateX(-50%);-moz-transform: translateX(-50%);transform: translateX(-50%);}
.center{left: 50%;top: 50%; -webkit-transform: translate(-50%,-50%);-moz-transform: translate(-50%,-50%);transform: translate(-50%,-50%);}
.left{float: left;margin-left: 10px;}
.right{float: right;margin-right: 10pt;}
.hidden{visibility: collapse;display: none;}
.disable-scroll {
    height: 100%;overflow: hidden;
}
    
input[type="text"] , input[type="password"], input[type="email"],input[type="datetime-local"],select,textarea {
     display: block;margin: 10px 0px;width: 100%; height: 30pt;border: 1px solid #ddd;position: relative;padding: 8;font-size: 1.0em;font-family: bodyFont;
     border-radius: 6px;-webkit-border-radius: 6px;

}
.reaction {
    width: 300px;position: relative;
}
.round-10 {border-radius: 10px;-webkit-border-radius: 10px;-moz-border-radius: 10px;-o-border-radius: 10px;-ms-border-radius: 10px;}
.round {border-radius: 50%;-webkit-border-radius: 50%;-moz-border-radius: 50%;-o-border-radius: 50%;-ms-border-radius: 50%;}
    [role="button"] {
    text-decoration: none;
}
.add-button {
    width: 100px;height: 20px;padding: 10px;background-color: #00AFEF;color: white;text-align: center;position: relative;margin: 0px auto;cursor: pointer;
}
.left{float: left;margin-left: 10px;}
    
/*
    Menu styles
    
*/
    
.context-menu {
    width: 300px auto; height: 40px;z-index: 29;position: relative;
/*    border-left:1px solid #4DBCEB;*/
}
.context-menu > [role="button"]{
     background-repeat: no-repeat;background-position: center;background-size: contain;
    width: 30px;height: 30px;margin: 5px; position: relative;margin-left: 20px;
}
.new:hover {
    background-color: lightblue;
}
.new.disabled {
    pointer-events: none;background-color:lightblue;
}
.tooltip:after {
    content: attr(data-tip); visibility: hidden;width: 80px;background-color: lightblue;color: #fff;text-align: center;
    padding: 5px 0;border-radius: 6px;
 
    /* Position the tooltip text - see examples below! */
    position: absolute;
    z-index: 1;top: 115%;
    left: 50%;margin-left: -40px;
}
.tooltip:hover.tooltip:after{
    visibility: visible;
}
.tooltip:hover.tooltip:before {
    content: " ";
    position: absolute;
    bottom: -15%;  /* At the top of the tooltip */
    left: 50%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: transparent transparent lightblue transparent;
}
#add {
    
    background-image: url(/cosmic/delivery/icons/expand.png);
}
#edit {
    background-image: url(/cosmic/delivery/icons/edit.png);
}
#del {
    background-image: url(/cosmic/delivery/icons/delete1.png);
}
#new {
    background-image: url(/cosmic/delivery/icons/new_1.png);
}
#cancel {
    background-image: url(/cosmic/delivery/icons/cancel.png);
}
#save {
    background-image: url(/cosmic/delivery/icons/save.png);
}
#loader{background-image: url(/cosmic/delivery/icons/progress.gif);display: block;background-position: center;background-repeat: no-repeat;}
[role="button"].upd, [role="button"].del {
    text-align: center; color: darkblue;
    background-position: center;
    background-repeat: no-repeat;background-size: contain;
}

.no-touch {
    pointer-events: none;
}
.no-touch:before {
    content: "";width: 100%;height: 130%;background-color: rgba(250,250,250,0.4);position: absolute;z-index: 99;
}
.thumb-image {
   background-image: url(/cosmic/delivery/icons/camera.png) !important;
}
.read-only input,.read-only select,.read-only textarea,.read-only .nicEdit-main {
    border: none;cursor: text;pointer-events: none;
}
.read-only .reaction {
    display: none;
    
}
.read-only .upload-file {
    display: none;
    
}
.read-only .thumb-image {
    background-size: cover;cursor: auto;background-position: center;pointer-events: none;
}
.gallary-form table, .profile-form table,.input-form table {
    width: 70%;margin: 0 auto;
}
.profile-view form table td {
    width: 100%;height: 40px;padding-left: 25px;background-size: 20px;background-position: 3 center;background-repeat: no-repeat;
}
.upload-image {
    background-origin: content-box;background-repeat: no-repeat;background-position: center;cursor: pointer;background-size: contain;margin-bottom: 20px;position: relative;margin: 0 auto;
}
.upload-image:hover,.upload-video:hover {
    opacity: 0.6;
}
#selectedimage {
    height: 250px;width: 80%;
}
#caption,#profilename {
    background-image: url(../icons/tag.png);
}
#notes {
    background-image: url(../icons/text.png);
}
.fill{
    width: 100%;height: 100%;
/*    transition:all .5s ease-in;-webkit-transition:all .5s ease-in;-moz-transition:all .5s ease-in;-ms-transition:all .5s ease-in;-o-transition:all .5s ease-in;*/
}
    
input[type="text"] , input[type="password"], input[type="email"] {
    display: block;margin: 0px 0px;width: 100%; height: 30pt;position: relative;font-size: 18px;

}
textarea {
    display: block;border: 1px solid #ddd;resize: none;
    width: 100%;position: relative;height: 120px
    
}

/*
    RADIO BUTTON STYLES
*/
.row {
    width: 100%;height: auto;
}
.cols {
    width: 100%;height: auto;
    padding: 10px 0px;
    
}
.cols.two >.col {
    width: 45%;
    margin: 5px 1.5%;
    
}
.control {
    font-size: 18px;
	position: relative;
	display: block;
	margin-bottom: 15px;
/*	padding-left: 10px;*/
	cursor: pointer;
    color: #FFF;height: auto;
}
.control input {
	position: absolute;
	z-index: -1;
	opacity: 0;
}
.control__indicator {
	position: relative;
	top: 2px;
	left: 0;
}
.control__text{
    color: #2aa1c0;position: absolute;text-align: center;font-weight: bold;font-size: 18px;
    line-height: 1.23349;margin-top: 0;width: 100%;
}
/* Hover and focus states */
.control:hover input ~ .control__indicator,
.control input:focus ~ .control__indicator {
	border: 1px solid #2aa1c0;background-color: #2aa1c0;color: #fff;
}

/* Checked state */
.control input:checked ~ .control__indicator {
	border: 1px solid #2aa1c0;background-color: #2aa1c0;color: #fff; 
/*    background: #2aa1c0;*/
}

.control:hover input ~ .control__text,
.control input:focus ~ .control__text {
	color: #fff;
}

/* Checked state */
.control input:checked ~ .control__text {
	color: #fff; 
/*    background: #2aa1c0;*/
}
.control--radio .control__indicator {
/*	border-radius: 50%;*/
}
.who-toggle {
background:#00AFEF transparent;padding: 1px;
  color: #000;margin: 0 10 0 0; text-align: center;
  transition:all .3s ease-in;cursor: pointer;
  position: relative;font-weight: bold;height: 40px;
  border: 1px solid #2aa1c0;
    font-size: 20px;
    line-height: 1.23349;
}
.who-toggle.active {
border: 1px solid #5d5d5d;background-color: #5d5d5d;color: #fff;
}
.whoweare {
    position: relative;background-color:#4DBCEB transparent;padding: 10px 0px;height: auto;
   background-size:cover;background-repeat: no-repeat;overflow: auto;width: 440px;
    transition:all .3s ease-in;-webkit-transition:all .3s ease-in;-moz-transition:all .3s ease-in;-ms-transition:all .3s ease-in;-o-transition:all .3s ease-in;
}

/*
    SLIDER STYLES
*/
.preview-slider {
    width: 100%; height:auto;
  overflow: hidden;position: relative;z-index:0;top: 20;
}
.full-slider > ul, .preview-slider > ul {
   height: auto;overflow: auto;
    position: relative;left: 0;
    -webkit-transition: 0.5s left;
    -moz-transition: 0.5s left;
    -ms-transition: 0.5s left;
    -o-transition: 0.5s left;
    transition: 0.5s left;
    list-style: none;
    margin: 0; padding: 0;
  }
  ul {
    list-style: none;padding: 0;
}
.preview-slider > ul > li {
      float: left;margin: 0 0px;
      width: 100%; height: auto;overflow: hidden;
    }
  
</style>
</head>
    
<body class="">

    
    <section class="row " style="margin-top: 50px;" id="control_content">       
                                   
          <div class="profile-view" id="applyform" style="width: auto;"> 

                   <form name="inputform" class="input-form " enctype="multipart/form-data" >                              

                       <table>
                           
                           <tr><td id="title" >Mobile Money/Account Number</td></tr>
                           <tr><td><input type="text" name="mm_number" style="display:block;" class="round-10" value="" />


                               </td>
                           </tr>
                           
                            <tr><td id="title" >Mobile Money Network</td></tr>
                            <tr >
                                <td id="mm_net_det" colspan="2">
                                    <select type="text" name="mm_network" class="round-5" >                                       
                                        <option value="mtn"  >MTN</option>
                                        <option value="voda" >Vodafone</option>
                                        <option value="tigo" >Tigo</option>
                                        <option value="airtel" >Airtel</option>
                                    </select>
                                </td>
                            </tr>
                            <span id="voda_token" class="hidden">
                                <tr><td id="title" >Token number</td></tr>
                                <tr><td><input type="text" name="token" style="display:block;" class="round-10" value=""/>


                                    </td>
                                </tr>
                            </span>
                            
                           <tr><td id="title" >Account name</td></tr>
                           <tr><td><input type="text" name="mm_name" style="display:block;" class="round-10" value=""/>


                               </td>
                           </tr>

                       </table>
                   </form> 
              
                   <span style="display: table-cell;"><div class="send-button round-5" role="button" id="pay" data-post="<?php echo Controller::$page['search']; ?>"> Pay </div></span>
               </div>
    
    </section>    
    

<script type="text/javascript" >
    
 function post(url, data, callback) {
          var req = new XMLHttpRequest();
          req.open("POST", url, true);
          req.onload= function() {
            if (req.status === 200){
                if(req.responseText===""){callback(null,new Error("Empty response"));}else
                {callback(req.responseText);}
            } else
              callback(null, new Error("Request failed: " + req.statusText));
          };
          req.addEventListener("error", function() {
            callback(null, new Error("Network error"));
          });
             req.addEventListener("abort", function() {
            callback(null, new Error("Request Cancelled"));
          });

             req.addEventListener("timeout", function() {
            callback(null, new Error("Request taking too long"));
          });

          req.setRequestHeader("Content-type","application/x-www-form-urlencoded");
          req.send(data);
    };

 
 function processTransaction(){
        var pay_form = document.forms[0];
        var fdata = new FormData(pay_form),
            data = [];

        for (var value of fdata.keys()) {

            if(fdata.get(value)!="") {

                data.push(value+'='+fdata.get(value));

                }
           }
           
        var recentid = first_row.getAttribute('data-id');
        
        
        post('http://eprepaid.origgin.net/payments/pay_mazzuma/'+recentid,data.join('&'),function(s,f){
            if(s!==null) {
                        try{
                            var json = JSON.parse(s);
                            if(json.status === "ok" && typeof json.data === "object" && json.data.length>0){
                                addRecentToList(json.data);
                                if(recentid==null){
                                    table_body.removeChild(first_row);
                                }
                                    
                            }  
                        }catch(ex) {
                           console.log(ex);
                        }                        
                        
                    } else {
                        console.log(f);
                    }
        });
    }


 
    
</script>
</body>

</html>