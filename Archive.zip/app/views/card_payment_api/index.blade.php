<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<head><title>Virtual Payment Client Example</title>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>
<style type='text/css'>
    <!--
    h1       { font-family:Arial,sans-serif; font-size:24pt; color:#08185A; font-weight:100}
    h2.co    { font-family:Arial,sans-serif; font-size:24pt; color:#08185A; margin-top:0.1em; margin-bottom:0.1em; font-weight:100}
    h3.co    { font-family:Arial,sans-serif; font-size:16pt; color:#000000; margin-top:0.1em; margin-bottom:0.1em; font-weight:100}
    body     { font-family:Verdana,Arial,sans-serif; font-size:10pt; color:#08185A background-color:#FFFFFF }
    TR       { height:25px; }
    TR.shade { height:25px; background-color:#E1E1E1 }
    TR.title { height:25px; background-color:#C1C1C1 }
    P.blue   { font-family:Verdana,Arial,sans-serif; font-size:7pt;  color:#08185A }
    p        { font-family:Verdana,Arial,sans-serif; font-size:10pt; color:#FFFFFF }
    p.bl     { font-family:Verdana,Arial,sans-serif; font-size:8pt; color:#08185A }
    a:link   { font-family:Verdana,Arial,sans-serif; font-size:8pt; color:#08185A }
    a:visited{ font-family:Verdana,Arial,sans-serif; font-size:8pt; color:#08185A }
    a:hover  { font-family:Verdana,Arial,sans-serif; font-size:8pt; color:#FF0000 }
    a:active { font-family:Verdana,Arial,sans-serif; font-size:8pt; color:#FF0000 }
    td       { font-family:Verdana,Arial,sans-serif; font-size:8pt; color:#08185A }
    th       { font-family:Verdana,Arial,sans-serif; font-size:10pt; color:#08185A; font-weight:bold; background-color:#E1E1E1; padding-top:0.5em; padding-bottom:0.5em}
    input    { font-family:Verdana,Arial,sans-serif; font-size:8pt; color:#08185A; background-color:#E1E1E1; font-weight:bold }
    select   { font-family:Verdana,Arial,sans-serif; font-size:8pt; color:#08185A; background-color:#E1E1E1; font-weight:bold }
    textarea { font-family:Verdana,Arial,sans-serif; font-size:8pt; color:#08185A; background-color:#E1E1E1; font-weight:normal; scrollbar-arrow-color:#08185A; scrollbar-base-color:#E1E1E1 }
    -->
</style></head>
<body>

    <!-- branding table -->
<table width='100%' border='2' cellpadding='2' bgcolor='#C1C1C1'><tr><td bgcolor='#E1E1E1' width='90%'><h2 class='co'>&nbsp;Virtual Payment Client Example</h2></td><td bgcolor='#C1C1C1' align='center'><h3 class='co'>MIGS</h3></td></tr></table>
	<center><h1>PHP 2.5 Party (MerchantHosted Authenticate and Pay) Example</H1></center>
</table>
	
<!-- The "Pay Now!" button submits the form, transferring control -->
{{ Form::open(array('url' => 'payment_try')) }}
	<table width="80%" align="center" border="0" cellpadding='0' cellspacing='0'>
    <tr class="shade">
        <td align="right"><strong><em>Virtual Payment Client URL:&nbsp;</em></strong></td>
        <td><input name="virtualPaymentClientURL" size="65" value="https://migs.mastercard.com.au/vpcpay" maxlength="250"/></td>
    </tr>
    <tr><td colspan="2">&nbsp;<hr width="75%">&nbsp;</td></tr>
    <tr class="title">
                        <td colspan="2" style="text-align: left"><p>&nbsp;<strong>Transaction Fields</strong></p></td>
                    </tr>
					<tr class="shade">
						<td align="right"><strong><em> VPC Version: </em></strong></td>
						<td><input name="vpc_Version" value="1" size="20" maxlength="8"/></td>
					</tr>
                    <tr>

                        <td style="text-align: right"><strong><em>Command:</em></strong></td>
                        <td style="text-align: left"><input name="vpc_Command" type="text" value="pay" id="vpc_Command" /></td>
                    </tr>
					 <tr class="shade">
						<td align="right"><strong><em>MerchantID: </em></strong></td>
						<td><input name="vpc_Merchant" value="" size="20" maxlength="16"/></td>
					</tr>
					<tr>
						<td align="right"><strong><em>Merchant AccessCode: </em></strong></td>
						<td><input name="vpc_AccessCode" value="" size="20" maxlength="8"/></td>
					</tr>
                    <tr class="shade">
                        <td style="text-align: right"><strong><em>Merchant Transaction Reference:</em></strong></td>
                        <td style="text-align: left"><input name="vpc_MerchTxnRef" type="text" id="vpc_MerchTxnRef" /></td>
                    </tr>
                    <tr>

                        <td style="text-align: right"><strong><em>OrderInfo:</em></strong></td>
                        <td style="text-align: left"><input name="vpc_OrderInfo" type="text" id="vpc_OrderInfo" /></td>
                    </tr>
                    <tr class="shade">
                        <td style="text-align: right"><strong><em>Purchase Amount:</em></strong></td>
                        <td style="text-align: left"><input name="vpc_Amount" type="text" id="vpc_Amount" /></td>
                    </tr>
                    <tr>

                        <td style="text-align: right"><strong><em>Currency (optional field):</em></strong></td>
                        <td style="text-align: left"><input name="vpc_Currency" type="text" id="vpc_Currency" /></td>
                    </tr>
                    <tr class="shade">
                        <td style="text-align: right"><strong><em>TicketNo (optional field):</em></strong></td>
                        <td style="text-align: left"><input name="vpc_TicketNo" type="text" id="vpc_TicketNo" /></td>
                    </tr>
					    <tr>
        <td align="right"><strong><em>Receipt ReturnURL: </em></strong></td>
        <td><input name="vpc_ReturnURL" size="65" value="PHP_VPC_3DS 2.5 Party_DR.php" maxlength="250"/></td>
    </tr>
                    <tr class="shade">

                        <td style="text-align: right"><strong><em>Gateway:</em></strong></td>
                        <td style="text-align: left">
                            <select name="vpc_Gateway" id="vpc_Gateway">
		<option value="ssl">Auth-Purchase with 3DS Authentication</option>
		<option value="threeDSecure">3DS Authentication Only</option>

	</select></td>                       
                    </tr>

                    <tr><td colspan="2">&nbsp;<hr width="75%"/>&nbsp;</td></tr>

                    <tr class="title">
                        <td colspan="2" style="text-align: left"><p><strong>&nbsp;Optional Card Details (Requires External Payment Selection)</strong></p></td>
                    </tr>
                    <tr>
                        <td style="text-align: right"><strong><em>Card Type:</em></strong></td>
                        <td style="text-align: left">

                            <select name="vpc_card" id="vpc_card">
		<option value="">Please Select</option>
		<option value="Mastercard">Mastercard</option>
		<option value="Visa">Visa</option>
		<option value="Amex">American Express</option>
		<option value="AmexPurchaseCard">Amex Corporate Purchase Card</option>

		<option value="Dinersclub">Diners Club</option>

	</select>
                        </td>  
                    </tr>
                    <tr class="shade">
                        <td style="text-align: right"><strong><em>Card Number:</em></strong></td>
                        <td style="text-align: left"><input name="vpc_CardNum" type="text" id="vpc_CardNum" /></td>
                    </tr>

                    <tr>
                        <td style="text-align: right"><strong><em>Card Expiry Date (YYMM):</em></strong></td>
                        <td style="text-align: left"><input name="vpc_CardExp" type="text" id="vpc_CardExp" /></td>
                    </tr>
					<tr class="title">
        <td colspan="2"><p><b>&nbsp;Optional Card Security Code (CVV2) Field (Requires Card Details)</b></p></td>
    </tr>
    <tr>
        <td align="right"><strong><em>Card Security Code (CVV2): </em></strong></td>

        <td><input type="text" name="vpc_CardSecurityCode" maxlength="4" value=""/></td>
    </tr>
                    <tr>
                        <td width="40%">&nbsp; <input type="hidden" value="MIGS 2.5 Party Transaction" name="Title" </td>
                        <td width="60%">&nbsp;</td>
                    </tr>

                    <tr>
                        <td style="height: 21px" />
                        <td style="text-align: left; height: 21px"><input type="submit" name="btnPay" value="Pay Now!" id="btnPay" /></td>
                    </tr>

                    <tr><td colspan="2">&nbsp;<hr width="75%"/>&nbsp;</td></tr>


    <tr><td colspan="2">&nbsp;<hr width="75%">&nbsp;</td></tr>
    <tr>
        <td colspan="2">
        <p class='blue'><strong><em><u>Note</u>:</em></strong><br/>
        Any information passed through the customer's browser
        can potentially be modified by the customer, or even by third parties to
        fraudulently alter the transaction data. Therefore all transactional
        information should <strong>not</strong> be passed through the browser in
        a way that could potentially be modified (e.g. hidden form fields).
        Transaction data should only be accepted once from a browser at the
        point of input, and then kept in a way that does not allow others
        to modify it (e.g. database, server session, etc.). Any transaction
        information displayed to a customer, such as amount, should be passed
        only as display information and the actual transactional data should be
        retrieved from the secure source at the point of processing the transaction.<br><br>
        Fields like return links back to the order page (AgainLink), titles, and any other non-transactional information are only included here in the example for information purposes. They do not apply to the transaction and do not have be included in production code orders.
        </p>
        </td>
    </tr>

    <tr>
        <td width="40%">&nbsp;</td>
        <td width="60%">&nbsp;</td>
    </tr>
    </table>
  </form>
</body>
</html>
