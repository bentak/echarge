
@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">

	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">

    <div class="widget" style="overflow: auto;">
        <div class="widget-header">
            <i class="icon-list-alt"></i>
            <h3>Transactions </h3>
        </div>
        <!-- /widget-header -->
        <div class="widget-content">

            <table class="table" style="margin-bottom: 30px; margin-right: 10px; " id="translist">
                <thead>
          		<th>Date Time</th>
          		<!--<th>ID</th>-->
                        <th>Meter ID</th>
                        <th>Quota</th>
                        <th>Convenience Fee</th> 
                        <th>Meter Owner</th>
                        <th>Location</th>
                        <th>Customer</th>
                        <th>Partner</th>                       
                        <th>Payment Number</th>
                        <th>Request Type</th>
                        <th>Network</th>
          		<th style="text-align: center;">Action</th>
            </thead>
          	@foreach($transactions as $key=>$transaction)
                <tr data-id="{{$transaction->id}}">
                  <td>{{$transaction->created_at}}</td>
                  <!--<td>{{$transaction->transaction_id}}</td>-->
                  <td>{{$transaction->requst?$transaction->requst->meter_code:''}}</td>
                  <td>{{$transaction->ecg_amount}}</td>
                  <td>{{$transaction->origgin_charge}}</td>
                  <td>{{$transaction->requst?$transaction->requst->meter_owner:''}}</td>
                  <td>{{$transaction->location}}</td>
                  <td>{{$transaction->customer()?$transaction->customer():'-'}}</td>
                  <td>{{$transaction->partner()?$transaction->partner().'('.$transaction->branch().')':'-'}}</td>
                  <td>{{$transaction->pay_number}}</td>
                  <td>{{$transaction->requst?($transaction->requst->type_id==1?'Prepaid Credit':'Credit Balance'):'-'}}</td>
                  <td>{{$transaction->network}}</td>
                  
                  <td style="text-align: center;" class="dropdown">
                    <a title="Sold" href="{{URL::to('transactions/'.$transaction->id.'/add_as_sale')}}" class=""><i class="icon-check"></i></a>
                    <a title="Refund" href="{{URL::to('transactions/'.$transaction->id.'/add_as_refund')}}" class=""><i class="icon-retweet"></i></a>
                  </td>
                </tr>
            @endforeach
	        @if(count($transactions)<1)
                <tr id="nolist">
	          		<td colspan="9" style="text-align: center;">There are no transactions here yet.</td>
	          	</tr>
          @elseif(EcgStatus::currentStatus())
          <audio src="{{URL::asset('assets/sounds/beep-03.wav')}}" autoplay width="0" height="0" id="palyer" enablejavascript="true">
	        @endif
          </table>
      </div>
    </div>


  </div> <!-- /row -->

	    </div> <!-- /container -->

	</div> <!-- /main-inner -->

</div>
<!-- /main -->

<!-- start of footer -->
<div id="footer">
    <p>
      <center>
          <span class="text-white">
              Copyright &copy; <?= date('Y') ?> Origgin Ltd. All Rights Reserved.
          </span>
      </center>
    </p>
</div> <!-- /navbar-inner -->
<!-- /footer --> 
<!-- /footer -->
<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="assets/dashboard/js/jquery-1.7.2.min.js"></script>
<script src="assets/dashboard/js/excanvas.min.js"></script>
<script src="assets/dashboard/js/chart.min.js" type="text/javascript"></script>
<script src="assets/dashboard/js/bootstrap.js"></script>
<script src="assets/dashboard/js/base.js"></script>
<script type="text/javascript">
      setInterval(function(){
        location='';
      },3000);

      setTimeout(function(){
          PlaySound('palyer');
        },4000);
    </script>
</body>
</html>
