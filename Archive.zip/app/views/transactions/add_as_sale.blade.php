
@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">
    
    <div class="widget">
        <div class="widget-header" style="padding-right: 12px;">
            <i class="icon-list-alt"></i>
            <h3>Add Transaction as Sale </h3>
            <a href="{{URL::to('transactions')}}" class="pull-right"><i class="icon-list-alt"></i></a>
        </div>
        <!-- /widget-header -->
        <div class="widget-content">
        
          {{ Form::model($transaction, array('route' => array('post.transactions.add_as_sale', $transaction->id),'method' => 'PUT','class'=>'form-horizontal')) }}
                <!-- <form class="form-horizontal"> -->
                  <fieldset>
                    <legend>Form to register a sale after successfully delivering credit on ECG Portal</legend>
                    <div class="span5">
                      <div class="control-group">
                        <label class="control-label" for="focusedInput">Amount</label>
                        <div class="controls">
                          {{ Form::text('amount',Input::old('amount'),array('class'=>'input-xlarge focused','disabled'=>'disabled')) }}
                          <span class="help-inline">{{$errors->first('amount')}}</span>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label" for="focusedInput">Charge</label>
                        <div class="controls">
                          {{ Form::text('charges',Input::old('charges'),array('class'=>'input-xlarge focused','disabled'=>'disabled')) }}
                          <span class="help-inline">{{$errors->first('charges')}}</span>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label" for="focusedInput">Sum after Charge</label>
                        <div class="controls">
                          {{ Form::text('amount_after_charges',Input::old('amount_after_charges'),array('class'=>'input-xlarge focused','disabled'=>'disabled')) }}
                          <span class="help-inline">{{$errors->first('amount_after_charges')}}</span>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label" for="focusedInput">Request At</label>
                        <div class="controls">
                          {{ Form::text('requested_at',$transaction->requst->created_at,array('class'=>'input-xlarge focused','disabled'=>'disabled')) }}
                          <span class="help-inline">{{$errors->first('requested_at')}}</span>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label" for="focusedInput">Paid At</label>
                        <div class="controls">
                          {{ Form::text('created_at',Input::old('created_at'),array('class'=>'input-xlarge focused','disabled'=>'disabled')) }}
                          <span class="help-inline">{{$errors->first('created_at')}}</span>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label" for="focusedInput">Vendor</label>
                        <div class="controls">
                          {{ Form::select('vendor_id', Vendor::lists('name', 'id'), Input::old('vendor_id'),array('class'=>'input-xlarge focused')) }}
                          <span class="help-inline">{{$errors->first('vendor_id')}}</span>
                        </div>
                      </div>
                    </div>
                    <div class="span6">
                      <div class="control-group">
                        <label class="control-label" for="focusedInput">Meter Code</label>
                        <div class="controls">
                          {{ Form::text('meter_code',$transaction->requst->meter_code,array('class'=>'input-xlarge focused','disabled'=>'disabled')) }}
                          <span class="help-inline">{{$errors->first('meter_code')}}</span>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label" for="focusedInput">Meter Owner</label>
                        <div class="controls">
                          {{ Form::text('meter_owner',$transaction->requst->meter_owner,array('class'=>'input-xlarge focused','disabled'=>'disabled')) }}
                          <span class="help-inline">{{$errors->first('meter_owner')}}</span>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label" for="focusedInput">Location</label>
                        <div class="controls">
                          {{ Form::text('location',$transaction->requst->location,array('class'=>'input-xlarge focused','disabled'=>'disabled')) }}
                          <span class="help-inline">{{$errors->first('location')}}</span>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label" for="focusedInput">Transaction ID</label>
                        <div class="controls">
                          {{ Form::text('transaction_id',Input::old('transaction_id'),array('class'=>'input-xlarge focused','disabled'=>'disabled')) }}
                          <span class="help-inline">{{$errors->first('transaction_id')}}</span>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label" for="focusedInput">Response Code</label>
                        <div class="controls">
                          {{ Form::text('response_code',Input::old('response_code'),array('class'=>'input-xlarge focused','disabled'=>'disabled')) }}
                          <span class="help-inline">{{$errors->first('response_code')}}</span>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label" for="focusedInput">Client Reference</label>
                        <div class="controls">
                          {{ Form::text('client_refrence',Input::old('client_refrence'),array('class'=>'input-xlarge focused','disabled'=>'disabled')) }}
                          <span class="help-inline">{{$errors->first('client_refrence')}}</span>
                        </div>
                      </div>
                    </div><div class="clearfix"></div>
                    <div class="form-actions">
                      <button type="submit" class="btn btn-primary">Add As Sale</button>
                      <button type="reset" class="btn">Cancel</button>
                    </div>
                  </fieldset>
                <!-- </form> -->
          {{ Form::close() }}
        
        </div>
    </div>
      
    
  </div> <!-- /row -->
	
	    </div> <!-- /container -->
    
	</div> <!-- /main-inner -->
	    
</div>
<!-- /main -->

<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="span12"> &copy; {{date('Y')}} <a href="http://www.origgin.net/">Origgin</a>. </div>
        <!-- /span12 --> 
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /footer-inner --> 
</div>
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="{{URL::asset('assets/dashboard/js/jquery-1.7.2.min.js')}}"></script> 
<script src="{{URL::asset('assets/dashboard/js/excanvas.min.js')}}"></script> 
<script src="{{URL::asset('assets/dashboard/js/chart.min.js')}}" type="text/javascript"></script> 
<script src="{{URL::asset('assets/dashboard/js/bootstrap.js')}}"></script>
<script language="javascript" type="text/javascript" src="{{URL::asset('assets/dashboard/js/full-calendar/fullcalendar.min.js')}}"></script>
 
<script src="{{URL::asset('assets/dashboard/js/base.js')}}"></script>
</body>
</html>
