
@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">
    
    <div class="widget">
        <div class="widget-header">
            <i class="icon-list-alt"></i>
            <h3>
                Partner Topups (From {{date('l, M d, Y',strtotime($from))}} to {{date('l, M d, Y',strtotime($to))}}
            </h3>
             <span class="pull-right">
              From: <input id="from_date" class="form-control" value="{{$from}}" type="date" onchange="remakeDate();"> To: <input id="to_date" class="form-control" value="{{$to}}" type="date" onchange="remakeDate();"><input type="hidden" name="date_str" id="date_str"> <button class="btn btn-success btn-sm" onclick="doSubmit();">Go</button>
            </span>
        </div>
        <!-- /widget-header -->
        <div class="widget-content">
        
          <table class="table">
          	<tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Partner Name</th>
                    <th>Amount Paid</th>
                    <th>Quota</th>
                    <th>Quota Before</th>
                    <th>Quota After</th>
                    <th>Partner Comm.</th>
                    <th>Vendor Comm.</th>
                    <th>Origgin Comm.</th>
          	</tr>
          	@foreach($topups as $key=>$branch)
	          	<tr>
                            <td><a href="{{URL::to('topups/edit').'/'.$branch->id}}">{{$branch->id}}</a></td>
                            <td>{{$branch->created_at}}</td>
                            <td>{{$branch->partner?$branch->partner->partner_name:''}}</td>
                            <td>{{number_format($branch->amount_paid,2)}}</td>
                            <td>{{number_format($branch->ecg_quota,2)}}</td>
                            <td>{{number_format($branch->before_topup,2)}}</td>
                            <td>{{number_format($branch->after_topup,2)}}</td>
                            <td>{{number_format($branch->partner_commission,2)}}</td>
                            <td>{{number_format($branch->vendor_commission,2)}}</td>
                            <td>{{number_format($branch->origgin_commission,2)}}</td>
	          	</tr>
	        @endforeach
	        @if(count($topups)<1)
	        	<tr>
	          		<td colspan="5" style="text-align: center;">There are no top ups here yet.</td>
	          	</tr>
	        @endif
          </table>
        
      </div>
    </div>
      
    
  </div> <!-- /row -->
	
	    </div> <!-- /container -->
    
	</div> <!-- /main-inner -->
	    
</div>
<!-- /main -->

<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="span12"> &copy; {{date('Y')}} <a href="http://www.origgin.net/">Origgin</a>. </div>
        <!-- /span12 --> 
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /footer-inner --> 
</div>
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="{{ URL::asset('assets/dashboard/js/jquery-1.7.2.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/excanvas.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/chart.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/dashboard/js/bootstrap.js') }}"></script>
<script language="javascript" type="text/javascript" src="{{ URL::asset('assets/dashboard/js/full-calendar/fullcalendar.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/base.js') }}"></script>

<script>     
   
 function remakeDate(){
    $('#date_str').val('/'+$('#from_date').val()+'/'+$('#to_date').val());
  }

  function doSubmit(){
    window.location.href = 'http://eprepaid.origgin.net/topups/records'+$('#date_str').val();
  }
       
</script><!-- /Calendar -->
</body>
</html>
