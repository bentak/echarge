
@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">
    
    <div class="widget">
        <div class="widget-header">
            <i class="icon-list-alt"></i>
            <h3>
                Add New User
            </h3>
            
             <span class="pull-right">
                <button class="btn btn-success btn-sm" onclick="doSubmit();">Go</button>
            </span>
        </div>
        <!-- /widget-header -->
        <div class="widget-content">
        
          <div class="profile-view " >
                             
            <form name="inputform" class="input-form" enctype="multipart/form-data">
                 <table>
                     <tr><td >User Name</td></tr>
                     <tr><td><input type="text" name="user_name" placeholder="name for loging in"  /></td></tr>
                     
                     <tr><td >Contact</td></tr>
                     <tr><td><input type="text" name="user_phone" placeholder="contact number"  /></td></tr>
                     
                     <tr><td >Password</td></tr>
                     <tr><td><input type="password" name="user_password" placeholder="" /></td></tr>
                     
                     <tr><td >Partner</td></tr>
                     <tr><td>
                             <select type="text" name="branch_partner" placeholder="Partner name"  > 
                                 @foreach($partners as $key=>$partner)
                                 <option value="{{$partner->id}}"> {{$partner->partner_name}} </option>          		
	          	
                                 @endforeach
                             </select>
                         </td>
                     </tr> 
                     <tr><td >Branch</td></tr>
                     <tr><td>
                             <select type="text" name="branch_partner" placeholder="Partner name"  > 
                                 @foreach($branches as $key=>$branch)
                                 <option value="{{$branch->branch_id}}"> {{$branch->branch_name}} </option>          		
	          	
                                 @endforeach
                             </select>
                         </td>
                     </tr>                    
                     
                </table>
            </form>
        </div>
        
      </div>
    </div>
      
    
  </div> <!-- /row -->
	
	    </div> <!-- /container -->
    
	</div> <!-- /main-inner -->
	    
</div>
<!-- /main -->

<!-- start of footer -->
<div id="footer">
    <p>
      <center>
          <span class="text-white">
              Copyright &copy; <?= date('Y') ?> Origgin Ltd. All Rights Reserved.
          </span>
      </center>
    </p>
</div> <!-- /navbar-inner -->
<!-- /footer --> 
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="{{ URL::asset('assets/dashboard/js/jquery-1.7.2.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/excanvas.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/chart.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/dashboard/js/bootstrap.js') }}"></script>
<script language="javascript" type="text/javascript" src="{{ URL::asset('assets/dashboard/js/full-calendar/fullcalendar.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/base.js') }}"></script>
<script>
    
    function remakeDate(){
    $('#date_str').val('/'+$('#from_date').val()+'/'+$('#to_date').val());
  }

  function doSubmit(){
    var create_form = document.forms['inputform'];
    var form_data = new FormData(create_form),
        input_data = [];

    for (var value of form_data.keys()) {

        if(form_data.get(value)!="") { 
            input_data.push(value+'='+form_data.get(value));
        }
    }
        
    //var runat = this.sendButton.getAttribute('data-post');
      
    window.location.href = 'http://eprepaid.origgin.net/branches/store?'+input_data.join('&');
    
  }


</script><!-- /Calendar -->
</body>
</html>
