
@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">
    
    <div class="widget">
        <div class="widget-header">
            <i class="icon-list-alt"></i>
            <h3>
                Partner User Accounts</h3>
        </div>
        <!-- /widget-header -->
        <div class="widget-content">
        
          <table class="table">
          	<tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Partner</th>
                    <th>Branch</th> 
                    <th>Location</th> 
                    <th>Date</th>
                   
          	</tr>
          	@foreach($users as $key=>$user)
	          	<tr>
	          		<td>{{$user->user_id}}</td>
	          		<td>{{$user->user_name}}</td>
	          		<td>{{$user->partner?$user->partner->partner_name:''}}</td>
	          		<td>{{$user->branch?$user->branch->branch_name:''}}</td>
	          		<td>{{$user->branch?$user->branch->branch_location:''}}</td>
	          		<td>{{$user->created_at}}</td>
	          	</tr>
	        @endforeach
	        @if(count($users)<1)
	        	<tr>
	          		<td colspan="5" style="text-align: center;">There are no users here yet.</td>
	          	</tr>
	        @endif
          </table>
        
      </div>
    </div>
      
    
  </div> <!-- /row -->
	
	    </div> <!-- /container -->
    
	</div> <!-- /main-inner -->
	    
</div>
<!-- /main -->

<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="span12"> &copy; {{date('Y')}} <a href="http://www.origgin.net/">Origgin</a>. </div>
        <!-- /span12 --> 
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /footer-inner --> 
</div>
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="assets/dashboard/js/jquery-1.7.2.min.js"></script> 
<script src="assets/dashboard/js/excanvas.min.js"></script> 
<script src="assets/dashboard/js/chart.min.js" type="text/javascript"></script> 
<script src="assets/dashboard/js/bootstrap.js"></script>
<script language="javascript" type="text/javascript" src="assets/dashboard/js/full-calendar/fullcalendar.min.js"></script>
 
<script src="assets/dashboard/js/base.js"></script> 
<script>     

        var lineChartData = {
            labels: ["{{date('M', strtotime('-6 month'))}}", "{{date('M', strtotime('-5 month'))}}", "{{date('M', strtotime('-4 month'))}}", "{{date('M', strtotime('-3 month'))}}", "{{date('M', strtotime('-2 month'))}}", "{{date('M', strtotime('-1 month'))}}", "{{date('M')}}"],
            datasets: [
                {
                    fillColor: "rgba(220,0,220,0.5)",
                    strokeColor: "rgba(220,0,220,0.9)",
                    pointColor: "rgba(220,0,220,1)",
                    pointStrokeColor: "#ffffff",
                    data: [8, 29, 60, 81, 56, 95, 140]
                },
                {
                    fillColor: "rgba(20,0,220,0.5)",
                    strokeColor: "rgba(20,0,220,0.9)",
                    pointColor: "rgba(20,0,220,1)",
                    pointStrokeColor: "#ffffff",
                    data: [5, 9, 60, 101, 126, 115, 170]
                },
                {
                    fillColor: "rgba(151,187,205,0.5)",
                    strokeColor: "rgba(151,187,205,1)",
                    pointColor: "rgba(151,187,205,1)",
                    pointStrokeColor: "#ffffff",
                    data: [28, 48, 40, 19, 96, 27, 100]
                }
            ]

        }

        var myLine = new Chart(document.getElementById("area-chart").getContext("2d")).Line(lineChartData);


        var barChartData = {
            labels: ["January", "February", "March", "April", "May", "June", "{{date('M')}}"],
            datasets: [
                {
                    fillColor: "rgba(220,220,220,0.5)",
                    strokeColor: "rgba(220,220,220,1)",
                    data: [65, 59, 90, 81, 56, 55, 40]
                },
                {
                    fillColor: "rgba(151,187,205,0.5)",
                    strokeColor: "rgba(151,187,205,1)",
                    data: [28, 48, 40, 19, 96, 27, 100]
                }
            ]

        }    

        $(document).ready(function() {
        var date = new Date();
        var d = date.getDate();
        var m = date.getMonth();
        var y = date.getFullYear();
        var calendar = $('#calendar').fullCalendar({
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
          },
          selectable: true,
          selectHelper: true,
          select: function(start, end, allDay) {
            var title = prompt('Event Title:');
            if (title) {
              calendar.fullCalendar('renderEvent',
                {
                  title: title,
                  start: start,
                  end: end,
                  allDay: allDay
                },
                true // make the event "stick"
              );
            }
            calendar.fullCalendar('unselect');
          },
          editable: true,
          events: [
            {
              title: 'All Day Event',
              start: new Date(y, m, 1)
            },
            {
              title: 'Long Event',
              start: new Date(y, m, d+5),
              end: new Date(y, m, d+7)
            },
            {
              id: 999,
              title: 'Repeating Event',
              start: new Date(y, m, d-3, 16, 0),
              allDay: false
            },
            {
              id: 999,
              title: 'Repeating Event',
              start: new Date(y, m, d+4, 16, 0),
              allDay: false
            },
            {
              title: 'Meeting',
              start: new Date(y, m, d, 10, 30),
              allDay: false
            },
            {
              title: 'Lunch',
              start: new Date(y, m, d, 12, 0),
              end: new Date(y, m, d, 14, 0),
              allDay: false
            },
            {
              title: 'Birthday Party',
              start: new Date(y, m, d+1, 19, 0),
              end: new Date(y, m, d+1, 22, 30),
              allDay: false
            },
            {
              title: 'EGrappler.com',
              start: new Date(y, m, 28),
              end: new Date(y, m, 29),
              url: 'http://EGrappler.com/'
            }
          ]
        });
      });
    </script><!-- /Calendar -->
</body>
</html>
