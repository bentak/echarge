
@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">
    
    <div class="widget">
        <div class="widget-header">
            <i class="icon-list-alt"></i>
            <h3>
                Partners (From {{date('l, M d, Y',strtotime($from))}} to {{date('l, M d, Y',strtotime($to))}})
            </h3>
            
             <span class="pull-right">
              From: <input id="from_date" class="form-control" value="{{$from}}" type="date" onchange="remakeDate();"> To: <input id="to_date" class="form-control" value="{{$to}}" type="date" onchange="remakeDate();"><input type="hidden" name="date_str" id="date_str"> <button class="btn btn-success btn-sm" onclick="doSubmit();">Go</button>
            </span>
        </div>
        <!-- /widget-header -->
        <div class="widget-content">
        
          <table class="table">
          	<tr>
          		<th>Since</th>
          		<th>ID</th>
          		<th>Partner Name</th>
                        <th>Phone</th>
          		<th>Email</th>
          		<th>Balance</th>
          		<th>Reseller</th>
          		<th>API Key</th>
          	</tr>
                
                <?php                   
                  $total_number = 0;                
                ?>
                
          	@foreach($partners as $key=>$partner)
	          	<tr>
	          		<td>{{$partner->created_at}}</td>
	          		<td>{{$partner->id}}</td>
	          		<td>{{$partner->partner_name}}</td>
                                <td>{{$partner->partner_phone}}</td>
                                <td>{{$partner->partner_email}}</td>
                                <td>{{$partner->quota_bal}}</td>                                	          		
                            <td style="text-align: center;">                               
                                <a title="" class="">{{$partner->is_reseller==1?'YES':'NO'}}</a>
                            </td>
                            <td>{{$partner->api_key}}</td>
	          	</tr>
                        
                         <?php 
                        
                        $total_number++;
                        ?>
	        @endforeach
	        @if(count($partners)<1)
	        	<tr>
	          		<td colspan="5" style="text-align: center;">There are no Partners here yet.</td>
	          	</tr>
                        
                        @else
                <tr>
                  <th style="text-align: center;" colspan="3">Total</th>
                  <th>{{$total_number}} <?php echo $total_number==1?" Partner":" Partners" ?></th>
                  <th></th>
                  <th></th>                 
                  <th></th>
                </tr>
	        @endif
          </table>
        
      </div>
    </div>
      
    
  </div> <!-- /row -->
	
	    </div> <!-- /container -->
    
	</div> <!-- /main-inner -->
	    
</div>
<!-- /main -->

<!-- start of footer -->
<div id="footer">
    <p>
      <center>
          <span class="text-white">
              Copyright &copy; <?= date('Y') ?> Origgin Ltd. All Rights Reserved.
          </span>
      </center>
    </p>
</div> <!-- /navbar-inner -->
<!-- /footer --> 
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="{{ URL::asset('assets/dashboard/js/jquery-1.7.2.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/excanvas.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/chart.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/dashboard/js/bootstrap.js') }}"></script>
<script language="javascript" type="text/javascript" src="{{ URL::asset('assets/dashboard/js/full-calendar/fullcalendar.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/base.js') }}"></script>

<script>
    
 function remakeDate(){
    $('#date_str').val('/'+$('#from_date').val()+'/'+$('#to_date').val());
  }

  function doSubmit(){
    window.location.href = 'http://eprepaid.origgin.net/partners/records'+$('#date_str').val();
  }

    </script><!-- /Calendar -->
</body>
</html>
