
@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">
    
    <div class="widget">
        <div class="widget-header">
            <i class="icon-list-alt"></i>
            <h3>
                Add Partner
            </h3>
            
             <span class="pull-right">
                <button class="btn btn-success btn-sm" onclick="doSubmit();">Go</button>
            </span>
        </div>
        <!-- /widget-header -->
        <div class="widget-content">
        
          <div class="profile-view " >
                             
            <form name="inputform" class="input-form" enctype="multipart/form-data">
                 <table>
                     <tr><td id="caption">Name</td></tr>
                     <tr><td><input type="text" name="partner_name" placeholder="Company Name"  /></td></tr>
                     
                     <tr><td >Email</td></tr>
                     <tr><td><input type="text" name="partner_email" placeholder="Email Address"  /></td></tr>
                     <tr><td >Phone</td></tr>
                     <tr><td><input type="text" name="partner_phone" placeholder="Contact No."  /></td></tr>                    
                     <tr><td><input type="hidden" name="api_key" placeholder="API Key" value="{{Partner::createToken()}}" /></td></tr>
                     <tr><td >Reseller</td></tr>
                     <tr><td><input type="checkbox" name="is_reseller" /></td></tr>
                     
                     <tr><td >Username</td></tr>
                     <tr><td><input type="text" name="user_name" placeholder="username"  /></td></tr>

                     <tr><td id="title" >Password</td></tr>
                     <tr><td><input type="text" name="user_password" placeholder="password"/></td></tr>
                    
                </table>
            </form>
        </div>
        
      </div>
    </div>
      
    
  </div> <!-- /row -->
	
	    </div> <!-- /container -->
    
	</div> <!-- /main-inner -->
	    
</div>
<!-- /main -->

<!-- start of footer -->
<div id="footer">
    <p>
      <center>
          <span class="text-white">
              Copyright &copy; <?= date('Y') ?> Origgin Ltd. All Rights Reserved.
          </span>
      </center>
    </p>
</div> <!-- /navbar-inner -->
<!-- /footer --> 
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="{{ URL::asset('assets/dashboard/js/jquery-1.7.2.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/excanvas.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/chart.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/dashboard/js/bootstrap.js') }}"></script>
<script language="javascript" type="text/javascript" src="{{ URL::asset('assets/dashboard/js/full-calendar/fullcalendar.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/base.js') }}"></script>
<script>
    
    function remakeDate(){
    $('#date_str').val('/'+$('#from_date').val()+'/'+$('#to_date').val());
  }

  function doSubmit(){
    var create_form = document.forms["inputform"];
    var form_data = new FormData(create_form),
        input_data = [];

    for (var value of form_data.keys()) {

        if(form_data.get(value)!="") { 
            input_data.push(value+'='+form_data.get(value));
        }
    }
        
    //var runat = this.sendButton.getAttribute('data-post');
      
    window.location.href = 'http://eprepaid.origgin.net/partners/add?'+input_data.join('&');
    //window.location.href = 'http://localhost/eprepaid/public/partners/add?'+input_data.join('&');
  }


</script><!-- /Calendar -->
</body>
</html>
