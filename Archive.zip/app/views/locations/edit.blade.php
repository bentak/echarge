
@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">
    
    <div class="widget">
        <div class="widget-header">
            <i class="icon-list-alt"></i>
            <h3>
                Edit Location
            </h3>
            
             <span class="pull-right">
                <button class="btn btn-success btn-sm" onclick="doSubmit();">Go</button>
            </span>
        </div>
        <!-- /widget-header -->
        <div class="widget-content">
        
          <div class="profile-view " >
                             
            <form name="inputform" class="input-form" enctype="multipart/form-data">
                 <table>
                     <tr><td >Name</td></tr>
                     <tr><td><input type="text" name="name" placeholder="location name" id="loc_name" value="{{$location->name}}"  /></td></tr>
                     
                     <tr><td >Description</td></tr>
                     <tr><td><input type="text" name="description" placeholder="location description" id="quota_input"  value="{{$location->description}}" /></td></tr>
                     
                     <tr><td >Region</td></tr>
                     <tr><td>
                             <select type="text" name="region_id"  > 
                                 @foreach($regions as $key=>$region)                                          		
                                   <option value="{{$region->id}}" {{$region->id==$location->region_id?'selected':''}} > {{$region->description}} </option>
                                 @endforeach
                             </select>
                         </td>
                     </tr>                              
                    
                </table>
            </form>
        </div>
        
      </div>
    </div>
      
    
  </div> <!-- /row -->
	
	    </div> <!-- /container -->
    
	</div> <!-- /main-inner -->
	    
</div>
<!-- /main -->

<!-- start of footer -->
<div id="footer">
    <p>
      <center>
          <span class="text-white">
              Copyright &copy; <?= date('Y') ?> Origgin Ltd. All Rights Reserved.
          </span>
      </center>
    </p>
</div> <!-- /navbar-inner -->
<!-- /footer --> 
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="{{ URL::asset('assets/dashboard/js/jquery-1.7.2.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/excanvas.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/chart.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/dashboard/js/bootstrap.js') }}"></script>
<script language="javascript" type="text/javascript" src="{{ URL::asset('assets/dashboard/js/full-calendar/fullcalendar.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/base.js') }}"></script>
<script>
    
    function remakeDate(){
    $('#date_str').val('/'+$('#from_date').val()+'/'+$('#to_date').val());
  }

  function doSubmit(){
    var create_form = document.forms['inputform'];
    var form_data = new FormData(create_form),
        input_data = [];

    for (var value of form_data.keys()) {

        if(form_data.get(value)!="") { 
            input_data.push(value+'='+form_data.get(value));
        }
    }
        
    //var runat = this.sendButton.getAttribute('data-post');
      
    window.location.href = 'http://eprepaid.origgin.net/locations/update/{{$location->id}}?'+input_data.join('&');
    //window.location.href = 'http://localhost/eprepaid/public/locations/update/{{$location->id}}?'+input_data.join('&');
    
  }


</script><!-- /Calendar -->
</body>
</html>
