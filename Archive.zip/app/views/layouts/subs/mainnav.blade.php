<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Portal | Origgin Prepaid</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="{{ URL::asset('assets/dashboard/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/dashboard/css/bootstrap-responsive.min.css') }}" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="{{ URL::asset('assets/dashboard/css/font-awesome.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/dashboard/css/style.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/dashboard/css/pages/dashboard.css') }}" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

<style>
.input-form table {
    width: 90%;margin: 0 auto;
}
.profile-view form table td {
    width: 100%;height: 40px;padding-left: 15px;background-size: 20px;background-position: 3px center;background-repeat: no-repeat;
}
input[type="text"] , input[type="password"], input[type="email"] {
    display: block;margin: 0px 0px;width: 100%; height: 30pt;position: relative;font-size: 18px;

}
</style>
</head>
<body>

<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand" href="{{URL::to('')}}">
                      {{ HTML::image("assets/dashboard/img/logo.png", "Logo") }} E-PREPAID
                    </a>
      <div class="nav-collapse">
        <ul class="nav pull-right" style="padding-top: 1em;">
          <li class="btn btn-{{EcgStatus::currentStatus()?'success':'danger'}} btn-sm"><a href="{{URL::to('ecg_status_toggle')}}" style="padding: 1px 10px 2px; margin:"><i class="icon-tag"></i><span> {{EcgStatus::currentStatus()?'SYSTEM ON':'SYSTEM OFF'}}</span> </a></li>
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-user"></i> {{Auth::user()? Auth::user()->email:'Welcome'}} <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="{{URL::to('logout')}}">Logout</a></li>
            </ul>
          </li>
        </ul>
        <!--<form class="navbar-search pull-right">
          <input type="text" class="search-query" placeholder="Search">
        </form>-->
      </div>
      <!--/.nav-collapse --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /navbar-inner --> 
</div>
<!-- /navbar -->

<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
        <li class="{{((isset($pagetab)&&$pagetab=='dashboard')?'active':'')}}"><a href="{{URL::to('')}}"><i class="icon-dashboard"></i><span>Dashboard</span> </a> </li>
        <!--<li class="{{((isset($pagetab)&&$pagetab=='denied')?'active':'')}}"><a href="{{URL::to('')}}"><i class="icon-list-alt"></i><span>Denied Requests</span> </a> </li>-->
        <li class="dropdown {{((isset($pagetab)&&$pagetab=='requests')?'active':'')}}">
            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
                <i class="icon-list-alt"></i><span>Requests</span> </a>
            <ul class="dropdown-menu">
                <li><a href="{{URL::to('requests')}}">Received</a></li>
                <li><a href="{{URL::to('denied_requests')}}">Denied</a></li>            
            </ul>
        </li>
        <li class="{{((isset($pagetab)&&$pagetab=='transactions')?'active':'')}}"><a href="{{URL::to('transactions')}}"><i class="icon-money"></i><span>Transactions</span> </a> </li>
        <li class="dropdown {{((isset($pagetab)&&$pagetab=='sales')?'active':'')}}">
            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
                <i class="icon-tag"></i><span>Sales</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="{{URL::to('sales')}}">All</a></li>
            <li><a href="{{URL::to('sales/today')}}">Today</a></li>
            <li><a href="{{URL::to('sales/for_period/'.date('Y-m-01').'/'.date('Y-m-d'))}}">For Period</a></li>
          </ul>
        </li>
        <li class="dropdown {{((isset($pagetab)&&$pagetab=='customers')?'active':'')}}">
            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
                <i class="icon-group"></i><span>Customers</span> <b class="caret"></b></a>
            <ul class="dropdown-menu">
            <li><a href="{{URL::to('customers')}}">All</a></li>
            <li><a href="{{URL::to('blocked_list')}}">Blocked</a></li>            
          </ul>
        </li>
        <li class="dropdown {{((isset($pagetab)&&$pagetab=='partners')?'active':'')}}">
            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-group"></i><span>Partners</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="{{URL::to('partners')}}">List</a></li>
            <li><a href="{{URL::to('branches')}}">Partner Branches</a></li>
            <li><a href="{{URL::to('partner_users')}}">Partner Users</a></li>
            <li><a href="{{URL::to('partners/create')}}">Add Partner</a></li>
          </ul>
        </li>
        <li class="dropdown {{((isset($pagetab)&&$pagetab=='topups')?'active':'')}}">
            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-group"></i><span>Credit Topup</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="{{URL::to('topups')}}">List</a></li>
            <li><a href="{{URL::to('topups/create')}}">Add Topup</a></li>
          </ul>
        </li>
        
        <!--<li class="{{((isset($pagetab)&&$pagetab=='blocked')?'active':'')}}"><a href="{{URL::to('blocked_list')}}"><i class="icon-group"></i><span> List</span> </a> </li>-->
        <!--<li class="{{((isset($pagetab)&&$pagetab=='enquiries')?'active':'')}}"><a href="{{URL::to('enquiries')}}"><i class="icon-comments"></i><span>Enquiries</span> </a> </li>-->
        <li class="dropdown {{((isset($pagetab)&&$pagetab=='location')?'active':'')}}"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-map-marker"></i><span>Locations</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="{{URL::to('ecg_regions')}}">ECG Regions</a></li>
            <li><a href="{{URL::to('locations')}}">Locations</a></li>
            <li><a href="{{URL::to('locations/create')}}">Add Location</a></li>
          </ul>
        </li>
        
        <li class="dropdown {{((isset($pagetab)&&$pagetab=='configurations')?'active':'')}}"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-cog"></i><span>Configurations</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="{{URL::to('#')}}">Vendors</a></li>
            <li><a href="{{URL::to('users')}}">Users</a></li>           
            <li><a href="{{URL::to('#')}}">Permission</a></li>
            <li><a href="{{URL::to('payment_services')}}">Payment Services</a></li>
          </ul>
        </li>
      </ul>
    </div>
    <!-- /container --> 
  </div>
  <!-- /subnavbar-inner --> 