<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dashboard</title>

    <!-- Bootstrap Core CSS -->
    <link href="{{ URL::asset('assets/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="{{ URL::asset('assets/metisMenu/metisMenu.min.css') }}" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="{{ URL::asset('assets/css/sb-admin-2.css') }}" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="{{ URL::asset('assets/morrisjs/morris.css') }}" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="{{ URL::asset('assets/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesnt work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Point of Sale</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> {{ucfirst(Auth::user()->username) . ' as ' . ucfirst(Auth::user()->type->name)}}  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="{{URL::to('user/profile')}}"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="{{URL::to('logout')}}"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search" style="width: 250px; height: 130px;">
                            
                        </li>
                        <li>
                            <a href="{{URL::to('') }}"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,4) || UserType::userTypeHasPermission(Auth::user()->user_type_id,3) || UserType::userTypeHasPermission(Auth::user()->user_type_id,8))
                        <li>
                            <a href="#"><i class="fa fa-users fa-fw"></i> Customers<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,4))
                                <li>
                                    <a href="{{URL::to('customers/create')}}">New Customer</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,3))
                                <li>
                                    <a href="{{URL::to('customers')}}">Customers' List</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,8))
                                <li>
                                    <a href="{{URL::to('customers/cash_in')}}">Add Cash</a>
                                </li>
                                @endif
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        @endif
                        @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,2) || UserType::userTypeHasPermission(Auth::user()->user_type_id,1))
                        <li>
                            <a href="#"><i class="fa fa-tags fa-fw"></i> Sales<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,2))
                                <li>
                                    <a href="{{URL::to('sales/create')}}">New Sale</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,1))
                                <li>
                                    <a href="{{URL::to('sales')}}">Sales Register</a>
                                </li>
                                @endif
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        @endif
                        @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,10) || UserType::userTypeHasPermission(Auth::user()->user_type_id,9) || UserType::userTypeHasPermission(Auth::user()->user_type_id,15))
                        <li>
                            <a href="{{URL::to('products')}}"><i class="fa fa-table fa-fw"></i> Inventory<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,10))<li>
                                    <a href="{{URL::to('products/create')}}">New Product</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,9))
                                <li>
                                    <a href="{{URL::to('products')}}">Products' List</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,15))
                                <li>
                                    <a href="{{URL::to('products/stock')}}">Stock</a>
                                </li>
                                @endif
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        @endif
                        @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,6) || UserType::userTypeHasPermission(Auth::user()->user_type_id,5))
                        <li>
                            <a href="{{URL::to('suppliers')}}"><i class="fa fa-truck fa-fw"></i> Suppliers<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,6))
                                <li>
                                    <a href="{{URL::to('suppliers/create')}}">New Supplier</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,5))
                                <li>
                                    <a href="{{URL::to('suppliers')}}">Suppliers' List</a>
                                </li>
                                @endif
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        @endif
                        @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,12) || UserType::userTypeHasPermission(Auth::user()->user_type_id,11) || UserType::userTypeHasPermission(Auth::user()->user_type_id,14) ||
                        UserType::userTypeHasPermission(Auth::user()->user_type_id,13))
                        <li>
                            <a href="#"><i class="fa fa-money fa-fw"></i> Accounts<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,12))
                                <li>
                                    <a href="{{URL::to('accounts/today')}}">Sales - Today</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,12))
                                <li>
                                    <a href="{{URL::to('accounts/this_week')}}">Sales - This week</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,12))
                                <li>
                                    <a href="{{URL::to('accounts/this_month')}}">Sales - This month</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,11))
                                <li>
                                    <a href="{{URL::to('expenses')}}">Expenses</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,14))
                                <li>
                                    <a href="{{URL::to('accounts/p_n_l')}}">Profit & Loss</a>
                                </li>
                                @endif
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        @endif
                        @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,12) || UserType::userTypeHasPermission(Auth::user()->user_type_id,11) || UserType::userTypeHasPermission(Auth::user()->user_type_id,14) ||
                        UserType::userTypeHasPermission(Auth::user()->user_type_id,13))
                        <li>
                            <a href="#"><i class="fa fa-cogs fa-fw"></i> Organization<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,12))
                                <li>
                                    <a href="{{URL::to('users/create')}}">New User</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,11))
                                <li>
                                    <a href="{{URL::to('users')}}">Users' List</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,14))
                                <li>
                                    <a href="{{URL::to('user_types/create')}}">New User Type</a>
                                </li>
                                @endif
                                @if(UserType::userTypeHasPermission(Auth::user()->user_type_id,13))
                                <li>
                                    <a href="{{URL::to('user_types')}}">User Types' List</a>
                                </li>
                                @endif
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        @endif
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            @if(Session::has('ms'))
                <div class="row" style="padding-top: 7px;">
                    <div class="alert alert-{{Session::get('mt')}} alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <span style="font-weight: 600;font-size: 16px;">{{strtoupper(Session::get('mt'))}}!</span><br>
                        {{Session::get('ms')}}</a>.
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
            @endif

        @yield('contentarea')
        <!-- /#page-wrapper -->

        </div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="{{ URL::asset('assets/jquery/jquery.min.js') }}"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="{{ URL::asset('assets/bootstrap/js/bootstrap.min.js') }}"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="{{ URL::asset('assets/metisMenu/metisMenu.min.js') }}"></script>

    <!-- Morris Charts JavaScript -->
    <script src="{{ URL::asset('assets/raphael/raphael.min.js') }}"></script>
    <script src="{{ URL::asset('assets/morrisjs/morris.min.js') }}"></script>
    <script src="{{ URL::asset('assets/data/morris-data.js') }}"></script>

    <!-- DataTables JavaScript -->
    <script src="{{ URL::asset('assets/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ URL::asset('assets/datatables-plugins/dataTables.bootstrap.min.js') }}"></script>
    <script src="{{ URL::asset('assets/datatables-responsive/dataTables.responsive.js') }}"></script>

    <!-- Custom Theme JavaScript -->
    <script src="{{ URL::asset('assets/js/sb-admin-2.js') }}"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
