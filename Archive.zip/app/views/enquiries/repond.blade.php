<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Portal | Origgin Prepaid</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="{{URL::asset('assets/dashboard/css/bootstrap.min.css')}}" rel="stylesheet">
<link href="{{URL::asset('assets/dashboard/css/bootstrap-responsive.min.css')}}" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="{{URL::asset('assets/dashboard/css/font-awesome.css')}}" rel="stylesheet">
<link href="{{URL::asset('assets/dashboard/css/style.css')}}" rel="stylesheet">
<link href="{{URL::asset('assets/dashboard/css/pages/dashboard.css')}}" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>

@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">
  
  <div class="main-inner">

      <div class="container">
      <div class="row all-icons">
          <div class="widget ">
              
              <div class="widget-header">
                  <i class="icon-comments"></i>
                  <h3>Enquery Response</h3>
              </div> <!-- /widget-header -->
            
            <div class="widget-content">
              
              <div class="tabbable">
              <ul class="nav nav-tabs" style="margin: 0;">
                <li class="active">
                  <a href="#balance_enquiry" data-toggle="tab">{{$enquiry->type}}</a>
                </li>
              </ul>
              
              <br>
              
                <div class="tab-content">
                  <div class="tab-pane active" id="balance_enquiry">
                  <form id="edit-profile" class="form-horizontal">
                    <fieldset>
                      
                      <div class="control-group">                     
                        <label class="control-label" for="email">Email</label>
                        <div class="controls">
                          {{ Form::text('email',Input::old('email')?Input::old('email'):($enquiry->customer?$enquiry->customer->email:''),array('class'=>'span6 disabled','placeholder'=>'','disabled'=>'')) }}
                          <p class="help-block" style="color: red;">{{$errors->first('email')}}</p>
                        </div> <!-- /controls -->       
                      </div> <!-- /control-group -->

                      <div class="control-group">                     
                        <label class="control-label" for="email">{{$field}}</label>
                        <div class="controls">
                          {{ Form::text('balance',Input::old('balance'),array('class'=>'span6 disabled','id'=>'balance','onchange'=>'update_balance();')) }}
                          <p class="help-block" style="color: red;">{{$errors->first('balance')}}</p>
                        </div> <!-- /controls -->       
                      </div> <!-- /control-group -->
                      
                      
                      <div class="control-group">                     
                        <label class="control-label" for="firstname">Message</label>
                        <div class="controls">
                          {{ Form::textarea('message',$message,array('class'=>'span6 disabled','id'=>'message','rows'=>'10')) }}
                          <p class="help-block" style="color: red;">{{$errors->first('message')}}</p>
                        </div> <!-- /controls -->       
                      </div> <!-- /control-group -->

                      <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Send</button> 
                        <button class="btn">Cancel</button>
                      </div> <!-- /form-actions -->
                    </fieldset>
                  </form>
                  </div>
                </div>
                
                
              </div>
            
            
            
            
            
          </div> <!-- /widget-content -->
            
        </div>
        </div> <!-- /row -->
  
      </div> <!-- /container -->
    
  </div> <!-- /main-inner -->
      
</div>
<!-- /main -->

<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="span12"> &copy; {{date('Y')}} <a href="http://www.origgin.net/">Origgin</a>. </div>
        <!-- /span12 --> 
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /footer-inner --> 
</div>
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="{{URL::asset('assets/dashboard/js/jquery-1.7.2.min.js') }}"></script> 
<script src="{{URL::asset('assets/dashboard/js/excanvas.min.js') }}"></script> 
<script src="{{URL::asset('assets/dashboard/js/chart.min.js') }}" type="text/javascript"></script> 
<script src="{{URL::asset('assets/dashboard/js/bootstrap.js') }}"></script>
<script language="javascript" type="text/javascript" src="{{URL::asset('assets/dashboard/js/full-calendar/fullcalendar.min.js') }}"></script>
 
<script src="{{URL::asset('assets/dashboard/js/base.js') }}"></script> 
<script type="text/javascript">
  function update_balance(){
    // var mes = $('#message').val();
    // var balance = $('#balance').val();
    // mes = mes.replace('%%0.00%%',$('#balance').val());

    $('#message').val($('#message').val().replace('%%0.00%%',$('#balance').val()));
  }
</script>
</body>
</html>
