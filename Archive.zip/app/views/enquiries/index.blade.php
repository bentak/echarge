<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Portal | Origgin Prepaid</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="assets/dashboard/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/dashboard/css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="assets/dashboard/css/font-awesome.css" rel="stylesheet">
<link href="assets/dashboard/css/style.css" rel="stylesheet">
<link href="assets/dashboard/css/pages/dashboard.css" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>

@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">
    
    <div class="widget">
        <div class="widget-header">
            <i class="icon-list-alt"></i>
            <h3>
                Enquiries</h3>
        </div>
        <!-- /widget-header -->
        <div class="widget-content">
        
          <table class="table">
          	<tr>
          		<th>Since</th>
          		<th>ID</th>
          		<th>Type</th>
              	<th>Phone</th>
              	<th>Email</th>
          		<th>Action</th>
          	</tr>
          	@foreach($enquiries as $key=>$enquiry)
	          	<tr>
	          		<td>{{$enquiry->created_at}}</td>
	          		<td>{{$enquiry->id}}</td>
	          		<td>{{$enquiry->type}}</td>
	                <td>{{$enquiry->customer?$enquiry->customer->phone:''}}</td>
	                <td>{{$enquiry->customer?$enquiry->customer->email:''}}</td>
		          	<td><a href="{{URL::to('enquiries/'.$enquiry->id.'/respond')}}" target="_blanc"><i class="icon-reply"></i></a></td>
	          	</tr>
	        @endforeach
	        @if(count($enquiries)<1)
	        	<tr>
	          		<td colspan="6" style="text-align: center;">There are no enquiries here yet.</td>
	          	</tr>
	        @endif
          </table>
        
      </div>
    </div>
      
    
  </div> <!-- /row -->
	
	    </div> <!-- /container -->
    
	</div> <!-- /main-inner -->
	    
</div>
<!-- /main -->

<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="span12"> &copy; {{date('Y')}} <a href="http://www.origgin.net/">Origgin</a>. </div>
        <!-- /span12 --> 
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /footer-inner --> 
</div>
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="assets/dashboard/js/jquery-1.7.2.min.js"></script> 
<script src="assets/dashboard/js/excanvas.min.js"></script> 
<script src="assets/dashboard/js/chart.min.js" type="text/javascript"></script> 
<script src="assets/dashboard/js/bootstrap.js"></script>
<script language="javascript" type="text/javascript" src="assets/dashboard/js/full-calendar/fullcalendar.min.js"></script>
 
<script src="assets/dashboard/js/base.js"></script> 
</body>
</html>
