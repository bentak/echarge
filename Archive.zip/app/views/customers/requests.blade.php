<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Portal | Origgin Prepaid</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="{{ URL::asset('assets/dashboard/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/dashboard/css/bootstrap-responsive.min.css') }}" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="{{ URL::asset('assets/dashboard/css/font-awesome.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/dashboard/css/style.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/dashboard/css/pages/dashboard.css') }}" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>

@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">

	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">

    <div class="widget">
        <div class="widget-header">
            <i class="icon-list-alt"></i>
            <h3>
                Requests for Customer []
            </h3>
            <span class="pull-right">
              From: <input id="from_date" class="form-control" value="{{$from}}" type="date" onchange="remakeDate();"> To: <input id="to_date" class="form-control" value="{{$to}}" type="date" onchange="remakeDate();"><input type="hidden" name="date_str" id="date_str"> <button class="btn btn-success btn-sm" onclick="doSubmit();">Go</button>
            </span>
        </div>
        <!-- /widget-header -->
        <div class="widget-content">

          <div class="tabbable">
            <ul class="nav nav-tabs">
              <li class="active">
                <a href="#sold" data-toggle="tab"><i class="icon icon-check"></i>Sold</a>
              </li>
              <li><a href="#refunded" data-toggle="tab"><i class="icon icon-retweet"> </i>Refunded</a></li>
            </ul>
            
            <br>
            
              <div class="tab-content">
                <div class="tab-pane active" id="sold">
                    <table class="table">
                <tr>
                  <th>Date Time</th>
                  <th>ID</th>
                  <th>Meter ID</th>
                  <th>Meter Name</th>
                  <th>Amount (GHS)</th>
                  <th>Quota</th>
                  <th>Convenience Fee (GHS)</th>
                  <th>API Charge (GHS)</th>
                  <th>Customer</th>
                  
                </tr>
                <?php 
                  $total_amount = 0;
                  $total_ecg_amount = 0;
                  $total_origgin_charge = 0;
                  $total_charges = 0;
                ?>
                @foreach($sold as $key=>$sale)
                <?php 
                  $total_amount += $sale->amount;
                  $total_ecg_amount += $sale->ecg_amount;
                  $total_origgin_charge += $sale->origgin_charge;
                  $total_charges += $sale->charges;
                ?>
                  <tr>
                    <td>{{$sale->sold_at}}</td>
                    <td>{{$sale->id}}</td>
                    <th>{{$sale->requst?$sale->requst->meter_code:''}}</th>
                     <th>{{$sale->requst?$sale->requst->meter_owner:''}}</th>
                    <th>{{$sale->amount}}</th>
                    <th>{{$sale->ecg_amount}}</th>
                    <td>{{$sale->origgin_charge}}</td>
                    <td>{{$sale->charges}}</td>
                    <td>{{$sale->customer()?$sale->customer():''}}</td>
                    
                  </tr>
              @endforeach
              @if(count($sold)<1)
                <tr>
                    <td colspan="8" style="text-align: center;">There are no sales here yet.</td>
                  </tr>
              @else
                <tr>
                  <th style="text-align: center;" colspan="3">Totals</th>
                   <th></th>
                  <th>{{number_format($total_amount,2,'.',',')}}</th>
                  <th>{{number_format($total_ecg_amount,2,'.',',')}}</th>
                  <th>{{number_format($total_origgin_charge,2,'.',',')}}</th>
                  <th>{{number_format($total_charges,2,'.',',')}}</th>
                  <th></th>
                </tr>
              @endif
              </table>
              
                </div>
                
                <div class="tab-pane" id="refunded">
                  <table class="table">
            <tr>
              <th>Date Time</th>
              <th>ID</th>
              <th>Meter ID</th>
              <th>Meter Name</th>
              <th>Amount (GHS)</th>
              <th>Quota</th>
              <th>Convenience Fee (GHS)</th>
              <th>API Charge (GHS)</th>
              <th>Customer</th>
            </tr>
            <?php 
                  $rtotal_amount = 0;
                  $rtotal_ecg_amount = 0;
                  $rtotal_origgin_charge = 0;
                  $rtotal_charges = 0;
                ?>
            @foreach($refunded as $key=>$sale)
            <?php 
                  $rtotal_amount += $sale->amount;
                  $rtotal_ecg_amount += $sale->ecg_amount;
                  $rtotal_origgin_charge += $sale->origgin_charge;
                  $rtotal_charges += $sale->charges;
                ?>
              <tr>
                <td>{{$sale->sold_at}}</td>
                <td>{{$sale->id}}</td>
                <th>{{$sale->requst?$sale->requst->meter_code:''}}</th>
                 <th>{{$sale->requst?$sale->requst->meter_owner:''}}</th>
                <th>{{$sale->amount}}</th>
                <th>{{$sale->ecg_amount}}</th>
                <td>{{$sale->origgin_charge}}</td>
                <td>{{$sale->charges}}</td>
                <td>{{$sale->customer()?$sale->customer():''}}</td>
                
              </tr>
          @endforeach
          @if(count($refunded)<1)
            <tr>
                <td colspan="8" style="text-align: center;">There are no refunded sales here yet.</td>
              </tr>
          @else
                <tr>
                  <th style="text-align: center;" colspan="3">Totals</th>
                   <th></th>
                  <th>{{number_format($rtotal_amount,2,'.',',')}}</th>
                  <th>{{number_format($rtotal_ecg_amount,2,'.',',')}}</th>
                  <th>{{number_format($rtotal_origgin_charge,2,'.',',')}}</th>
                  <th>{{number_format($rtotal_charges,2,'.',',')}}</th>
                  <th></th>
                </tr>
          @endif
          </table>
                </div>
                
              </div>
              
              
            </div>
      </div>
    </div>


  </div> <!-- /row -->

	    </div> <!-- /container -->

	</div> <!-- /main-inner -->

</div>
<!-- /main -->

<!-- start of footer -->
<!-- start of footer -->
<div id="footer">
    <p>
      <center>
          <span class="text-white">
              Copyright &copy; <?= date('Y') ?> Origgin Ltd. All Rights Reserved.
          </span>
      </center>
    </p>
</div> <!-- /navbar-inner -->
<!-- /footer --> 
<!-- /footer --> 
<!-- /footer -->
<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="{{ URL::asset('assets/dashboard/js/jquery-1.7.2.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/excanvas.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/chart.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/dashboard/js/bootstrap.js') }}"></script>
<script language="javascript" type="text/javascript" src="{{ URL::asset('assets/dashboard/js/full-calendar/fullcalendar.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/base.js') }}"></script>
<script>
 function remakeDate(){
    $('#date_str').val('/123/'+$('#from_date').val()+'/'+$('#to_date').val());
  }

  function doSubmit(){
    window.location.href = 'http://eprepaid.origgin.net/customers'+$('#date_str').val();
  }
       
        $(document).ready(function() {
        var date = new Date();
        var d = date.getDate();
        var m = date.getMonth();
        var y = date.getFullYear();
        var calendar = $('#calendar').fullCalendar({
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
          },
          selectable: true,
          selectHelper: true,
          select: function(start, end, allDay) {
            var title = prompt('Event Title:');
            if (title) {
              calendar.fullCalendar('renderEvent',
                {
                  title: title,
                  start: start,
                  end: end,
                  allDay: allDay
                },
                true // make the event "stick"
              );
            }
            calendar.fullCalendar('unselect');
          },
          editable: true,
          events: [
            {
              title: 'All Day Event',
              start: new Date(y, m, 1)
            },
            {
              title: 'Long Event',
              start: new Date(y, m, d+5),
              end: new Date(y, m, d+7)
            },
            {
              id: 999,
              title: 'Repeating Event',
              start: new Date(y, m, d-3, 16, 0),
              allDay: false
            },
            {
              id: 999,
              title: 'Repeating Event',
              start: new Date(y, m, d+4, 16, 0),
              allDay: false
            },
            {
              title: 'Meeting',
              start: new Date(y, m, d, 10, 30),
              allDay: false
            },
            {
              title: 'Lunch',
              start: new Date(y, m, d, 12, 0),
              end: new Date(y, m, d, 14, 0),
              allDay: false
            },
            {
              title: 'Birthday Party',
              start: new Date(y, m, d+1, 19, 0),
              end: new Date(y, m, d+1, 22, 30),
              allDay: false
            },
            {
              title: 'EGrappler.com',
              start: new Date(y, m, 28),
              end: new Date(y, m, 29),
              url: 'http://EGrappler.com/'
            }
          ]
        });
      });
    </script><!-- /Calendar -->
</body>
</html>
