<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Portal | Origgin Prepaid</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="{{ URL::asset('assets/dashboard/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/dashboard/css/bootstrap-responsive.min.css') }}" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="{{ URL::asset('assets/dashboard/css/font-awesome.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/dashboard/css/style.css') }}" rel="stylesheet">
<link href="{{ URL::asset('assets/dashboard/css/pages/dashboard.css') }}" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>

@include('layouts.subs.mainnav')
</div>
<!-- /subnavbar -->
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">
    
    <div class="widget">
        <div class="widget-header">
            <i class="icon-list-alt"></i>
            <h3>
                Denied Requests (From {{date('l, M d, Y',strtotime($from))}} to {{date('l, M d, Y',strtotime($to))}})
            </h3>
            
             <span class="pull-right">
              From: <input id="from_date" class="form-control" value="{{$from}}" type="date" onchange="remakeDate();"> To: <input id="to_date" class="form-control" value="{{$to}}" type="date" onchange="remakeDate();"><input type="hidden" name="date_str" id="date_str"> <button class="btn btn-success btn-sm" onclick="doSubmit();">Go</button>
            </span>
        </div>
        <!-- /widget-header -->
        <div class="widget-content">
        
            <table class="table" id="translist">
                <thead>
                    <th>Date Time</th>
                    <th>ID</th>
                    <th>Meter ID</th>
                    <th>Meter Owner</th>
                    <th>Amount</th>
                    <th>Name</th>
                    <th>Customer Number</th>                    
                    <th>Location</th>
                    <th>Request Type</th>
                    <th>Reason</th>
                    
            </thead>
            
             <?php 
                  $total_amount = 0;
                  $total_requests = 0;
                
                ?>
            
          	@foreach($requests as $key=>$request)
                    <tr data-id="{{$request->id}}">
                            <td>{{$request->created_at}}</td>
                            <td>{{Str::limit($request->id,10)}}</td>
                            <td>{{$request->meter_code}}</td>
                             <td>{{$request->meter_owner}}</td>
                            <td>{{$request->amount}}</td>
                            <td>{{$request->customer?($request->customer->name=='-'?$request->customer->email:$request->customer->name):'-'}}</td>
                            <td>{{$request->customer?$request->customer->phone:''}}</td>	          		
                            <td>{{$request->location}}</td>
                           <td>{{$request->type_id==1?'Prepaid Credit':'Credit Balance'}}</td>
                           <td>{{$request->reject_reason}}</td>
                    </tr>

                    <?php 
                        $total_amount += $request->amount;
                        $total_requests++;
                     ?>
                        
	        @endforeach
	        @if(count($requests)<1)
                    <tr>
                            <td colspan="5" style="text-align: center;">There are no requests here yet.</td>
                    </tr>
                    @else
                <tr>
                    <th style="text-align: center;" >Totals</th>
                  <th colspan="2">{{$total_requests}} <?php echo $total_requests==1?" Request":" Requests" ?></th>
                  <th></th>
                  <th colspan="2">GHc {{number_format($total_amount,2,'.',',')}}</th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                </tr>
	        @endif
          </table>
        
      </div>
    </div>
      
    
  </div> <!-- /row -->
	
	    </div> <!-- /container -->
    
	</div> <!-- /main-inner -->
	    
</div>
<!-- /main -->

<!-- start of footer -->
<div id="footer">
    <p>
      <center>
          <span class="text-white">
              Copyright &copy; <?= date('Y') ?> Origgin Ltd. All Rights Reserved.
          </span>
      </center>
    </p>
</div> <!-- /navbar-inner -->
<!-- /footer --> 
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="{{ URL::asset('assets/dashboard/js/jquery-1.7.2.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/excanvas.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/chart.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/dashboard/js/bootstrap.js') }}"></script>
<script language="javascript" type="text/javascript" src="{{ URL::asset('assets/dashboard/js/full-calendar/fullcalendar.min.js') }}"></script>
<script src="{{ URL::asset('assets/dashboard/js/base.js') }}"></script>

<script> 
    
//     setInterval(function(){
//        //getNewRequests();
//      },5000);

function remakeDate(){
    $('#date_str').val('/'+$('#from_date').val()+'/'+$('#to_date').val());
  }

  function doSubmit(){
    window.location.href = 'http://eprepaid.origgin.net/denied_requests'+$('#date_str').val();
  }



        $(document).ready(function() {
        var date = new Date();
        var d = date.getDate();
        var m = date.getMonth();
        var y = date.getFullYear();
        var calendar = $('#calendar').fullCalendar({
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
          },
          selectable: true,
          selectHelper: true,
          select: function(start, end, allDay) {
            var title = prompt('Event Title:');
            if (title) {
              calendar.fullCalendar('renderEvent',
                {
                  title: title,
                  start: start,
                  end: end,
                  allDay: allDay
                },
                true // make the event "stick"
              );
            }
            calendar.fullCalendar('unselect');
          },
          editable: true,
          events: [
            {
              title: 'All Day Event',
              start: new Date(y, m, 1)
            },
            {
              title: 'Long Event',
              start: new Date(y, m, d+5),
              end: new Date(y, m, d+7)
            },
            {
              id: 999,
              title: 'Repeating Event',
              start: new Date(y, m, d-3, 16, 0),
              allDay: false
            },
            {
              id: 999,
              title: 'Repeating Event',
              start: new Date(y, m, d+4, 16, 0),
              allDay: false
            },
            {
              title: 'Meeting',
              start: new Date(y, m, d, 10, 30),
              allDay: false
            },
            {
              title: 'Lunch',
              start: new Date(y, m, d, 12, 0),
              end: new Date(y, m, d, 14, 0),
              allDay: false
            },
            {
              title: 'Birthday Party',
              start: new Date(y, m, d+1, 19, 0),
              end: new Date(y, m, d+1, 22, 30),
              allDay: false
            },
            {
              title: 'EGrappler.com',
              start: new Date(y, m, 28),
              end: new Date(y, m, 29),
              url: 'http://EGrappler.com/'
            }
          ]
        });
      });
    </script><!-- /Calendar -->
</body>
</html>
