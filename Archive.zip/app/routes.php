<?php
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', array('as' => 'home', 'uses' => 'HomeController@home'));
// Route::get('payment_try', array('as' => 'get.payment_try', 'uses' => 'CardPaymentAPIController@index'));
// Route::post('payment_try', array('as' => 'post.payment_try', 'uses' => 'CardPaymentAPIController@main'));
// Route::get('payment_try_return.php', array('as' => 'get.payment_try_return', 'uses' => 'CardPaymentAPIController@indexReturn'));

Route::get('signin', array('as' => 'signin', 'uses' => 'UsersController@getSignin'));
Route::get('login', array('as' => 'signin', 'uses' => 'UsersController@getSignin'));
Route::get('logout', array('as' => 'logout', 'uses' => 'UsersController@signout'));
Route::get('signout', array('as' => 'logout', 'uses' => 'UsersController@signout'));

Route::get('ecg_status_toggle', array('as' => 'ecg_status_toggle', 'uses' => 'HomeController@ecgStatusToggle'));

Route::post('signin', array('as' => 'signin', 'uses' => 'UsersController@signin'));

//api - inhouse
Route::post('api/customer/signup', array('as' => 'api.post.customer.signup', 'uses' => 'CustomersController@apiPostCustomerSignup'));
Route::post('api/v2/customer/signup', array('as' => 'api.post.customer.signup', 'uses' => 'CustomersController@apiV2PostCustomerSignup'));
Route::post('api/customer/signin', array('as' => 'api.post.customer.signin', 'uses' => 'CustomersController@apiPostCustomerSignin'));
Route::post('api/v2/customer/signin', array('as' => 'api.post.customer.signin', 'uses' => 'CustomersController@apiV2PostCustomerSignin'));
Route::get('api/customer/{token}', array('as' => 'api.get.customer', 'uses' => 'CustomersController@apiGetCustomer'));
Route::post('api/update_customer/{token}', array('as' => 'api.post.customer.update', 'uses' => 'CustomersController@apiPostCustomerUpdate'));
Route::post('api/initiate_request/{token}', array('as' => 'api.post.request.initiate', 'uses' => 'RequstsController@apiPostInitiateRequest'));
Route::get('api/initiate_enquiry/{meter_code}/{token}', array('as' => 'api.post.initiate_enquiry', 'uses' => 'EnquiriesController@apiPostInitiateEnquiry'));
Route::get('api/consumption_enquiry/{meter_code}/{token}', array('as' => 'api.post.consumption_enquiry', 'uses' => 'EnquiriesController@apiPostConsumptionEnquiry'));
Route::get('api/confirm_enquiry/{meter_code}/{token}', array('as' => 'api.get.confirm_enquiry', 'uses' => 'EnquiriesController@apiGetConfirmEnquiry'));
Route::get('api/ecg_status', array('as' => 'api.get.ecg_status', 'uses' => 'HomeController@apiGetEcgStatus'));

Route::get('api2/customer_sales/{token}', array('as' => 'api2.get.customer_sales', 'uses' => 'CustomersController@api2GetCustomerSales'));
Route::post('api2/customer_login/euwjsiur77e9en84w04nxjs', array('as' => 'api2.post.customer_login', 'uses' => 'CustomersController@api2CustomerLogin'));
Route::get('api/products/euwjsiur77e9en84w04nxjs', array('as' => 'api.get.products', 'uses' => 'ProductsController@apiGetProducts'));
Route::get('api/customers/euwjsiur77e9en84w04nxjs', array('as' => 'api.get.customers', 'uses' => 'CustomersController@apiGetCustomers'));
Route::get('api/sales/euwjsiur77e9en84w04nxjs', array('as' => 'api.get.sales', 'uses' => 'SalesController@apiGetSales'));
Route::get('api/pre_sale', array('as' => 'api.get.pre_sale', 'uses' => 'SalesController@apiGetPreSales'));
Route::post('api/sales/euwjsiur77e9en84w04nxjs', array('as' => 'api.post.sales', 'uses' => 'SalesController@apiPostSales'));
Route::post('api/login/euwjsiur77e9en84w04nxjs', array('as' => 'api.post.login', 'uses' => 'UsersController@apiLogin'));

Route::post('api/customer_sales/{token}', array('as' => 'api.post.customer_sales', 'uses' => 'CustomersController@apiPostCustomerSales'));
//api - hubtel momo
Route::post('successful_momo_transaction', array('as' => 'successful_momo_transaction', 'uses' => 'MomoTransationsController@callback'));
Route::post('api/momo_callback', array('as' => 'momo_callback', 'uses' => 'MomoTransationsController@CheckoutCallback'));
Route::post('api/balance_momo_callback', array('as' => 'balance_momo_callback', 'uses' => 'MomoTransationsController@BalanceCheckoutCallback'));

Route::get('api/momo_cancel/{request_id}', array('as' => 'momo_cancel', 'uses' => 'MomoTransationsController@cancelCallback'));
Route::get('api/momo_return/{request_id}', array('as' => 'momo_return', 'uses' => 'MomoTransationsController@returnCallback'));
Route::get('api/momo_callback/myghpay', array('as' => 'momo_callback.myghpay', 'uses' => 'MomoTransationsController@MyGHPayCallback'));
Route::get('api/balance_momo_callback/myghpay', array('as' => 'balance_momo_callback.myghpay', 'uses' => 'MomoTransationsController@MyGHPayBalanceCallback'));
Route::get('api/momo_pay/{request_id}', array('as' => 'momo_pay', 'uses' => 'MomoTransationsController@MyGHPayPrepaid'));
Route::get('api/momo_pay_balance/{request_id}', array('as' => 'momo_pay_balance', 'uses' => 'MomoTransationsController@MyGHPayBalance'));

Route::post('api/payments/exist/{request_id}', array('as' => 'payment_exist', 'uses' => 'MomoTransationsController@PaymentExists'));

Route::post('api/payments/status/{request_id}', array('as' => 'payment_status', 'uses' => 'NsanoPaymentController@CheckPaymentStatus'));

Route::post('api/payments/checkout/{request_id}', array('as' => 'payment_checkout', 'uses' => 'NsanoPaymentController@PaymentCheckout'));
Route::post('api/payments/momo/debit/callback', array('as' => 'payment_callback', 'uses' => 'NsanoPaymentController@NsanoDebitCallback'));
Route::post('api/payments/momo/debit/callback/', array('as' => 'payment_callback', 'uses' => 'NsanoPaymentController@NsanoDebitCallback'));

//mPay Callback
Route::post('api/payments/mpay/debit/callback', array('as' => 'mpay_callback', 'uses' => 'NsanoPaymentController@MPayDebitCallback'));
Route::post('api/payments/mpay/debit/callback/', array('as' => 'mpay_callback', 'uses' => 'NsanoPaymentController@MPayDebitCallback'));

Route::get('api/payments/mazzuma_balance_checkout/{request_id}', array('as' => 'mazzuma_pay_balance', 'uses' => 'NsanoPaymentController@NsanoPaymentCheckout'));
Route::post('api/payments/pay_mazzuma/{request_id}', array('as' => 'pay_mazzuma', 'uses' => 'NsanoPaymentController@NsanoPaymentCheckout'));
Route::post('api/payments/balance_pay_mazzuma/{request_id}', array('as' => 'balance_pay_mazzuma', 'uses' => 'NsanoPaymentController@NsanoPaymentCheckout'));

//kwarteng generate

//check meter balance
Route::post('api/check_balance/{token}', array('as' => 'api.post.balance', 'uses' => 'RequstsController@apiPostCheckBalance'));

//check meter balance
Route::post('api2/check_balance/{token}', array('as' => 'api.post.balance', 'uses' => 'RequstsController@api2PostCheckBalance'));

//check meter balance
Route::post('api/v2/check_balance/{token}', array('as' => 'api.post.balance', 'uses' => 'RequstsController@apiV2PostCheckBalance'));

//initiate request
Route::post('api2/new_request/{token}', array('as' => 'api.post.newrequest', 'uses' => 'RequstsController@api2PostInitiateNewRequest'));

//initiate request
Route::post('api/v2/new_request/{token}', array('as' => 'api.post.newrequest', 'uses' => 'RequstsController@apiV2PostInitiateNewRequest'));

//initiate request
Route::post('api/new_request/{token}', array('as' => 'api.post.newrequest', 'uses' => 'RequstsController@apiPostInitiateNewRequest'));

//get origgin charge for an amount
Route::post('api/transactions/origgin_charge/{amount}', array('as' => 'post.transactions.origgin_charge', 'uses' => 'TransactionsController@apiPostOrigginCharge'));

//get valid locations for location entered by user
Route::post('api/locations/find/{location}', array('as' => 'post.locations.find', 'uses' => 'LocationsController@find'));

//resset password
Route::post('api/customer/account-resset/{number}', array('as' => 'post.account-resset', 'uses' => 'CustomersController@verifyNumber'));

//resset password: verify code
Route::post('api/customer/account-resset/authenticate/{number}/{code}', array('as' => 'post.account-resset.authenticate', 'uses' => 'CustomersController@authenticateResetCode'));

//resset password: new password
Route::post('api/customer/account-resset/resset/{token}', array('as' => 'post.account-resset.resset', 'uses' => 'CustomersController@ressetPassword'));



//resend account verification code
Route::post('api/customer/account-verify/resend/{number}', array('as' => 'post.account-verify.resend', 'uses' => 'CustomersController@resendAccountVerificationCode'));

//authenticate accont verification code
Route::post('api/customer/account-verify/authenticate/{number}/{code}', array('as' => 'post.account-verify.authenticate', 'uses' => 'CustomersController@authenticateAccountVerificationCode'));

//request payment verification code
Route::post('api/customer/payment-verify/{token}/{number}', array('as' => 'post.payment-verify', 'uses' => 'CustomersController@verifyPaymentNumber'));

//authenticate payment verification code
Route::post('api/customer/payment-verify/authenticate/{number}/{code}', array('as' => 'post.payment-verify.authenticate', 'uses' => 'CustomersController@authenticatePayment'));

//resend account verification code
Route::post('api/customer/payment-verify/resend/{token}/{number}', array('as' => 'post.payment-verify.resend', 'uses' => 'CustomersController@resendPaymentVerificationCode'));



//POS MOBILE MONEY API
Route::post('api/momo/mazzuma/pay/{request_id}', array('as' => 'mazzuma_pay', 'uses' => 'MazzumaPaymentController@ProccesMazzumaPayment'));
Route::post('api/momo/mazzuma/status/{request_id}', array('as' => 'mazzuma_status', 'uses' => 'MazzumaPaymentController@CheckPaymentStatus'));

Route::group(array('before' => 'auth'), function()
	{
    
        });
		Route::get('sales/today', array('as' => 'sales.today', 'uses' => 'SalesController@today'));
		Route::get('sales/for_period/{from?}/{to?}', array('as' => 'sales.for_period', 'uses' => 'SalesController@forPeriod'));
		Route::get('accounts/today', array('as' => 'sales.today', 'uses' => 'SalesController@today'));
		Route::get('accounts/this_week', array('as' => 'sales.today', 'uses' => 'SalesController@thisWeek'));
		Route::get('accounts/this_month', array('as' => 'sales.today', 'uses' => 'SalesController@thisMonth'));
		Route::get('transactions/{id}/add_as_sale', array('as' => 'get.transactions.add_as_sale', 'uses' => 'TransactionsController@addAsSale'));
		Route::get('transactions/{id}/add_as_refund', array('as' => 'get.transactions.add_as_refund', 'uses' => 'TransactionsController@addAsRefund'));
		Route::get('requests/{id}/add_as_paid', array('as' => 'get.requests.add_as_paid', 'uses' => 'RequstsController@addAsPaid'));
		Route::get('enquiries/{id}/respond', array('as' => 'get.enquiries.respond', 'uses' => 'EnquiriesController@getRespond'));
		Route::post('enquiries/{id}/respond', array('as' => 'post.enquiries.respond', 'uses' => 'EnquiriesController@postRespond'));
		
             
                Route::post('transactions/new/{id}', array('as' => 'post.transactions.new', 'uses' => 'TransactionsController@recent'));
                Route::post('requests/new/{id}', array('as' => 'post.requests.new', 'uses' => 'RequstsController@recent'));
                
                Route::get('blocked_list/unblock/{id}/{phone}', array('as' => 'blocked.unblock', 'uses' => 'BlockedListController@unblock')); 
                Route::get('blocked_list/add_block/{id}/{phone}', array('as' => 'blocked.addblock', 'uses' => 'BlockedListController@addBlock')); 
                Route::get('blocked_list/add_exception/{phone}', array('as' => 'blocked.addexception', 'uses' => 'BlockedListController@addBlockException')); 
                Route::get('blocked_list/remove_exception/{phone}', array('as' => 'blocked.removeexception', 'uses' => 'BlockedListController@removeBlockException')); 

                Route::get('denied_requests/{from?}/{to?}', array('as' => 'denied.for_period', 'uses' => 'DeniedRequestController@index'));
                
                Route::get('customers/{from?}/{to?}', array('as' => 'customers.for_period', 'uses' => 'CustomersController@index'));
                
                Route::get('customers/requests/{id}/{from?}/{to?}', array('as' => 'customers.requests', 'uses' => 'CustomersController@getCustomerSales'));                
                
       
        
                Route::get('requests/{from?}/{to?}', array('as' => 'request.for_period', 'uses' => 'RequstsController@index'));
        
                Route::get('partners/records/{from?}/{to?}', array('as' => 'partners.for_period', 'uses' => 'PartnersController@index'));
                Route::get('topups/records/{from?}/{to?}', array('as' => 'topups.for_period', 'uses' => 'PartnerTopupController@index'));
                
                Route::get('partners/add', array('as' => 'partners.add', 'uses' => 'PartnersController@store'));                
                Route::get('topups/add', array('as' => 'topups.add', 'uses' => 'PartnerTopupController@store'));                
                Route::get('branches/add', array('as' => 'branches.add', 'uses' => 'PartnerBrachesController@store'));
                
                Route::get('partners/create', array('as' => 'partners.create', 'uses' => 'PartnersController@create'));                
                Route::get('topups/create', array('as' => 'topups.create', 'uses' => 'PartnerTopupController@create'));                
                Route::get('topups/edit/{id}', array('as' => 'topups.edit', 'uses' => 'PartnerTopupController@edit'));                
                Route::get('topups/update/{id}', array('as' => 'topups.edit', 'uses' => 'PartnerTopupController@update'));
                
                Route::get('locations/add', array('as' => 'locations.add', 'uses' => 'LocationsController@store'));                
                Route::get('locations/create', array('as' => 'locations.create', 'uses' => 'LocationsController@create'));                
                Route::get('locations/edit/{id}', array('as' => 'locations.edit', 'uses' => 'LocationsController@edit'));                
                Route::get('locations/update/{id}', array('as' => 'locations.update', 'uses' => 'LocationsController@update'));
                
                Route::get('branches/create', array('as' => 'branches.create', 'uses' => 'PartnerBrachesController@create'));
        
                Route::resource('partners','PartnersController');
                Route::resource('topups', 'PartnerTopupController'); 
                Route::resource('branches', 'PartnerBranchesController');
                Route::resource('partner_users', 'PartnerUsersController');
                                
                //Route::get('customers/requests/{id}/{from?}/{to?}', array('as' => 'customers.requests', 'uses' => 'CustomersController@getCustomerSales'));                


		Route::resource('users', 'UsersController');
		Route::resource('user_types', 'UserTypesController');
		Route::resource('customers', 'CustomersController');
		Route::resource('transactions', 'TransactionsController');
		Route::resource('requests', 'RequstsController');
		Route::resource('locations', 'LocationsController');
		Route::resource('sales', 'SalesController');
		Route::resource('ecg_statuses', 'EcgStatusesController');
		Route::resource('momo_transations', 'MomoTransationsController');
		Route::resource('districts', 'DistrictsController');
		Route::resource('ecg_regions', 'EcgRegionsController');
		Route::resource('vendors', 'VendorsController');
		Route::resource('enquiries', 'EnquiriesController');
                
                Route::resource('payment_services','PaymentTypeController');
                Route::resource('blocked_list', 'BlockedListController'); 
                Route::resource('denied_requests', 'DeniedRequestController');
                
                
		

                
        /*
         * THIRD PARTY API ROUTES
         * ALL ROUTES REQUIRE API KEY
         */

//initiate new request
Route::post('partner/new_request/{api_key}', array('as' => 'partner.newrequest', 'uses' => 'PartnerRequestsController@apiPostInitiateNewRequest'));

//check system availability
Route::post('partner/ecg/status/{api_key}', array('as' => 'ecg.status', 'uses' => 'PartnerRequestsController@apiPostGetECGStatus'));

//check request status
Route::post('partner/transaction/status/{api_key}/{request_id}', array('as' => 'partner.request.status', 'uses' => 'PartnerRequestsController@CheckTransactionStatus'));

//initiate new request
Route::post('partner/balance/{api_key}', array('as' => 'partner.balance', 'uses' => 'PartnerRequestsController@apiPostInitiateNewRequest'));

//initiate new request
Route::post('partner/reseller/new_request/{api_key}/{user}/{branch}', array('as' => 'partner.reseller.newrequest', 'uses' => 'PartnerRequestsController@apiPostInitiateNewResellerRequest'));

//get list of available locations
Route::post('partner/locations/{api_key}', array('as' => 'partner.locations', 'uses' => 'LocationsController@all'));

//Dashboard API
Route::post('partner/transactions/filter/{user}/{api_key}', array('as' => 'partner.transactions.filter', 'uses' => 'PartnerRequestsController@filterRequestsAPI'));
Route::post('partner/transactions/recent/{user}/{api_key}/{last_id}', array('as' => 'partner.transactions.recent', 'uses' => 'PartnerRequestsController@recentRequestsAPI'));

Route::post('partner/branches/filter/{api_key}', array('as' => 'partner.branches.filter', 'uses' => 'PartnerBranchesController@filterBranchAPI'));
Route::post('partner/branches/add/{api_key}', array('as' => 'partner.branches.add', 'uses' => 'PartnerBranchesController@addBranchAPI'));
Route::post('partner/branches/update/{branch_id}/{api_key}', array('as' => 'partner.branches.update', 'uses' => 'PartnerBranchesController@updateBranchAPI'));

Route::post('partner/users/filter/{user}/{api_key}', array('as' => 'partner.users.filter', 'uses' => 'PartnerUsersController@filterUserAPI'));
Route::post('partner/users/add/{api_key}', array('as' => 'partner.users.add', 'uses' => 'PartnerUsersController@addUserAPI'));
Route::post('partner/users/update/{user_id}/{api_key}', array('as' => 'partner.users.update', 'uses' => 'PartnerUsersController@updateUserAPI'));

Route::post('partner/topups/filter/{api_key}', array('as' => 'partner.credit.filter', 'uses' => 'PartnerTopupController@filterTopupAPI'));

Route::post('partner/dashboard/filter/{api_key}', array('as' => 'partner.users.filter', 'uses' => 'PartnerUsersController@filterUerAPI'));




App::missing(function($exception)
{
   // return Response::view('errors.missing', array(), 404);
	return '404';
});