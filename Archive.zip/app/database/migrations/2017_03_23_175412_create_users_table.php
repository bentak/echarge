<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateUsersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('users', function(Blueprint $table)
		{
			$table->increments('id');
			
			$table->integer('type_id');
			$table->string('username', 16)->unique();
            $table->string('password', 64);
            $table->string('email', 128)->unique();
			$table->integer('user_type_id')->default(1)->unsigned()->index();
			$table->double('balance')->default(0);
			
			$table->string('recustomer_token',255);
			$table->softDeletes();
            $table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('users');
	}

}
