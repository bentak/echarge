<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMomoTransationsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('momo_transations', function(Blueprint $table)
		{
			$table->increments('id');

			$table->double('amount');
            $table->double('charges');
						$table->double('ecg_amount');
						$table->double('origgin_charge');
            $table->double('amount_after_charges');
            $table->string('transaction_id', 124)->unique();
            $table->string('response_code', 16);
            $table->string('description', 512);
            $table->string('client_refrence', 124);
            $table->string('external_transaction_id', 124);
            $table->integer('requst_id')->unsigned()->index();
						$table->boolean('is_sold');
            $table->datetime('sold_at');

			$table->softDeletes();
            $table->timestamp('created_at')->default(date('y-m-d H:i:s', strtotime('now')));
			$table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP'));
		});
	}

//account number - HM0408170017
	//Basic YnRsbndscGc6a3ltd3Job3g=
	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('momo_transations');
	}

}
