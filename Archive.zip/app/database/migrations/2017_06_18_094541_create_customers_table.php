<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateCustomersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('customers', function(Blueprint $table)
		{
			$table->increments('id');
			
			$table->integer('type_id')->default(1);
			$table->string('phone', 32);
			$table->string('phone_alt', 32);
            $table->string('password', 64);
            $table->string('email', 128)->unique();
			$table->integer('user_type_id')->default(1)->unsigned()->index();
			
			
			$table->string('customer_token',255);
			$table->softDeletes();
            $table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('customers');
	}

}
