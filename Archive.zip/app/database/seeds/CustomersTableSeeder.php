<?php

class CustomersTableSeeder extends Seeder {

	public function run()
	{
		
	}

}