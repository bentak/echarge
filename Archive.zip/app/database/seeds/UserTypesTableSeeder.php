<?php

class UserTypesTableSeeder extends Seeder {

	public function run()
	{
		
	}

}