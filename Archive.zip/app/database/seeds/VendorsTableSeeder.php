<?php

class VendorsTableSeeder extends Seeder {

	public function run()
	{
		Vendor::truncate();

        Vendor::create(array(
            'ecg_region_id'      =>  1,
            'name'     => 'East Legon Woman',
            'address'       => 'American House, East Legon, Accra',
            'email'          => 'vendor1@gmail.com',
            'telephone'          => '0502369854',
            'telephone_alt'          => '0244715689'
        ));
	}

}