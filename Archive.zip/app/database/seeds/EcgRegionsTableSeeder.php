<?php

class EcgRegionsTableSeeder extends Seeder {

	public function run()
	{
		DB::table('ecg_regions')->truncate();
		
		//greater accra region
		DB::table('ecg_regions')->insert(array(
		    array('region_id' => 5, 'name' => 'Accra West', 'description' => 'Accra West'),
		    array('region_id' => 5, 'name' => 'Accra East', 'description' => 'Accra East'),
		    array('region_id' => 5, 'name' => 'Tema', 'description' => 'Tema')
		));
	}

}