<?php

class EnquiriesTableSeeder extends Seeder {

	public function run()
	{
		Enquiry::truncate();

		Enquiry::create(array(
			'meter_code'=>'55226895',

			'customer_token'=>'sgedfgertdhrs',

			'response'=>'Your balance is GHS 607.90 as at 2017-12-03 12:54:12',

			'is_confirmed'=>'1',

			'confirmed_at'=> date('Y-m-d H:i:s'),

			'confirmed_by_id' => 1));
	}

}