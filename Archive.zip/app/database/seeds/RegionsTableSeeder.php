<?php

class RegionsTableSeeder extends Seeder {

	public function run()
	{
		
	}

}