<?php

class UsersTableSeeder extends Seeder {

	public function run()
	{
		User::truncate();

        User::create(array(
            'user_type_id'      =>  1,
            'type_id'        => '1',
            'username'     => 'elikem',
            'password'       => 'james111',
            'email'          => 'elishasenoo@gmail.com'
        ));
		
		User::create(array(
            'user_type_id'      =>  2,
            'type_id'     => '2',
            'username'  => 'elisha',
            'password'    => 'james111',
            'email'       => 'mailelikem@gmail.com'
        ));
		
		User::create(array(
            'user_type_id'      =>  3,
            'type_id'     => '2',
            'username'  => 'caleb',
            'password'    => 'james111',
            'email'       => 'calebston@gmail.com'
        ));
	}

}