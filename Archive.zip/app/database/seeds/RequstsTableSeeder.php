<?php

class RequstsTableSeeder extends Seeder {

	public function run()
	{
		Requst::truncate();

		Requst::create(array(
			'type_id' => 1,

			'meter_code'=>'55226895',

			'amount'=>'2',

			'location'=>'America House',

			'meter_owner'=>'Richard Folley',

			'location_id'=>'1',

			'customer_id'=>'1',

			'is_paid'=>'1',

			'paid_at'=> date('Y-m-d H:i:s')));

	}

}