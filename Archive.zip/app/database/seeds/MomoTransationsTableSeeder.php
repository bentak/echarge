<?php

class MomoTransationsTableSeeder extends Seeder {

	public function run()
	{
		MomoTransation::truncate();

		MomoTransation::create(array(
			'amount'=>'200',

			'charges'=>'5',

			'amount_after_charges'=>'205',

			'transaction_id'=>'2',

			'requst_id'=>'1',

			'response_code'=>'200',

			'description'=>'Seeded transaction',

			'client_refrence'=>'sgedfgertdhrs',

			'external_transaction_id' => 'jfj-e3434-98'));
	}

}