<?php

class DistrictsTableSeeder extends Seeder {

	public function run()
	{
		DB::table('districts')->truncate();
		
		//accra west
		DB::table('districts')->insert(array(
		    array('ecg_region_id' => 1, 'name' => 'Korle-bu', 'description' => 'Korle-bu'),
		    array('ecg_region_id' => 1, 'name' => 'Kaneshie', 'description' => 'Kaneshie'),
		    array('ecg_region_id' => 1, 'name' => 'Dansoman', 'description' => 'Dansoman'),
		    array('ecg_region_id' => 1, 'name' => 'Bortianor', 'description' => 'Bortianor'),
		    array('ecg_region_id' => 1, 'name' => 'Achimota', 'description' => 'Achimota'),
		    array('ecg_region_id' => 1, 'name' => 'Nsawam', 'description' => 'Nsawam'),
		));

		//accra east
		DB::table('districts')->insert(array(
		    array('ecg_region_id' => 2, 'name' => 'Tema North', 'description' => 'Tema North'),
		    array('ecg_region_id' => 2, 'name' => 'Tema North', 'description' => 'Tema North'),
		    array('ecg_region_id' => 2, 'name' => 'Nungua', 'description' => 'Nungua'),
		    array('ecg_region_id' => 2, 'name' => 'Ada', 'description' => 'Ada'),
		    array('ecg_region_id' => 2, 'name' => 'Prampram', 'description' => 'Prampram'),
		    array('ecg_region_id' => 2, 'name' => 'Afienya', 'description' => 'Afienya'),
		));

		//Tema
		DB::table('districts')->insert(array(
		    array('ecg_region_id' => 3, 'name' => 'Tema North', 'description' => 'Tema North'),
		    array('ecg_region_id' => 3, 'name' => 'Tema North', 'description' => 'Tema North'),
		    array('ecg_region_id' => 3, 'name' => 'Nungua', 'description' => 'Nungua'),
		    array('ecg_region_id' => 3, 'name' => 'Ada', 'description' => 'Ada'),
		    array('ecg_region_id' => 3, 'name' => 'Prampram', 'description' => 'Prampram'),
		    array('ecg_region_id' => 3, 'name' => 'Afienya', 'description' => 'Afienya'),
		));
	}

}