<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Messaging {
    
    const CLIENT_SECRET ="cwrtmanw";
    
    const CLIENT_ID ="bqgomiqo";
    //Origgin E-Prepaid Account verification code
    public function sendQuickSMSto($contact,$message) {
        
        $trim = ltrim($contact, "0");
        $contact_with_code = "+233$trim";        
        $content = "$message is your E-Prepaid account verification code.";
        $url_enc = urlencode($content);
        
        $quick_url = "https://api.hubtel.com/v1/messages/send?";
        $quick_url .= "From=E-Prepaid&To=$contact_with_code&";
        $quick_url .= "Content=$url_enc&ClientId=".Messaging::CLIENT_ID."&";
        $quick_url .= "ClientSecret=".Messaging::CLIENT_SECRET."&RegisteredDelivery=False";
    
        $curl = curl_init($quick_url);
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
        curl_setopt( $curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CAINFO, $_SERVER['DOCUMENT_ROOT'] ."/cacert.pem");
        //Execute the request.
        $results = curl_exec($curl);
        // get curl error if any
        $error = curl_error($curl);
        
        //Close the cURL handle.
        curl_close($curl);

        $sent_response = NULL;
        
        if(strlen($results)>0) {
            $sent_response = json_decode($results);
            
            if(!is_null($sent_response)) {
                
               //return array('sent'=>$sent_response->Status=='0'?'yes':'no','message'=>$sent_response->MessageId);
              return array('sent'=>'yes','message'=>$results);
               
            } else {
                return array('sent'=>'no','message'=>$results);
            }

        } else {
            return array('sent'=>'no','message'=>$error);
        }            
           
    }
    
    public function sendSoldSMS($contact,$meter,$amount) {
        
        $trim = ltrim($contact, "0");
        $contact_with_code = "+233$trim";        
        $content = "Your meter $meter has been credited with GHc$amount.";
        $url_enc = urlencode($content);
        
        $quick_url = "https://api.hubtel.com/v1/messages/send?";
        $quick_url .= "From=E-Prepaid&To=$contact_with_code&";
        $quick_url .= "Content=$url_enc&ClientId=".Messaging::CLIENT_ID."&";
        $quick_url .= "ClientSecret=".Messaging::CLIENT_SECRET."&RegisteredDelivery=False";
    
        $curl = curl_init($quick_url);
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
        curl_setopt( $curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CAINFO, $_SERVER['DOCUMENT_ROOT'] ."/cacert.pem");
        //Execute the request.
        $results = curl_exec($curl);
        // get curl error if any
        $error = curl_error($curl);
        
        //Close the cURL handle.
        curl_close($curl);

        $sent_response = NULL;
        
        if(strlen($results)>0) {
            $sent_response = json_decode($results);
            
            if(!is_null($sent_response)) {
                
               //return array('sent'=>$sent_response->Status=='0'?'yes':'no','message'=>$sent_response->MessageId);
              return array('sent'=>'yes','message'=>$results);
               
            } else {
                return array('sent'=>'no','message'=>$results);
            }

        } else {
            return array('sent'=>'no','message'=>$error);
        }            
           
    }
    
    public function sendRefundSMS($contact,$meter,$amount) {
        
        $trim = ltrim($contact, "0");
        $contact_with_code = "+233$trim";        
        $content = "Your GHc$amount prepaid top up for meter $meter was unsuccessful. Try again later.";
        $url_enc = urlencode($content);
        
        $quick_url = "https://api.hubtel.com/v1/messages/send?";
        $quick_url .= "From=E-Prepaid&To=$contact_with_code&";
        $quick_url .= "Content=$url_enc&ClientId=".Messaging::CLIENT_ID."&";
        $quick_url .= "ClientSecret=".Messaging::CLIENT_SECRET."&RegisteredDelivery=False";
    
        $curl = curl_init($quick_url);
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
        curl_setopt( $curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_CAINFO, $_SERVER['DOCUMENT_ROOT'] ."/cacert.pem");
        //Execute the request.
        $results = curl_exec($curl);
        // get curl error if any
        $error = curl_error($curl);
        
        //Close the cURL handle.
        curl_close($curl);

        $sent_response = NULL;
        
        if(strlen($results)>0) {
            $sent_response = json_decode($results);
            
            if(!is_null($sent_response)) {
                
               //return array('sent'=>$sent_response->Status=='0'?'yes':'no','message'=>$sent_response->MessageId);
              return array('sent'=>'yes','message'=>$results);
               
            } else {
                return array('sent'=>'no','message'=>$results);
            }

        } else {
            return array('sent'=>'no','message'=>$error);
        }            
           
    }
    
    
    private function send($url) {           
            
            
            $request_url = $url;
       
            $curl = curl_init($request_url);
            
            //curl_setopt( $curl, CURLOPT_POST, true );  
            //curl_setopt( $curl, CURLOPT_POSTFIELDS, json_encode(self::$MazzumaRequestOptions) );  
            curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
            curl_setopt( $curl, CURLOPT_HTTPHEADER, array(                
                'Cache-Control: no-cache',
                'Content-Type: application/json',
              ));

            //disable SSL check CURLOPT_SSL_VERIFYPEER => false
            curl_setopt($curl, CURLOPT_CAINFO, $_SERVER['DOCUMENT_ROOT'] ."/cacert.pem");
            //Execute the request.
            $results = curl_exec($curl);

            $error = curl_error($curl);

            //Close the cURL handle.
            curl_close($curl);

            return array('data'=>$results,'error'=>$error);
        }
       
}
