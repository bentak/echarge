<?php
include_once 'dbconnect.php';

class DeniedRequestController extends \BaseController {   
    
    public function unblock($customerid,$phone){  
                
            $db = new DBConnector();

            $add_block = array(
                'blocked_customer'=>$customerid,
                'blocked_contact'=>$phone,
                'block_status'=>0,
                'created_at'=>date('Y-m-d H:i:s')
            );
               
            $block_added = $db->Insert($add_block,"blocked_lists");
            
            if(is_int($block_added)) {
                $where = array('customer_id',$customerid,'is_paid'=>0);
             
                $db->Delete('requsts',$where);
            }
            
            return Redirect::back();
        }
        
        public function addBlock($customerid,$phone){  
                
            $db = new DBConnector();

            $add_block = array(
                'blocked_customer'=>$customerid,
                'blocked_contact'=>$phone,
                'block_status'=>1,
                'created_at'=>date('Y-m-d H:i:s')
            );
               
            $block_added = $db->Insert($add_block,"blocked_lists");
            
//            if(is_int($block_added)) {
//                $where = array('customer_id',$customerid,'is_paid'=>0);
//             
//                $db->Delete('requsts',$where);
//            }
            
            return Redirect::back();
        }
        
        public function addBlockException($phone){

            $db = new DBConnector();

            $add_exc = array(               
                'block_exception'=>1                
            );
               
            $where = array(               
                'phone'=>$phone
            );
               
            $block_added = $db->Update($add_exc,"customers",$where);          
           
            
            return Redirect::back();
            
        }
        
        public function removeBlockException($phone){

            $db = new DBConnector();

            $add_exc = array(               
                'block_exception'=>0               
            );
               
            $where = array(               
                'phone'=>$phone
            );
               
            $block_added = $db->Update($add_exc,"customers",$where);          
           
            
            return Redirect::back();
            
        }
    
	/**
	 * Display a listing of customers
	 *
	 * @return Response
	 */
	public function index($from="",$to="")
	{
            $data['pagetab'] = 'requests';
             $data['requests'] = strlen($from)==0 && strlen($to)==0 ?
                    DeniedRequest::where('created_at','>=',date('Y-m-d 00:00:00'))->where('created_at','<=',date('Y-m-d 23:59:59'))->orderBy('id','DESC')->get():                    
                    DeniedRequest::where('created_at','>=',date($from.' 00:00:00'))->where('created_at','<=',date($to.' 23:59:59'))->orderBy('id','DESC')->get();
            
            //$data['requests'] = DeniedRequest::orderBy('id','DESC')->get();

            $data['from'] = strlen($from)==0?date('Y-m-d'): $from;
            $data['to'] = strlen($to)==0?date('Y-m-d'): $to;
            
            return View::make('denied_requests.index', $data);
	}

	/**
	 * Show the form for creating a new customer
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('blocked_list.create');
	}

	/**
	 * Store a newly created customer in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), Customer::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		Customer::create($data);

		return Redirect::route('blocked_list.index');
	}

	/**
	 * Display the specified customer.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$customer = Customer::findOrFail($id);

		return View::make('blocked_list.show', compact('customer'));
	}

	/**
	 * Show the form for editing the specified customer.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$customer = Customer::find($id);

		return View::make('blocked_list.edit', compact('customer'));
	}

	/**
	 * Update the specified customer in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$customer = Customer::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Customer::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$customer->update($data);

		return Redirect::route('customers.index');
	}

	/**
	 * Remove the specified customer from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Customer::destroy($id);

		return Redirect::route('customers.index');
	}

	public function apiPostCustomerSignup(){
		$validator = Validator::make($data = Input::all(), Customer::$rules);
                
                
		if ($validator->fails())
		{
			return json_encode(array('customer_created'=>'no','status'=>400,'errors'=>$validator->messages()));
		}

		$data['customer_token'] = Customer::createToken();
		$customer = Customer::create($data);

		return json_encode(array('customer_created'=>'yes','status'=>200,'customer'=>$customer));
	}


	public function apiPostCustomerSignin(){
		$validator = Validator::make($data = Input::all(), Customer::$signinRules);

		if ($validator->fails())
		{
			return json_encode(array('customer_exists'=>'no','status'=>400,'errors'=>$validator->messages()));
		}

		$customer = Customer::where('phone',$data['phone']);

		if(count($customer->get())>0){
			$customer = $customer->first();//return Hash::make($data['password']).'----'.$customer->password;
			
			if($customer->checkPassword($data['password'])){
				return json_encode(array('customer_exists'=>'yes','status'=>200,'customer'=>$customer));
			}

			return json_encode(array('customer_exists'=>'no','status'=>401,'errors'=>NULL));
		}

		return json_encode(array('customer_exists'=>'no','status'=>400,'errors'=>NULL));
	}

	public function apiGetCustomer($token){
		$temp = Customer::where('customer_token',$token);

		if(count($temp->get())>0){
			$customer = $temp->first();
			return Response::json(array('customer_exists'=>'yes','status'=>200,'customer'=>$customer));
		}

		return json_encode(array('customer_exists'=>'no','status'=>400));
	}

	public function apiPostCustomerUpdate($token)
	{
		$temp = Customer::where('customer_token',$token);

		if(count($temp->get())>0){
			$customer = $temp->first();

			$data = Input::all();

			$rules = Customer::$apiUpdateRules2;

			if(isset($data['email']) && $customer->email == $data['email']) $rules = Customer::$apiUpdateRules1;

			$validator = Validator::make($data, $rules);

			if ($validator->fails())
			{
				return json_encode(array('customer_updated'=>'no','status'=>400,'errors'=>$validator->messages()));
			}

			$data['type_id'] = $customer->type_id;
			$data['customer_token'] = $customer->customer_token;

			$customer->update($data);

			return Response::json(array('customer_updated'=>'yes','status'=>200,'customer'=>$customer));
		}

		return json_encode(array('customer_updated'=>'no','status'=>400, 'errors' => 'Invalid token' ));

		
	}

	public function api2GetCustomerSales($token){
		$temp = Customer::with('sales','sales.items')->where('token',$token);

		if(count($temp->get())>0){
			$customer = $temp->first();
			return Response::json(Sale::with('items')->where('customer_id',$customer->id)->where('submitted',1)->get());
		}

		return json_encode(array('customer_exists'=>'no','status'=>200));
	}

}
