<?php

include_once 'dbconnect.php';

class NsanoPaymentController extends \BaseController {

    const API_KEY ="c7fea5f69fd545e881de2a36d77e1c08";

    private $NsanoCreditRequestOptions = array(
        'kuwaita'=>'mikopo',
        'amount'=>'',
        'mno'=>'',
        'refID'=>'',
        'msisdn'=>''            
        );
        
        private $NsanoDebitRequestOptions = array(
        'kuwaita'=>'malipo',
        'amount'=>'',
        'mno'=>'',
        'authToken'=>'',
        'msisdn'=>''            
        );
        
        private $MPayDebitRequestOptions = array(
        'merchantId'=>'origgin',
        'amount'=>'',
        'network'=>'MTN',
        'narration'=>'Payment',
        'msisdn'=>'',         
        'transactionId'=>'',         
        'source'=>'CALLBACK'            
        );
        
        private $NsanoCallbackResponse = array(
        'kuwaita'=>'kusubiri_mikopo',
        'code'=>'00',
        'msg'=>'Debit Successful',
        'metadataID'=>''            
        );
        
        private $NsanoResponseCode = array(
        '00'=>'Success',
        '01'=>'Failed',
        '02'=>'Error',
        '03'=>'Pending',
        '05'=>'Connection Error'            
        );
        
        public function AddNsanoDebitTransaction($request,$response){
		
            $data = array();                
                
                $origgin_charge = MomoTransation::getOrigginFee(doubleval(str_replace(',', '', $request->amount)));
                
                $api_charges = doubleval(str_replace(',', '', $request->amount))+$origgin_charge <= 50.00 ? 0.5: 0.015*(doubleval(str_replace(',', '', $request->amount))+$origgin_charge);
                
                $data['requst_id'] = $request->id;
		$data['ecg_amount'] = $request->type_id == 1 ?doubleval(str_replace(',', '', $request->amount)):0.00;
		$data['origgin_charge'] = $request->type_id == 1 ?$origgin_charge:1.00;
                
		$data['amount'] = $request->type_id == 1 ? doubleval(str_replace(',', '', $request->amount)) + $origgin_charge:1.00;
		$data['charges'] = $api_charges;
		$data['amount_after_charges'] = $request->type_id == 1 ? doubleval(str_replace(',', '', $request->amount)) + $origgin_charge:1.00;
		$data['transaction_id'] = $response->reference;
		$data['response_code'] = '0003'; //pending	
		$data['client_refrence'] = $response->reference;
		//$data['external_transaction_id'] = $temp_data['Data']['SalesInvoiceId'];
                $data['pay_number'] = Input::get('mm_number');
                $data['payment_type'] = 3;
                $data['network'] = Input::get('mm_network');
		
                
		$transaction = MomoTransation::create($data);

//                $db = new DBConnector();
//                $transaction = $db->Insert($data, 'momo_transations');
         

		return $transaction;
		
	}
        
        public function AddMPayDebitTransaction($request,$response){
		$data = array();                
                
                $origgin_charge = MomoTransation::getOrigginFee(doubleval(str_replace(',', '', $request->amount)));
                
                $api_charges = doubleval(str_replace(',', '', $request->amount))+$origgin_charge <= 50.00 ? 0.5: 0.015*(doubleval(str_replace(',', '', $request->amount))+$origgin_charge);
                
                $data['requst_id'] = $request->id;
		$data['ecg_amount'] = $request->type_id == 1 ?doubleval(str_replace(',', '', $request->amount)):0.00;
		$data['origgin_charge'] = $request->type_id == 1 ?$origgin_charge:1.00;
                
		$data['amount'] = $request->type_id == 1 ? doubleval(str_replace(',', '', $request->amount)) + $origgin_charge:1.00;
		$data['charges'] = $api_charges;
		$data['amount_after_charges'] = $request->type_id == 1 ? doubleval(str_replace(',', '', $request->amount)) + $origgin_charge:1.00;
		$data['transaction_id'] = $request->request_id;
		$data['response_code'] = '0003'; //pending	
		$data['client_refrence'] = $request->request_id;
		//$data['external_transaction_id'] = $temp_data['Data']['SalesInvoiceId'];
                $data['pay_number'] = Input::get('mm_number');
                $data['payment_type'] = 3;
                $data['network'] = Input::get('mm_network');
		
                
		$transaction = MomoTransation::create($data);

//                $db = new DBConnector();
//                $transaction = $db->Insert($data, 'momo_transations');
         

		return $transaction;
		
	}
         
        public function NsanoDebitCallback(){            
            
		$response_data = Input::all();
                
                $callback_response = file_get_contents('php://input');
                
                $file_date = PHP_EOL."Callback received at: ".date('Y-m-d H:i:s').PHP_EOL."Host : ".(array_key_exists('REMOTE_HOST', $_SERVER)?$_SERVER['REMOTE_HOST']:"").PHP_EOL."Address : ".$_SERVER['REMOTE_ADDR'].PHP_EOL;
                
                $log_file = file_put_contents($_SERVER['DOCUMENT_ROOT']."/Callback_log.txt", $file_date.$callback_response.PHP_EOL , FILE_APPEND | LOCK_EX);
                
                                
                $validator = Validator::make($response_data, MomoTransation::$callback_rules);

		if ($validator->fails())
		{

                    return json_encode(array('code'=>'01','msg'=>$validator->messages()));
		}               
                
                $transaction = MomoTransation::where('client_refrence',$response_data['reference'])->first();
                
                //return var_dump($transaction);
                
                if($transaction == NULL) {
                    
                   return json_encode(array('code'=>'01','msg'=>'Invalid Reference ID.'));
                
                }
                
                $request = Requst::where('id',$transaction->requst_id)->first();                
                
						               
                $transaction->description = urldecode($response_data['msg']);
                
		if($response_data['code'] == '00'){
                    $transaction->response_code = '0000';
                    $transaction->transaction_id = $response_data['transactionID'];                    
                    
                    $request->is_paid = 1;
                    $request->paid_at = date('Y-m-d H:i:s');
                    
                    $request->save();
                    $transaction->save();
                    
                     return json_encode(array('code'=>'03','msg'=>'Pending'));
                     
		} else {                    
                    $transaction->response_code = '0004';
                    $transaction->save();
                    return json_encode(array('code'=>'01','msg'=>'Failed'));
                }
                
                //default return when 
                return json_encode(array('code'=>'01','msg'=>'Failed'));
	}
        
         public function MPayDebitCallback() {            
            
		$response_data = Input::all();
                
                $tracker = $response_data['tracker'];
                
                $callback_response = file_get_contents('php://input');
                
                $file_date = PHP_EOL."Callback received at: ".date('Y-m-d H:i:s').PHP_EOL."Host : ".(array_key_exists('REMOTE_HOST', $_SERVER)?$_SERVER['REMOTE_HOST']:"").PHP_EOL."Address : ".$_SERVER['REMOTE_ADDR'].PHP_EOL;
                
                $log_file = file_put_contents($_SERVER['DOCUMENT_ROOT']."/MPayCallback_log.txt", $file_date.$callback_response.PHP_EOL , FILE_APPEND | LOCK_EX);
                
                $transaction = MomoTransation::where('requst_id',$tracker)->first();
                
                //return var_dump($transaction);
                
                if($transaction == NULL) {
                    
                   echo json_encode(array('responseCode'=>'01','responseMessage'=>'Callback received.'));
                   exit();
                }
                
                $request = Requst::where('id',$transaction->requst_id)->first();                
                
						               
                $transaction->description = urldecode($response_data['responseMessage']);
                
		if($response_data['responseCode'] == "000"){
                    $transaction->response_code = '0000';
                    //$transaction->transaction_id = $response_data['transactionID'];                    
                    
                    $request->is_paid = 1;
                    $request->paid_at = date('Y-m-d H:i:s');
                    
                    $request->save();
                    $transaction->save();
                    
                     echo json_encode(array('responseCode'=>'01','responseMessage'=>'Callback received.'));
                     exit();
                     
		} else {                    
                    $transaction->response_code = '0004';
                    $transaction->save();
                    
                    echo json_encode(array('responseCode'=>'01','responseMessage'=>'Callback received.'));
                     exit();
                }
                
                //default return when 
                echo json_encode(array('responseCode'=>'01','responseMessage'=>'Callback received.'));
                exit();
	}
        
        public function PaymentCheckout($referenceid) {
            
            $data = Input::all();
            
            if($data['mm_network'] == 'mtn') {
                $this->MPayPaymentCheckout($referenceid);
            } else {
                $this->NsanoPaymentCheckout($referenceid);
            }  
        }
                
        public function NsanoPaymentCheckout($referenceid) {
            
            $data = Input::all();          
            
            
            $validator = Validator::make($data, MomoTransation::$payment_rules);
            
            if ($validator->fails())
            {
                return json_encode(array('success'=>'no','status'=>400,'errors'=>$validator->messages()));
            }
            
            $request = Requst::where('request_id',$referenceid)->first();
            
            if($request != NULL) {                
                
                $transaction = MomoTransation::where('requst_id',$request->id)->get();
                
                $tp = $transaction->first();
                
                if(count($transaction)>0) {
                    
                    if($tp->response_code=='0000'){
                        
                        echo  json_encode(array(
                         'success'=>'yes',                    
                         'status'=>200,
                         'message'=> 'Payment successful.'
                     )); 
                    }
                    else if($tp->response_code=='0003'){
                            
                             echo json_encode(array(
                             'success'=>'no',
                             'status'=>300,
                             'message'=> 'Payment pending.'
                                 ));
                                 
                        } else if($tp->response_code=='0004'){
                             echo json_encode(array(
                             'success'=>'no',
                             'status'=>400,
                             'message'=> 'Payment failed.'
                                 ));
                        }

                    }
                
              $origgin_fee = MomoTransation::getOrigginFee(doubleval(str_replace(',', '', $request->amount)));
            
              $option = $this->getNetworkOption();
              
              $cost = $request->type_id==1 ? doubleval(doubleval(str_replace(',', '', $request->amount)) + $origgin_fee) : 1.00;
         
              $token = "";
              
              if(array_key_exists("token", $data)) {
                  
                  if(strlen($data['token'])>0)
                      $token = $data['token'];
              }
              
            $this->NsanoDebitRequestOptions['mno']=$option;
            //$this->NsanoDebitRequestOptions['amount'] = $cost <= 50.00 ? number_format($cost-0.5,2): number_format($cost - (0.015*$cost), 2);
            $this->NsanoDebitRequestOptions['amount'] = number_format($cost,2) ;
            $this->NsanoDebitRequestOptions['msisdn'] = $data['mm_number'];
            $this->NsanoDebitRequestOptions['authToken'] =  $token;
     
           //initiate payement request to Nsano
            $payment_response = $this->sendRequest();            
            
            $log_msg = "HTTP_STATUS: ".$payment_response['http_status']. " \n ERROR_NUMBER: ".$payment_response['error_no']." \n Error message-".$payment_response['error']." \n Success message-".$payment_response['data'];
            
            $file_date = PHP_EOL."Response received at: ".date('Y-m-d H:i:s').PHP_EOL."Host : ".(array_key_exists('REMOTE_HOST', $_SERVER)?$_SERVER['REMOTE_HOST']:"").PHP_EOL."Address : ".$_SERVER['REMOTE_ADDR'].PHP_EOL;
                
            $log_file = file_put_contents($_SERVER['DOCUMENT_ROOT']."/Request_log.txt", $file_date.$log_msg.PHP_EOL , FILE_APPEND | LOCK_EX);
            
            if(strlen($payment_response['error'])>0) {
                echo json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=>$payment_response['error']."-".$payment_response['http_status']."-".$payment_response['error_no']
                                    )
                                    );
            } 
            else if(is_object($payment_response['data']) || strlen($payment_response['data'])>0){
                                
                $response_data = json_decode($payment_response['data']);                
                          
                if(is_object($response_data) && !is_null($response_data)) {                    
                                        
                    if($response_data->code!=00) {

                        echo json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Payment failed. ' . $response_data->msg
                                ));
                    }
                    
                    $this->AddNsanoDebitTransaction($request, $response_data);
                  
                    echo json_encode(array(
                     'success'=>'no',                    
                     'status'=>300,
                     'message'=> 'Payment pending.'
                    ));
                } 
                else {
                    
                    echo json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Payment failed.-line 241-'.$response_data
                                ));
                }
                
            } else {
                
                echo json_encode(array(
                         'success'=>'no',                    
                         'status'=>400,
                         'message'=> 'payment failed - line 250-'.$payment_response['data']
                     )); 
            }
              
              
            } else {
                
                echo json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=> 'Invalid request token.'
                                    ));
                
            }
            
             
                
        }
        
        public function MPayPaymentCheckout($referenceid) {
            
            $data = Input::all();            
            
            $validator = Validator::make($data, MomoTransation::$payment_rules);
            
            if ($validator->fails())
            {
                return json_encode(array('success'=>'no','status'=>400,'errors'=>$validator->messages()));
            }
            
            $request = Requst::where('request_id',$referenceid)->first();
            
            if($request != NULL) {                
                
                $transaction = MomoTransation::where('requst_id',$request->id)->get();
                
                $tp = $transaction->first();
                
                if(count($transaction)>0) {
                    
                    if($tp->response_code=='0000'){
                        
                         echo json_encode(array(
                         'success'=>'yes',                    
                         'status'=>200,
                         'message'=> 'Payment successful.'
                     )); 
                    }
                    else if($tp->response_code=='0003'){
                            
                             echo json_encode(array(
                             'success'=>'no',
                             'status'=>300,
                             'message'=> 'Payment pending. - line 373'
                                 ));
                                 
                        } else if($tp->response_code=='0004'){
                             echo json_encode(array(
                             'success'=>'no',
                             'status'=>400,
                             'message'=> 'Payment failed.-- line 382'
                                 ));
                        }

                    }
                
              $origgin_fee = MomoTransation::getOrigginFee(doubleval(str_replace(',', '', $request->amount)));
            
              //$option = $this->getNetworkOption();
              
              $cost = $request->type_id==1 ? doubleval(doubleval(str_replace(',', '', $request->amount)) + $origgin_fee) : 1.00;

            //$this->NsanoDebitRequestOptions['amount'] = $cost <= 50.00 ? number_format($cost-0.5,2): number_format($cost - (0.015*$cost), 2);
            $this->MPayDebitRequestOptions['amount'] = $cost ;
            $this->MPayDebitRequestOptions['msisdn'] = "233".ltrim($data['mm_number'], "0");
            $this->MPayDebitRequestOptions['transactionId'] =  $request->id;
     
           //initiate payement request to Nsano
            $payment_response = $this->sendMpayRequest();            
            
            $log_msg = "HTTP_STATUS: ".$payment_response['http_status']. " \n ERROR_NUMBER: ".$payment_response['error_no']." \n Error message-".$payment_response['error']." \n Success message-".$payment_response['data'];
            
            $file_date = PHP_EOL."Response received at: ".date('Y-m-d H:i:s').PHP_EOL."Host : ".(array_key_exists('REMOTE_HOST', $_SERVER)?$_SERVER['REMOTE_HOST']:"").PHP_EOL."Address : ".$_SERVER['REMOTE_ADDR'].PHP_EOL;
                
            $log_file = file_put_contents($_SERVER['DOCUMENT_ROOT']."/MPayRequest_log.txt", $file_date.$log_msg.PHP_EOL , FILE_APPEND | LOCK_EX);
            
//            print_r($payment_response);
//            exit();
                
            if(strlen($payment_response['error'])>0) {
                echo $payment_response['error'];
                exit();
                echo json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=>$payment_response['error']."-".$payment_response['http_status']."-".$payment_response['error_no']
                                    )
                                    );
            } 
            else if(is_object($payment_response['data']) || strlen($payment_response['data'])>0){
                                
                $response_data = json_decode($payment_response['data']);                
                        
//                echo $payment_response['data'];
//                exit();
//                
                if(is_object($response_data) && !is_null($response_data)) {                    
                                        
                    if($response_data->responseCode != "09") {

                        echo json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Payment failed. ' . $response_data->responseMessage
                                ));
                    }
                    
                    $this->AddMPayDebitTransaction($request, $response_data);
                  
                    echo json_encode(array(
                     'success'=>'no',                    
                     'status'=>300,
                     'message'=> 'Payment pending.'
                    ));
                } 
                else {
                    
                    echo json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Payment failed.-line 481-'.$response_data
                                ));
                }
                
            } else {
                
                echo json_encode(array(
                         'success'=>'no',                    
                         'status'=>400,
                         'message'=> 'payment failed - line 490 - '.$payment_response['data']
                     )); 
            }
              
              
            } else {
                
                echo json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=> 'Invalid request token.'
                                    ));
                
            }
            
             
                
        }
        
        
        public function CheckPaymentStatus($referenceid) {
            
            //check if payment was successful
            
            $request = Requst::where('request_id',$referenceid)->get();
            
            if(count($request)==0) {
                return json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Invalid Request id.'
                                ));
            }
            
            $rq = $request->first();
            
            $transaction = MomoTransation::where('requst_id',$rq->id)->get();
            
            
            if(count($transaction)==0) {
                return json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Transaction not found.'
                                ));
            }
            
            $response = array();
            
            $tp = $transaction->first();
             
            switch ($tp->response_code) {
                
                case "0003":
                    $response = array(
                            'success'=>'no',
                            'status'=>300,
                            'message'=>'Payment pending.'
                                );
                    break;
                
                case "0004":
                    $response = array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Payment failed.'
                                );
                    break;
                case "0000":
                    $response = array(
                            'success'=>'yes',
                            'status'=>200,
                            'message'=>'Payment successful.'
                                );
                    break;
                default :
                    $response = array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Payment failed.'
                                );
                    break;
            }
            
             return json_encode($response);
        }
        
        
        public function SendSuccessNotification($referenceid) {
            $this->NsanoCallbackResponse['metadataID'] = $referenceid;
            
            $response = $this->sendResponse();
            
            if(strlen($response['data'])>0) {               
            
                $response_data = json_decode($response['data']);                
                          
                if(is_object($response_data) && !is_null($response_data)) {                    
                                        
                    return array('sent'=>$response_data->code==00 ? 'yes' : 'no','message'=>$response_data->msg);                   
                
                }
                
            } else {
                return array('sent'=> 'no','message'=>$response['error']);
            }
        }
        
        public function SendFailedNotification($referenceid) {
            
            $this->NsanoCallbackResponse['metadataID'] = $referenceid;
            $this->NsanoCallbackResponse['code'] = '01';
            $this->NsanoCallbackResponse['msg'] = 'Debit Failed';
            
            $response = $this->sendResponse();
            
            if(strlen($response['data'])>0) {               
            
                $response_data = json_decode($response['data']);                
                          
                if(is_object($response_data) && !is_null($response_data)) {                    
                                        
                    return array('sent'=>$response_data->code==00 ? 'yes' : 'no','message'=>$response_data->msg);                  
                
                }
                
            } else {
               return array('sent'=> 'no','message'=>$response['error']);    
            }
        }
        
        public function SendMPayRefund($transaction) {
            $amount = doubleval(str_replace(',', '', $transaction->amount));
            $this->MPayDebitRequestOptions['amount'] = rtrim($amount,".00") ;
            $this->MPayDebitRequestOptions['msisdn'] = "233".ltrim($transaction->pay_number, "0"); //"233553424376";
            $this->MPayDebitRequestOptions['transactionId'] = "10100$transaction->requst_id";
            $this->MPayDebitRequestOptions['narration'] = "Payout";
     
//            print_r($this->MPayDebitRequestOptions);            
//            exit();
            
            $response = $this->sendMPayResponse();
            
            if(strlen($response['data'])>0) {               
            
                $response_data = json_decode($response['data']);                
                          
                if(is_object($response_data) && !is_null($response_data)) {                    
                                        
                    return array('sent'=>$response_data->responseCode=="01" ? 'yes' : 'no','message'=>$response_data->responseMessage);                  
                
                }
                
            } else {
               return array('sent'=> 'no','message'=>$response['error']);    
            }
        }




        private function sendRequest() {
            
             $user_agent = $_SERVER['HTTP_USER_AGENT'];
             
            //$request_url = "https://fs.nsano.com:5000/api/fusion/tp/".NsanoPaymentController::API_KEY;
            $request_url = "https://portals1.nsano.com/originn/api/fusion/tp/".NsanoPaymentController::API_KEY;
       
            $curl = curl_init($request_url);
            
            curl_setopt( $curl, CURLOPT_POST, true );  
            curl_setopt( $curl, CURLOPT_POSTFIELDS, json_encode($this->NsanoDebitRequestOptions) );  
            curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
            curl_setopt( $curl, CURLOPT_HTTPHEADER, array(               
                'Cache-Control: no-cache',
                'Content-Type: application/json',
              ));

           curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
           //curl_setopt($curl, CURLOPT_USERAGENT, $user_agent);
           //curl_setopt($curl, CURLOPT_PROXY, "https://portals.nsano.com/api/fusion/tp/".NsanoPaymentController::API_KEY); //your proxy url
           //curl_setopt($curl, CURLOPT_PROXYPORT, "5000");
           
           //curl_setopt($curl, CURLOPT_CAINFO, $_SERVER['DOCUMENT_ROOT'] ."/cacert.pem");
           
        //Execute the request.
        $results = curl_exec($curl);
        
        $error = curl_error($curl);
        
        $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        
        $curl_errno = curl_errno($curl);

        //Close the cURL handle.
        curl_close($curl);
        
        return array('data'=>$results,'error'=>$error,'http_status'=>$http_status,'error_no'=>$curl_errno);
    }
    
    private function sendMpayRequest() {
        $basic_auth_key =  'Basic ' . base64_encode('origgin:@0r!gg!n@tGH@na');
        //$user_agent = $_SERVER['HTTP_USER_AGENT'];

        $request_url = "https://app.mtopup.net/external/payments/api/v1/charge/";

        $curl = curl_init($request_url);

        curl_setopt( $curl, CURLOPT_POST, TRUE );  
        curl_setopt( $curl, CURLOPT_POSTFIELDS, json_encode($this->MPayDebitRequestOptions) );  
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, TRUE );
        curl_setopt( $curl, CURLOPT_HEADER, FALSE );
        curl_setopt( $curl, CURLOPT_HTTPHEADER, array(               
            'Cache-Control: no-cache',
            'Authorization: '.$basic_auth_key,
            'Content-Type: application/json',
          ));

       curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
           
        $results = curl_exec($curl);
        
        $error = curl_error($curl);
        
        $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        
        $curl_errno = curl_errno($curl);

        //Close the cURL handle.
        curl_close($curl);
        
        return array('data'=>$results,'error'=>$error,'http_status'=>$http_status,'error_no'=>$curl_errno);
    }
    
    private function sendResponse() {
            
             
            $request_url = "https://portals1.nsano.com/originn/api/fusion/tp/".NsanoPaymentController::API_KEY;
       
            $curl = curl_init($request_url);
            
            curl_setopt( $curl, CURLOPT_POST, true );  
            curl_setopt( $curl, CURLOPT_POSTFIELDS, json_encode($this->NsanoCallbackResponse) );  
            curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
            curl_setopt( $curl, CURLOPT_HTTPHEADER, array(               
                'Cache-Control: no-cache',
                'Content-Type: application/json',
              ));

        //Execute the request.
        $results = curl_exec($curl);
        
        $error = curl_error($curl);

        //Close the cURL handle.
        curl_close($curl);
        
        $file_date = PHP_EOL.(strlen($results)>0?"Success ":"Error ")." Callback response received at: ".date('Y-m-d H:i:s').PHP_EOL;
        file_put_contents($_SERVER['DOCUMENT_ROOT']."/Callback_response_log.txt", $file_date.(strlen($results)>0?$results:$error).PHP_EOL , FILE_APPEND | LOCK_EX);
                
        
        return array('data'=>$results,'error'=>$error);
    }
    
    private function sendMPayResponse() {
       $basic_auth_key =  'Basic ' . base64_encode('origgin:@0r!gg!n@tGH@na');
        //$user_agent = $_SERVER['HTTP_USER_AGENT'];

        $request_url = "https://app.mtopup.net/external/payments/api/v1/payout/";

        $curl = curl_init($request_url);

        curl_setopt( $curl, CURLOPT_POST, TRUE );  
        curl_setopt( $curl, CURLOPT_POSTFIELDS, json_encode($this->MPayDebitRequestOptions) );  
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, TRUE );
        curl_setopt( $curl, CURLOPT_HEADER, FALSE );
        curl_setopt( $curl, CURLOPT_HTTPHEADER, array(               
            'Cache-Control: no-cache',
            'Authorization: '.$basic_auth_key,
            'Content-Type: application/json',
          ));

       curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
           
        $results = curl_exec($curl);
        
        $error = curl_error($curl);
        
        $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        
        $curl_errno = curl_errno($curl);
        
        $file_date = PHP_EOL.(strlen($results)>0?"Success ":"Error ")." Refund response received at: ".date('Y-m-d H:i:s').PHP_EOL;
        file_put_contents($_SERVER['DOCUMENT_ROOT']."/MPayRefund_response_log.txt", $file_date.(strlen($results)>0?$results:$error).PHP_EOL , FILE_APPEND | LOCK_EX);
                       
        
        return array('data'=>$results,'error'=>$error);
    }
    
    
    
    private function getNetworkOption() {
            $option = '';
            
            switch (Input::get('mm_network')){
                case 'airtel': 
                    $option = 'AIRTEL';                  
                    break;
                case 'voda': 
                    $option = 'VODAFONE';                  
                    break;
                case 'tigo': 
                    $option = 'TIGO';                  
                    break;
                default :
                    $option = 'MTN';
                    break;
              }
              
              return $option;
        }

}
