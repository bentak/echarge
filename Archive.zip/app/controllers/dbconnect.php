<?php

/* Connector manages all connections to the database
*  and performs all database related operations
*
*/
//include_once 'DBCONFIG.php';


class DBConnector {
    
 //private variable to hold mysql connection
    private $connector;

    // class constructor
    function __construct()
    {
       $this->Connect();
       
    }
    
    //private function to open connection to database
    private function Connect() {
        
      $this->connector = new Mysqli('localhost','root','miniproject','origginprepaid');
    
        return $this->connector->connect_errno ? false : true;
    
    }
    
    public function Remove($id,$table) {
        
        if(strlen($id)==0 ) return;
        
         $q="UPDATE $table SET active=0 WHERE del_id=$id";
        
         $removed = $this->connector->query($q);
                 
        if($removed === TRUE) 
        {
            return true;
        } 
        else 
        {
            return $this->connector->error;
        }
        
    }   
    
    /*
    * Generic select method to execute select statements.   
    */
    public function Select($query) {
        
        //check if arguement is null
        
        if (is_null($query) || strlen($query) == 0) {
            return;
        }

        $results = array();
        //execute query
        $selected=$this->connector->query($query);
        
        if($this->connector->error == NULL) {
            if($selected != NULL)
            {
                while($row=$selected->fetch_assoc()) {

                    $results[] = $row;
                }

                return $results;
            } else {

                return $this->connector->error;
            }
        } else {
            return $this->connector->error;
        }    
        
        
    }
    
    
    public function SelectValue($query,$value) {
        
        //check if arguement is null
        
        if (is_null($query) || strlen($query) == 0) {
            return;
        }

        $results = array();
        //execute query
        $selected=$this->connector->query($query);
        
        if($this->connector->error == NULL) {
            if($selected != NULL)
            {
                $row=$selected->fetch_assoc();
                return $row[$value];
                
            } else {

                return $this->connector->error;
            }
        } else {
            return $this->connector->error;
        }    
        
        
    }
    /*
    * Generic select method to execute select statements.   
    */
    public function SelectWith($table,$where,$limit) {
        
        //check if arguement is null
        
        if (is_null($table) || strlen($table) == 0) {
            return;
        }

        foreach ($where as $key => $value)
        {
          isset($cols) ? $cols .= ' AND ' : $cols = '';
          $cols .= strlen($value)==0?'': "$key='".$this->connector->real_escape_string($value)."'";
        
        }
        
        $results = array();
        //execute query
        
        $query = "SELECT * FROM $table WHERE $cols LIMIT $limit";
             
        $selected=$this->connector->query($query);
        
        if($selected != NULL) 
        {
            while($row=$selected->fetch_assoc()) {
                
                $results[] = $row;
            }
            
            return $results;
        }
        
        return $results;
    }
    
    /*
    * Generic insert method to execute insert statements.   
    */
    public function Insert($data,$table,$data2=null) {
        
        //check if arguement is null
        
        if (!is_array($data) || count($data) == 0) {
            return;
        }

        //construct statement from argument
        $cols = implode(',', array_keys($data));
        
        foreach (array_values($data) as $value)
        {
          isset($vals) ? $vals .= ',' : $vals = '';
          $vals .= "'".$this->connector->real_escape_string($value)."'";
        }
        
        if($data2 !=NULL) {
            foreach (array_values($data2) as $value)
            {
              isset($vals2) ? $vals2 .= ',' : $vals2 = '';
              $vals2 .= "'".$this->connector->real_escape_string($value)."'";
            }
        }
        
        //return 'INSERT INTO '.$table.' ('.$cols.') VALUES ('.$vals.')';
        //execute query
        if($this->connector->query('INSERT INTO '.$table.' ('.$cols.') VALUES ('.$vals.')'.($data2!=NULL?',('.$vals2.')':''))===TRUE) 
        {
            return $this->connector->insert_id;
//            return $this->connector->query('SELECT * FROM '.$table.' JOIN sections ON section=sect_id JOIN category ON tag=cat_id WHERE id='.$id);   
        }
        else 
        {
            return $this->connector->error;   
        }
        
    }
    
    /*
    * Generic update method to execute update statements.   
    */
    public function Update($data,$table,$cond) {
        
        //check if arguement is null        
        if (!is_array($data) || count($data) == 0) {
            return;
        }

        //construct statement from argument
        //$cols = implode(',', array_keys($data));
        foreach ($data as $key => $value)
        {
          isset($vals) ? $vals .= ',' : $vals = '';
          $vals .= "$key='".$this->connector->real_escape_string($value)."'";
        }
        
        foreach ($cond as $key => $value)
        {
          isset($cols) ? $cols .= ' AND ' : $cols = '';
          $cols .= "$key='".$this->connector->real_escape_string($value)."'";
        
        }
        
        //execute query
       if($this->connector->query('UPDATE '.$table.' SET '.$vals.' WHERE '.$cols )===TRUE) 
        {
           $query = "SELECT * FROM $table WHERE $cols";
           
           $selected=$this->connector->query($query);
            if($selected != NULL)
            {               

                return $selected->fetch_assoc();
            }   
        }
        else 
        {
            return $this->connector->error;   
        }
        
    }
    
    /*
    * Generic delete method to execute delete statements.   
    */
    public function Delete($table,$where) {
        
        //check if arguement is null
        
        if (is_null($table) && count($where) == 0) {
            return;
        }
        
        foreach ($where as $key => $value)
        {
          isset($cols) ? $cols .= ' AND ' : $cols = '';
          $cols .= strlen($value)==0?'': "$key='".$this->connector->real_escape_string($value)."'";
        
        }
        
        $query = "DELETE FROM $table WHERE $cols";

        //execute query
        if($this->connector->query($query)===TRUE) 
        {
            return true;   
        }
        else 
        {
            return $this->connector->error;   
        }
    }
    
    /*
    * Generic query method to execute update statements.   
    */
    public function Query($query) {
        
        //check if arguement is null
        
        if (is_null($query) || strlen($query) == 0) {
            return;
        }

        //execute statement
        if($this->connector->query($query)===TRUE) 
        {
            return true;   
        }
        else 
        {
            return false;   
        }
        
        
    }
    
}

?>