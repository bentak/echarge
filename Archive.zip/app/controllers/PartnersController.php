<?php
include_once 'dbconnect.php';

class PartnersController extends \BaseController {

	/**
	 * Display a listing of customers
	 *
	 * @return Response
	 */
	public function index($from="",$to="")
	{
		$data['pagetab'] = 'partners';
		$data['partners'] = Partner::orderBy('id','DESC')->get();
//                $data['partners'] = strlen($from)==0 && strlen($to)==0 ?
//                    Partner::where('created_at','>=',date('Y-m-d 00:00:00'))->where('created_at','<=',date('Y-m-d 23:59:59'))->orderBy('id','DESC')->get():                    
//                    Partner::where('created_at','>=',date($from.' 00:00:00'))->where('created_at','<=',date($to.' 23:59:59'))->orderBy('id','DESC')->get();

                $data['from'] = strlen($from)==0?date('Y-m-d'): $from;
                $data['to'] = strlen($to)==0?date('Y-m-d'): $to;
            
		return View::make('partners.index', $data);
	}

	/**
	 * Show the form for creating a new customer
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('partners.create');
	}

	/**
	 * Store a newly created customer in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
            $data = Input::all();
            
            $info = array('partner_name'=>$data['partner_name'],
                'partner_email'=>$data['partner_email'],
                'partner_phone'=>$data['partner_phone'],
                'api_key'=>$data['api_key'],
                'is_reseller'=>Input::get('is_reseller')=="on"?1:0);           
            
            
            $validator = Validator::make($info, Partner::$rules);

            if ($validator->fails())
            {
                    return $validator->messages(); //Redirect::back()->withErrors($validator)->withInput();
            }

            $partner = Partner::create($info);
            
            $branch_info = array('branch_name'=>$partner->partner_name,
                'branch_location'=>'Head Office',
                'branch_partner'=>$partner->id);
            
            $branch = PartnerBranche::create($branch_info);

            $acc = array('user_name'=>$data['user_name'],
                'user_password'=>md5($data['user_password'].'KANE->2018.Worla'),
                'user_partner'=> $partner->id,
                'user_branch'=> $branch->id,
                'account_level'=> 0
                    );            
            
            $user = PartnerUser::create($acc);
            
           $permisssions = $this->getPermissions();
           
           $output = array_map(function($val) { return $val+1; }, $permisssions);
           
           $output['user_account'] = $user->id;
           
            PartnerUserPermission::create($output);

            return Redirect::route('partners.index');
	}
        
        private function getPermissions() {
            return array( 'can_add_sales'=>Input::get('can_add_sales')=='1'?1:0,
       'can_view_transactions'=> Input::get('can_view_transactions')=='1'?1:0,
       'can_view_branches'=> Input::get('can_view_branches')=='1'?1:0,
       'can_edit_branches'=> Input::get('can_edit_branches')=='1'?1:0,
       'can_delete_branches'=> Input::get('can_delete_branches')=='1'?1:0,
       'can_view_report'=> Input::get('can_view_report')=='1'?1:0,
       'can_view_topups'=> Input::get('can_view_topups')=='1'?1:0,
       'can_view_users'=> Input::get('can_view_users')=='1'?1:0,
       'can_edit_users'=> Input::get('can_edit_users')=='1'?1:0,
       'can_add_users'=> Input::get('can_add_users')=='1'?1:0,
       'can_delete_users'=> Input::get('can_delete_users')=='1'?1:0,
       'can_update_all'=> Input::get('can_update_all')=='1'?1:0,
       'can_add_branches'=> Input::get('can_add_branches')=='1'?1:0, 
                );
    }

	/**
	 * Display the specified customer.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$customer = Partner::findOrFail($id);

		return View::make('partners.show', compact('customer'));
	}

	/**
	 * Show the form for editing the specified customer.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$customer = Partner::find($id);

		return View::make('partners.edit', compact('customer'));
	}

	/**
	 * Update the specified customer in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$customer = Partner::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Partner::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$customer->update($data);

		return Redirect::route('partners.index');
	}

	/**
	 * Remove the specified customer from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Customer::destroy($id);

		return Redirect::route('customers.index');
	}

	public function apiPostCustomerSignup(){
            
            $db = new DBConnector();
            
		$validator = Validator::make($data = Input::all(), Customer::$rules);                
                
		if ($validator->fails())
		{
			return json_encode(array('customer_created'=>'no','status'=>400,'errors'=>$validator->messages()));
		}

                //$db = new DBConnector();
                $data['email'] = $data['phone']."@email.com";
                $data['account_verified'] = 1;
		$data['customer_token'] = Customer::createToken();
                
		$customer = Customer::create($data);

                $cust = array(
                    'id'=>$customer->id,
                    'phone'=>$customer->phone,
                    'name'=>$customer->name,
                    'customer_token'=>$customer->customer_token,
                    'created_at'=>$customer->created_at
                        );
                
		return json_encode(array('customer_created'=>'yes','status'=>200,'message'=>'Account created successfully.','customer'=>$cust));
               
	}
        
	

	public function apiPostCustomerUpdate($token)
	{
		$temp = Customer::where('customer_token',$token);

		if(count($temp->get())>0){
			$customer = $temp->first();

			$data = Input::all();

			$rules = Customer::$apiUpdateRules2;

			if(isset($data['email']) && $customer->email == $data['email']) $rules = Customer::$apiUpdateRules1;

			$validator = Validator::make($data, $rules);

			if ($validator->fails())
			{
				return json_encode(array('customer_updated'=>'no','status'=>400,'errors'=>$validator->messages()));
			}

			$data['type_id'] = $customer->type_id;
			$data['customer_token'] = $customer->customer_token;

			$customer->update($data);

			return Response::json(array('customer_updated'=>'yes','status'=>200,'customer'=>$customer));
		}

		return json_encode(array('customer_updated'=>'no','status'=>400, 'errors' => 'Invalid token' ));

		
	}

	     
        

}
