<?php
include_once 'dbconnect.php';

class CustomersController extends \BaseController {

	/**
	 * Display a listing of customers
	 *
	 * @return Response
	 */
	public function index($from="",$to="")
	{
		$data['pagetab'] = 'customers';
		$data['customers'] = Customer::orderBy('id','DESC')->get();
                $data['customers'] = strlen($from)==0 && strlen($to)==0 ?
                    Customer::where('created_at','>=',date('Y-m-d 00:00:00'))->where('created_at','<=',date('Y-m-d 23:59:59'))->orderBy('id','DESC')->get():                    
                    Customer::where('created_at','>=',date($from.' 00:00:00'))->where('created_at','<=',date($to.' 23:59:59'))->orderBy('id','DESC')->get();

                $data['from'] = strlen($from)==0?date('Y-m-d'): $from;
                $data['to'] = strlen($to)==0?date('Y-m-d'): $to;
            
		return View::make('customers.index', $data);
	}

	/**
	 * Show the form for creating a new customer
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('customers.create');
	}

	/**
	 * Store a newly created customer in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), Customer::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		Customer::create($data);

		return Redirect::route('customers.index');
	}

	/**
	 * Display the specified customer.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$customer = Customer::findOrFail($id);

		return View::make('customers.show', compact('customer'));
	}

	/**
	 * Show the form for editing the specified customer.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$customer = Customer::find($id);

		return View::make('customers.edit', compact('customer'));
	}

	/**
	 * Update the specified customer in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$customer = Customer::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Customer::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$customer->update($data);

		return Redirect::route('customers.index');
	}

	/**
	 * Remove the specified customer from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Customer::destroy($id);

		return Redirect::route('customers.index');
	}

	public function apiPostCustomerSignup(){
            
            $db = new DBConnector();
            
		$validator = Validator::make($data = Input::all(), Customer::$rules);                
                
		if ($validator->fails())
		{
			return json_encode(array('customer_created'=>'no','status'=>400,'errors'=>$validator->messages()));
		}

                //$db = new DBConnector();
                $data['email'] = $data['phone']."@email.com";
                $data['account_verified'] = 1;
		$data['customer_token'] = Customer::createToken();
                
		$customer = Customer::create($data);

                $cust = array(
                    'id'=>$customer->id,
                    'phone'=>$customer->phone,
                    'name'=>$customer->name,
                    'customer_token'=>$customer->customer_token,
                    'created_at'=>$customer->created_at
                        );
                
		return json_encode(array('customer_created'=>'yes','status'=>200,'message'=>'Account created successfully.','customer'=>$cust));
//                $verify_code = AccountVerification::generateVerificationCode();              
//              
//                $add_verification = array(
//                   'verify_customer'=>$customer->id,
//                   'verify_contact'=>$customer->phone,
//                   'created_at'=> date('Y-m-d H:i:s'),
//                   'updated_at' => date('Y-m-d H:i:s'),
//                   'verify_code' => $verify_code
//                   );
//
//               $db->Insert($add_verification,"account_verifications");
               
             //send message
               
             //$msg_sent = Messaging::sendQuickSMSto($customer->phone, $verify_code);
               
//              return $msg_sent['sent']=='yes'?json_encode(array('success'=>'yes',                                
//                    'status'=>200,
//                    'message'=>'A verification code has been sent to your number.'
//                    )):json_encode(array('success'=>'no',                                
//                    'status'=>400,
//                    'message'=>'Error sending code.'
//                    ));                
	}
        
	public function apiV2PostCustomerSignup(){
            
            $db = new DBConnector();
            
		$validator = Validator::make($data = Input::all(), Customer::$rules);                
                
		if ($validator->fails())
		{
			return json_encode(array('customer_created'=>'no','status'=>400,'errors'=>$validator->messages()));
		}

                //$db = new DBConnector();
                $data['email'] = $data['phone']."@email.com";
                
		$data['customer_token'] = Customer::createToken();
                
		$customer = Customer::create($data);

                $verify_code = AccountVerification::generateVerificationCode();              
              
                $add_verification = array(
                   'verify_customer'=>$customer->id,
                   'verify_contact'=>$customer->phone,
                   'created_at'=> date('Y-m-d H:i:s'),
                   'updated_at' => date('Y-m-d H:i:s'),
                   'verify_code' => $verify_code
                   );

               $db->Insert($add_verification,"account_verifications");
               
             //send message
               $sms = new Messaging();
               
             $msg_sent = $sms->sendQuickSMSto($customer->phone, $verify_code);
               
              return $msg_sent['sent']=='yes'?json_encode(array('success'=>'yes',                                
                    'status'=>200,
                    'message'=>'A verification code has been sent to your number.'
                    )):json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Error sending code.'
                    ));                
	}


	public function apiPostCustomerSignin(){
		$validator = Validator::make($data = Input::all(), Customer::$signinRules);

		if ($validator->fails())
		{
			return json_encode(array('customer_exists'=>'no','status'=>400,'errors'=>$validator->messages()));
		}

		$customer = Customer::where('phone',$data['phone']);

		if(count($customer->get())>0){
			$customer = $customer->first();//return Hash::make($data['password']).'----'.$customer->password;			
                                                
			if($customer->checkPassword($data['password'])){
				return json_encode(array('customer_exists'=>'yes','status'=>200,'customer'=>$customer));
			}

			return json_encode(array('customer_exists'=>'no','status'=>401,'errors'=>'Phone Number or password is incorrect'));
		}

		return json_encode(array('customer_exists'=>'no','status'=>400,'errors'=>NULL));
	}
        
	public function apiV2PostCustomerSignin(){
		$validator = Validator::make($data = Input::all(), Customer::$signinRules);

		if ($validator->fails())
		{
			return json_encode(array('customer_exists'=>'no','status'=>400,'errors'=>$validator->messages()));
		}

		$customer = Customer::where('phone',$data['phone']);

		if(count($customer->get())>0){
                    
			$customer = $customer->first();//return Hash::make($data['password']).'----'.$customer->password;
			
                        if($customer->account_verified==0){
                            
				return json_encode(array('success'=>'no','status'=>400,'message'=>'Account not verified.'));
			}
                        
			if($customer->checkPassword($data['password'])){
				return json_encode(array('customer_exists'=>'yes','status'=>200,'customer'=>$customer));
			}

			return json_encode(array('customer_exists'=>'no','status'=>401,'errors'=>'Phone Number or password is incorrect'));
		}

		return json_encode(array('customer_exists'=>'no','status'=>400,'errors'=>NULL));
	}

	public function apiGetCustomer($token){
		$temp = Customer::where('customer_token',$token);

		if(count($temp->get())>0){
			$customer = $temp->first();
			return Response::json(array('customer_exists'=>'yes','status'=>200,'customer'=>$customer));
		}

		return json_encode(array('customer_exists'=>'no','status'=>400));
	}

	public function apiPostCustomerUpdate($token)
	{
		$temp = Customer::where('customer_token',$token);

		if(count($temp->get())>0){
			$customer = $temp->first();

			$data = Input::all();

			$rules = Customer::$apiUpdateRules2;

			if(isset($data['email']) && $customer->email == $data['email']) $rules = Customer::$apiUpdateRules1;

			$validator = Validator::make($data, $rules);

			if ($validator->fails())
			{
				return json_encode(array('customer_updated'=>'no','status'=>400,'errors'=>$validator->messages()));
			}

			$data['type_id'] = $customer->type_id;
			$data['customer_token'] = $customer->customer_token;

			$customer->update($data);

			return Response::json(array('customer_updated'=>'yes','status'=>200,'customer'=>$customer));
		}

		return json_encode(array('customer_updated'=>'no','status'=>400, 'errors' => 'Invalid token' ));

		
	}

	public function api2GetCustomerSales($token){
            
		$temp = Customer::with('sales','sales.items')->where('token',$token);

		if(count($temp->get())>0){
			$customer = $temp->first();
			return Response::json(Sale::with('items')->where('customer_id',$customer->id)->where('submitted',1)->get());
		}

		return json_encode(array('customer_exists'=>'no','status'=>200));
	}
        
        private function elapsedTime($date){
            
            if(empty($date)) {
               return "No date provided";
           }

           $periods         = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
           $lengths         = array("60","60","24","7","4.35","12","10");

           $now             = time();
           $unix_date         = strtotime($date);

              // check validity of date
           if(empty($unix_date)) {    
               return "Bad date";
           }

           // is it future date or past date
           if($now > $unix_date) {    
               $difference     = $now - $unix_date;
               $tense         = "ago";

           } else {
               $difference     = $unix_date - $now;
               $tense         = "from now";
           }

           for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
               $difference /= $lengths[$j];
           }

           $difference = round($difference);

           if($difference != 1) {
               $periods[$j].= "s";
           }

           return "$difference $periods[$j] {$tense}";
       }
        
	public function apiPostCustomerSales($token){
            
		$temp = Customer::where('customer_token',$token);
                
                if(count($temp->get())>0){
                    
                    $customer = $temp->first();
                    
                    $db = new DBConnector();
                    
                    $query = "SELECT DATE_FORMAT(momo_transations.updated_at,'%W,%D %M, %Y %T') as trans_date,momo_transations.created_at as updated_date,momo_transations.id as id,ecg_amount,origgin_charge,amount_after_charges,meter_code,meter_owner,location,customer_id,requsts.type_id as trans_type,payment_name,phone ";
                    $query .="FROM momo_transations JOIN requsts ON momo_transations.requst_id=requsts.id ";
                    $query .= "JOIN payment_types ON payment_type=payment_id ";
                    $query .= "JOIN customers ON customer_id=customers.id ";
                    $query .= "WHERE is_paid=1 AND response_code='0000' AND customer_id=$customer->id ORDER BY id DESC";
                    
                    $trans = $db->Select($query);
                    
                    if(is_array($trans)) {
                        
                        $return_arr = array();
                        foreach (array_values($trans) as $value)
                        {
//                            $now = time();
//                            $unix_date = strtotime($value['updated_at']);
                            
                            $date1 = new DateTime();
                            $date2 = new DateTime($value['updated_date']);
                            $date_diff = $date1->diff($date2)->days;
                            
                          $return_arr[] = array(
                              'id'=>$value['id'],
                              'date'=>$date_diff>2?$value['trans_date']:$this->elapsedTime($value['updated_date']),
                              'meter'=>$value['meter_code'],
                              'owner'=>$value['meter_owner'],
                              'location'=>$value['location'],
                              'type'=>$value['trans_type']==1?"Prepaid Credit":"Credit Balance",
                              'prepaid'=>$value['ecg_amount'],
                              'charges'=>$value['origgin_charge'],
                              'amount'=>$value['amount'],
                              'total'=> $value['amount_after_charges'],
                              'paymentType'=>$value['payment_name']
                              );
                        }
                        
                        return Response::json(array(
                            'request_initiated'=>'yes',
                            'status'=>200,
                            'data'=>$return_arr));
                        
                    } else {
                        return Response::json(array(
                            'request_initiated'=>'no',
                            'status'=>400,
                            'errors'=>$trans));
                    }
                    
                }

		return json_encode(array('request_initiated'=>'no','status'=>400,'errors'=>'Invalid Token'));
	}
        
        
	public function getCustomerSales($id,$from='',$to=''){
            
            $data['pagetab'] = 'customers';
            //$data['blockedlist'] = BlockedList::orderBy('created_at','DESC')->get();
            $data['from'] = strlen($from)==0?date('Y-m-d'): $from;
            $data['to'] = strlen($to)==0?date('Y-m-d'): $to;           
            
            
		$temp = Customer::where('id',$id);
                
                if(count($temp->get())>0){
                    
                    $customer = $temp->first();
                    
                    $db = new DBConnector();
                    
                    $q = MomoTransation::where('amount','>',0);
                    
                    $data['sold'] = $db->Select("SELECT * FROM momo_transations JOIN requsts ON requsts.id=momo_transations.requst_id WHERE date() BETWEEN '$from 00:00:00' AND '$to 23:59:59' customer_id=".$customer->id);
                            
                    $data['sold'] = $q->where('sold_at','>=',date($from.' 00:00:00'))->where('sold_at','<=',date($to.' 23:59:59'))->where('is_sold',1)->orderBy('id','DESC')->get();

                    $r = Requst::where('amount','>',0)->where('customer_id',$id);
                    $data['request'] = $r->where('created_at','>=',date($from.' 00:00:00'))->where('created_at','<=',date($to.' 23:59:59'))->where('is_sold',0)->orderBy('id','DESC')->get();

                    
//                    $db = new DBConnector();
//                    
//                    $query = "SELECT DATE_FORMAT(momo_transations.updated_at,'%W,%D %M, %Y %T') as trans_date,momo_transations.created_at as updated_date,momo_transations.id as id,ecg_amount,origgin_charge,amount_after_charges,meter_code,meter_owner,location,customer_id,requsts.type_id as trans_type,payment_name,phone ";
//                    $query .="FROM momo_transations JOIN requsts ON momo_transations.requst_id=requsts.id ";
//                    $query .= "JOIN payment_types ON payment_type=payment_id ";
//                    $query .= "JOIN customers ON customer_id=customers.id ";
//                    $query .= "WHERE is_paid=1 AND response_code='0000' AND customer_id=$customer->id AND DATE(momo_transations.updated_at) BETWEEN '$from' AND '$to' ORDER BY id DESC";
//                    
//                    $trans = $db->Select($query);
//                    
//                    if(is_array($trans)) {
//                        
//                        $return_arr = array();
//                        foreach (array_values($trans) as $value)
//                        {
////                            $now = time();
////                            $unix_date = strtotime($value['updated_at']);
//                            
//                            $date1 = new DateTime();
//                            $date2 = new DateTime($value['updated_date']);
//                            $date_diff = $date1->diff($date2)->days;
//                            
//                          $return_arr[] = array(
//                              'id'=>$value['id'],
//                              'date'=>$date_diff>2?$value['trans_date']:$this->elapsedTime($value['updated_date']),
//                              'meter'=>$value['meter_code'],
//                              'owner'=>$value['meter_owner'],
//                              'location'=>$value['location'],
//                              'type'=>$value['trans_type']==1?"Prepaid Credit":"Credit Balance",
//                              'prepaid'=>$value['ecg_amount'],
//                              'charges'=>$value['origgin_charge'],
//                              'amount'=>$value['amount'],
//                              'total'=> $value['amount_after_charges'],
//                              'paymentType'=>$value['payment_name']
//                              );
//                        }
//                        
//                      $data['sales'] = $return_arr;
//                      
//                    } 
                    
                }

		return View::make('customers.requests', $data);
	}
        
        // for verifying password resset request
        public function verifyNumber($contact) {
            
            $db = new DBConnector();
            
            $filter_phone = trim($contact);            
            $isValidNumber = $db->SelectValue("SELECT count(*) as found from customers where phone='$filter_phone'", 'found');
             
          if($isValidNumber>0) {
               //$db->SelectValue("SELECT count(*) as found from password_ressets where resset_contact='$filter_key' AND is_verified=0 AND is_resset=0", 'found');
              //check if a password resset request already exist 
              $resset_exists = PasswordResset::where('resset_contact',$filter_phone)->where('is_verified',0)->where('is_resset',0)->get();                         
              
              if(count($resset_exists)>0) {
                  
                  $resset = $resset_exists->first();
                  
                   $verify_token = PasswordResset::generateVerificationCode();
                   $resset_token = PasswordResset::createRessetToken();
                                    
                   
                   $update = array('verify_code'=>$verify_token,'resset_token'=>$resset_token);
                    $where = array('resset_id'=>$resset->resset_id);                    
                    
                    $db->Update($update, 'password_ressets', $where);
                   
                   //re-send message
                    $sms = new Messaging();
                    $msg_sent = $sms->sendQuickSMSto($filter_phone, $verify_token);
                   
                   return $msg_sent['sent']=='yes'?json_encode(array('success'=>'yes',                                
                    'status'=>200,
                    'message'=>'Verification code sent to '.$contact
                    )):json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Error sending code.'
                    ));
              }
              
              $customer = Customer::where('phone',$filter_phone)->first();
              
              $verify_token = PasswordResset::generateVerificationCode();
              $resset_token = PasswordResset::createRessetToken();
              
             $add_resset = array(
                'resset_customer'=>$customer->id,
                'resset_contact'=>$customer->phone,
                'created_at'=> date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
                'verify_code' => $verify_token,
                'resset_token' => $resset_token,
                );

               $db->Insert($add_resset,"password_ressets");
               
             //send message
             $sms = new Messaging();
             $msg_sent = $sms->sendQuickSMSto($filter_phone, $verify_token);
               
              return $msg_sent['sent']=='yes'?json_encode(array('success'=>'yes',                                
                    'status'=>200,
                    'message'=>'Verification code sent to '.$contact
                    )):json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Error sending code.'
                    ));
          }
                           
           return json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'No Account with this number found.'
                    ));
               
        }
        
        public function authenticateResetCode($contact,$code) {
            
            //$data = Input::all();
            $db = new DBConnector();
            
            $verify_code = trim($code);
            $verify_number = trim($contact);
            
             //check if a password resset request already exist 
            $resset_exists = PasswordResset::where('verify_code',$verify_code)->where('resset_contact',$verify_number)->where('is_verified',0)->where('is_resset',0)->get();
             
          if(count($resset_exists)>0) {
                          
              $resset = $resset_exists->first();
              
              //$resset->is_verified = 1;              
             
              //$resset->save();
              $update = array('is_verified'=>1);
              $where = array('resset_id'=>$resset->resset_id);
              $db->Update($update, 'password_ressets', $where);
                   
             return json_encode(array('success'=>'yes',                                
                    'status'=>200,
                    'resset_token'=>$resset->resset_token,
                    'message'=>'Code verified successfully.'
                    )); 
          }          
          
           return json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Invalid Verification code.'
                    ));
               
        }
        
        public function resendAccountVerificationCode($contact) {
            $db = new DBConnector();
            
            $filter_phone = trim($contact);            
            $isValidNumber = $db->SelectValue("SELECT count(*) as found from customers where phone='$filter_phone'", 'found');
             
          if($isValidNumber>0) {
               //$db->SelectValue("SELECT count(*) as found from password_ressets where resset_contact='$filter_key' AND is_verified=0 AND is_resset=0", 'found');
              //check if a password resset request already exist 
              $resset_exists = AccountVerification::where('verify_contact',$filter_phone)->where('is_verified',0)->where('is_expired',0)->get();                         
              
              if(count($resset_exists)>0) {
                  
                  $resset = $resset_exists->first();
                  
                   $verify_code = AccountVerification::generateVerificationCode();
                   
                   $update = array('verify_code'=>$verify_code,'updated_at'=>date('Y-m-d H:i:s'));
                    $where = array('verify_id'=>$resset->resset_id);
                    
                    $db->Update($update, 'account_verifications', $where);
                   
                   //re-send message
                   $sms = new Messaging();
                    $msg_sent = $sms->sendQuickSMSto($filter_phone, $verify_code);
                   
                   return $msg_sent['sent']=='yes'?json_encode(array('success'=>'yes',                                
                    'status'=>200,
                    'message'=>'Verification code sent to '.$contact
                    )):json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Error sending code.'
                    ));
              }
              
              $customer = Customer::where('phone',$filter_phone)->first();
              
              $verify_code = AccountVerification::generateVerificationCode();              
              
                $add_verification = array(
                   'verify_customer'=>$customer->id,
                   'verify_contact'=>$customer->phone,
                   'created_at'=> date('Y-m-d H:i:s'),
                   'updated_at' => date('Y-m-d H:i:s'),
                   'verify_code' => $verify_code
                   );

               $db->Insert($add_verification,"account_verifications");
               
             //send message
              $sms = new Messaging();
                    $msg_sent = $sms->sendQuickSMSto($filter_phone, $verify_code);
               
              return $msg_sent['sent']=='yes'?json_encode(array('success'=>'yes',                                
                    'status'=>200,
                    'message'=>'Verification code sent to '.$contact
                    )):json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Error sending code.'
                    ));
          }
                           
           return json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'No Account with this number found.'
                    ));
               
        }
        
        public function resendPaymentVerificationCode($token,$contact) {
            
            $db = new DBConnector();
            
            $filter_phone = trim($contact);            
             
              $resset_exists = PaymentVerification::where('verify_contact',$filter_phone)->where('is_verified',0)->where('is_expired',0)->get();                         
              
              if(count($resset_exists)>0) {
                  
                  $resset = $resset_exists->first();
                  
                   $verify_code = PaymentVerification::generateVerificationCode();
                   
                   $update = array('verify_code'=>$verify_code,'updated_at'=>date('Y-m-d H:i:s'));
                    $where = array('verify_id'=>$resset->verify_id);                    
                    $db->Update($update, 'payment_verifications', $where);
                   
                   //re-send message
                   $sms = new Messaging();
                    $msg_sent = $sms->sendQuickSMSto($filter_phone, $verify_code);
                   
                   return $msg_sent['sent']=='yes'?json_encode(array('success'=>'yes',                                
                    'status'=>200,
                    'message'=>'Verification code sent to '.$contact
                    )):json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Error sending code.'
                    ));
              }
              
              $customer = Customer::where('customer_token',$token)->first();
              
              $verify_code = PaymentVerification::generateVerificationCode();              
              
                $add_verification = array(
                   'verify_customer'=>$customer->id,
                   'verify_contact'=>$customer->phone,
                   'created_at'=> date('Y-m-d H:i:s'),
                   'updated_at' => date('Y-m-d H:i:s'),
                   'verify_code' => $verify_code
                   );

               $db->Insert($add_verification,"payment_verifications");
               
             //send message
             $sms = new Messaging();
                    $msg_sent = $sms->sendQuickSMSto($filter_phone, $verify_code);
               
              return $msg_sent['sent']=='yes'?json_encode(array('success'=>'yes',                                
                    'status'=>200,
                    'message'=>'Verification code sent to '.$contact
                    )):json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Error sending code.'
                    ));
               
        }         
        
        public function verifyPaymentNumber($token, $contact) {
            $db = new DBConnector();
            
            $filter_phone = trim($contact);       
            
              $resset_exists = PaymentVerification::where('verify_contact',$filter_phone)->where('is_verified',0)->where('is_expired',0)->get();                         
              
              if(count($resset_exists)>0) {
                  
                  $resset = $resset_exists->first();
                  
                   $verify_code = PaymentVerification::generateVerificationCode();
                   
                   $update = array('verify_code'=>$verify_code,'updated_at'=>date('Y-m-d H:i:s'));
                    $where = array('verify_id'=>$resset->verify_id);
                    
                    $db->Update($update, 'payment_verifications', $where);
                   
                   //re-send message
                    $sms = new Messaging();
                    $msg_sent = $sms->sendQuickSMSto($filter_phone, $verify_code);
                   
                   return $msg_sent['sent']=='yes'?json_encode(array('success'=>'yes',                                
                    'status'=>200,
                    'message'=>'A verification code has been sent to '.$contact
                    )):json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Error sending code.'
                    ));
              }
              
              $customer = Customer::where('customer_token',$token)->first();
              
              $verify_code = PaymentVerification::generateVerificationCode();              
              
                $add_verification = array(
                   'verify_customer'=>$customer->id,
                   'verify_contact'=>$filter_phone,
                   'created_at'=> date('Y-m-d H:i:s'),
                   'updated_at' => date('Y-m-d H:i:s'),
                   'verify_code' => $verify_code
                   );

               $db->Insert($add_verification,"payment_verifications");
               
             //send message
             $sms = new Messaging();
                    $msg_sent = $sms->sendQuickSMSto($filter_phone, $verify_code);
               
              return $msg_sent['sent']=='yes'?json_encode(array('success'=>'yes',                                
                    'status'=>200,
                    'message'=>'Verification code sent to '.$contact
                    )):json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Error sending code.'
                    ));
          
               
        } 
        
        public function authenticateAccountVerificationCode($contact,$code) {
            
            //$data = Input::all();
            $db = new DBConnector();
            
            $verify_code = trim($code);
            $verify_number = trim($contact);
            
             //check if a password resset request already exist 
            $resset_exists = AccountVerification::where('verify_code',$verify_code)->where('verify_contact',$verify_number)->where('is_verified',0)->get();
             
          if(count($resset_exists)>0) {
                          
              $resset = $resset_exists->first();
              $now = time();
              $unix_date = strtotime($resset->updated_at); 
              $time_passed = $now-$unix_date;
              
              if($resset->is_expired==1 || $time_passed > 300 ){
                  $update = array('is_verified'=>0,'is_expired'=>1);
                  $where = array('verify_id'=>$resset->verify_id);
              
                //update verification table
                $db->Update($update, 'account_verifications', $where);
                
                
                return json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Verification code expired.'
                    ));
              }
              
              $customer = Customer::where('phone',$verify_number)->first();
              
              //return print_r($customer);
              
              $update = array('is_verified'=>1,'is_expired'=>0);
              $where = array('verify_id'=>$resset->verify_id);
              
              //update verification table
              $db->Update($update, 'account_verifications', $where);
              
              //$cust_update = array('account_verified'=>1);
              $customer->account_verified=1;
              $customer->save();
                   
             $cust = array(
                    'id'=>$customer->id,
                    'phone'=>$customer->phone,
                    'name'=>$customer->name,
                    'customer_token'=>$customer->customer_token,
                    'created_at'=>$customer->created_at
                        );
                
		return json_encode(array('success'=>'yes','status'=>200,'message'=>'Account authenticated successfully.','customer'=>$cust));
          } 
          
           return json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Invalid Verification code.'
                    ));
               
        }
        
        public function authenticatePayment($contact,$code) {
            
            //$data = Input::all();
            $db = new DBConnector();
            
            $verify_code = trim($code);
            $verify_number = trim($contact);
            
             //check if a password resset request already exist 
            $resset_exists = PaymentVerification::where('verify_code',$verify_code)->where('verify_contact',$verify_number)->where('is_verified',0)->get();
             
          if(count($resset_exists)>0) {
                          
              $resset = $resset_exists->first();
              
              $now = time();
              $unix_date = strtotime($resset->updated_at);
              $time_passed = $now-$unix_date;
              
              if($resset->is_expired==1 || $time_passed > 300 ){
                  $update = array('is_verified'=>0,'is_expired'=>1);
                  $where = array('verify_id'=>$resset->verify_id);
              
                //update verification table
                $db->Update($update, 'payment_verifications', $where);
                
                
                return json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Verification code expired.'
                    ));
              }
                          
              
              $update = array('is_verified'=>1,'is_expired'=>0);
              $where = array('verify_id'=>$resset->verify_id);
              
              //update verification table
              $db->Update($update, 'payment_verifications', $where);
                 
                             
                return json_encode(array('success'=>'yes','status'=>200,'message'=>'Number successfully verified.'));
          } 
          
           return json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Invalid Verification code.'
                    ));
               
        }
        
        
        public function ressetPassword($token) {
            
            $data = Input::all();            
             
            $db = new DBConnector();
            
            if(strlen($data['password'])==0) {
                return json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Password cannot be empty'
                    ));
            }
            
             //check if a password resset request already exist 
            $resset_exists = PasswordResset::where('resset_token',$token)->where('is_verified',1)->where('is_resset',0)->get();
             
                        
          if(count($resset_exists)>0) {
                          
              $resset = $resset_exists->first();
              
              $customer = Customer::where('id',$resset->resset_customer)->first();
                       
                           
              $update = array('is_resset'=>1);
              $where = array('resset_id'=>$resset->resset_id);
              $db->Update($update, 'password_ressets', $where);
              
               $customer->update($data);  
               
               
             return json_encode(array('success'=>'yes',                                
                    'status'=>200,
                    'message'=>'Password resset successfully.',
                    'customer'=>$customer
                    )); 
          }          
          
           return json_encode(array('success'=>'no',                                
                    'status'=>400,
                    'message'=>'Resset token does not exist.'
                    ));
               
        }        
        

}
