<?php
include_once 'dbconnect.php';

class PartnerRequestsController extends \BaseController {
    private $table = 'momo_transations';
    
        public function recent($recentid)
	{       
            $db = new DBConnector();
            
            $query = "SELECT requsts.*,phone,name,email FROM requsts ";
            $query .= "JOIN customers ON customer_id=customers.id ";
            $query .= "WHERE is_paid=0 AND requsts.id>$recentid";
            
            $new = $db->Select($query);
            //$new = MomoTransation::where('is_sold',0)->where('response_code','0000')->where('id','>',$recentid)->get();
                
            return Response::json(array(
                'status'=>'ok',
                'data'=>$new));                
	}
        
        
        function filterRequestsAPI($user_id,$api_key) {
            $data = Input::all();

            $rows = Input::get('_display');
            $from_date = Input::get('from_date');
            $to_date = Input::get('to_date');
            $filter = Input::get('filter');
            $filter_key = Input::get('filter_key');
            $offset = Input::get('offset');
            
            $temp = Partner::where('api_key',$api_key);
                
            if(count($temp->get())==0){               
                return json_encode(array(
                    'success'=>'no',                    
                    'status'=>400,
                    'message' =>'Invalid API Key'                                
                    )
                        );                
            } 
            
            $partner = $temp->first();
            
            $temp2 = PartnerUser::where('user_id',$user_id);
                
            if(count($temp2->get())==0){               
                return json_encode(array(
                    'success'=>'no',                    
                    'status'=>400,
                    'message' =>'Unauthorized request.'                                
                    )
                        );                
            } 
            
            $user = $temp2->first();
            
            $limit = $offset + $rows;
        
            $gt_pos = strpos($filter_key, "gt");
            $lt_pos = strpos($filter_key, "lt");
            
            $filter_key = str_replace(['gt','lt'], '', $filter_key);
            
        switch ($filter) {
            case 0:
                $filter_sring = strlen($filter_key)>0? "meter_code='$filter_key'":'';                
                break;
            case 1:
                $filter_sring = strlen($filter_key)>0? "meter_owner RLIKE '$filter_key'":'';                
                break;
            case 2:
                $filter_sring = strlen($filter_key)>0? "location RLIKE '$filter_key'":'';                
                break;
            case 3:
                $filter_sring = strlen($filter_key)>0? "is_sold=".(strtoupper($filter_key)=='YES'?1:0):'is_sold=0';
                break;
            case 4:
                $filter_sring = strlen($filter_key)>0? ($gt_pos>=0||$lt_pos>=0?"ecg_amount >$filter_key":"ecg_amount=$filter_key"):'';
                break;
            case 5:
                $filter_sring = strlen($filter_key)>0? "user_name RLIKE '$filter_key'":'';                
                break;
            case 6:
                $filter_sring = strlen($filter_key)>0? "branch_name LIKE '$filter_key%'":'';                
                break;
                        
            default:
                $filter_sring='';
                break;
        }
        
        //string for date 
        $date_string ='';
        if(strlen($from_date)>0 && strlen($to_date)>0){
            $date_string = "DATE($this->table.created_at) BETWEEN '$from_date' AND '$to_date'";
        } elseif (strlen($from_date)>0) {            
            $date_string = "DATE($this->table.created_at) BETWEEN '$from_date' AND '$from_date'";
        } elseif(strlen($to_date)>0) {
            $date_string = "DATE($this->table.created_at) BETWEEN '$to_date' AND '$to_date'";
        }
      
        
        $where = strlen($filter_sring)>0 ? "WHERE partner=$partner->id AND $filter_sring ".($user->account_level==0?'':' AND requsts.branch_id='.$user->user_branch):"WHERE partner=$partner->id ".($user->account_level==0?'':' AND requsts.branch_id='.$user->user_branch);
        
        if (strlen($date_string)>0 && strlen($where)>0 ){
            $where .= " AND $date_string";
        } elseif (strlen($date_string)>0 && strlen($where)==0) {
            $where .= "WHERE $date_string";
        }
        
        $q = "SELECT momo_transations.*,meter_code,meter_owner,location,user_name,branch_name,requsts.type_id as type_id FROM momo_transations "
                . "JOIN requsts ON requsts.id=momo_transations.requst_id LEFT JOIN partner_users ON partner_users.user_id=requsts.user_id "
                . "LEFT JOIN partner_branches ON partner_branches.branch_id=requsts.branch_id ";
        $q .= " $where ORDER BY momo_transations.id DESC";
        
                
        $db = new DBConnector(); 
             
        $res = $db->Select($q);
        
        if(is_array($res)){
            if(count($res)>0) {
                echo json_encode(array('status'=>'ok','message'=>count($res).' results found.','data'=>$res));
            }
            else {
                echo json_encode(array('status'=>'ok','message'=>'No Transactions found.','data'=>$res));
            }  
        } else {
            echo json_encode(array('status'=>'error','message'=>$res));
        }
        
          
    } 
        
        function recentRequestsAPI($user_id,$api_key,$last_id) {                        
            $temp = Partner::where('api_key',$api_key);                
            if(count($temp->get())==0){               
                return json_encode(array(
                    'success'=>'no',                    
                    'status'=>400,
                    'message' =>'Invalid API Key'                                
                    )
                        );                
            } 
            
            $partner = $temp->first();
            
            $temp2 = PartnerUser::where('user_id',$user_id);
                
            if(count($temp2->get())==0){               
                return json_encode(array(
                    'success'=>'no',                    
                    'status'=>400,
                    'message' =>'Unauthorized request.'                                
                    )
                        );                
            } 
            
            $user = $temp2->first();
      
        $now = date("Y-m-d");
        $where = "WHERE partner=$partner->id ".($user->account_level==0?'':' AND requsts.branch_id='.$user->user_branch);
              
        $q = "SELECT momo_transations.*,meter_code,meter_owner,location,user_name,branch_name,requsts.type_id as type_id FROM momo_transations "
                . "JOIN requsts ON requsts.id=momo_transations.requst_id LEFT JOIN partner_users ON partner_users.user_id=requsts.user_id "
                . "LEFT JOIN partner_branches ON partner_branches.branch_id=requsts.branch_id ";
        $q .= " $where AND momo_transations.id>$last_id AND DATE($this->table.created_at)='$now' ORDER BY momo_transations.id DESC";
        
                
        $db = new DBConnector(); 
             
        $res = $db->Select($q);
        
        if(is_array($res)){
            if(count($res)>0) {
                echo json_encode(array('status'=>'ok','message'=>count($res).' new transactions found.','data'=>$res));
            }
            else {
                echo json_encode(array('status'=>'ok','message'=>'No Transactions found.','data'=>$res));
            }  
        } else {
            echo json_encode(array('status'=>'error','message'=>$res));
        }
        
          
    } 
        
	/**
	 * Display a listing of requsts
	 *
	 * @return Response
	 */
	public function index($from="",$to="")
	{
            $data['pagetab'] = 'requests';
            $data['requests'] = strlen($from)==0 && strlen($to)==0 ?
                    Requst::where('is_paid',0)->where('created_at','>=',date('Y-m-d 00:00:00'))->where('created_at','<=',date('Y-m-d 23:59:59'))->orderBy('id','DESC')->get():                    
                    Requst::where('is_paid',0)->where('created_at','>=',date($from.' 00:00:00'))->where('created_at','<=',date($to.' 23:59:59'))->orderBy('id','DESC')->get();
            
            $data['from'] = strlen($from)==0?date('Y-m-d'): $from;
            $data['to'] = strlen($to)==0?date('Y-m-d'): $to;
            
            return View::make('requsts.index', $data);
	}               
        
        
        public function apiPostGetECGStatus($api_key) {
            $temp = Partner::where('api_key',$api_key);
            
            if(count($temp->get())>0){
                    
                $partner = $temp->first();
                
                $ecg = EcgStatus::currentStatus();
                
                //return status 400 if ecg is off
                if($ecg == "0") {
                     return json_encode(array('success'=>'yes',
                        'ecg_status'=>$ecg,
                        'status'=>400,
                        'message' => 'System Offline'
                         )
                             );
                } else {
                    return json_encode(array('success'=>'yes',
                        'ecg_status'=>$ecg,
                        'status'=>200,
                        'message' => 'System Online'
                         )
                             );
                }
                
            } else {
                return json_encode(array(
                    'success'=>'no',                    
                    'status'=>400,
                    'message' =>'Invalid API Key',
                                
                    )
                        );
            }
            
            
        }
	
        
	public function apiPostInitiateNewRequest($api_key){
             $rules = array(		
		'meter_code' => 'required|numeric|min:8',
                'amount' => 'required|numeric|min:10',
                'location_id' => 'required',
                'meter_owner' => 'required',
                'customer_id' => 'required|numeric'
                );

        //check ecg status            
            $ecg = EcgStatus::currentStatus();           
            //
		$temp = Partner::where('api_key',$api_key);
                               
                $data = Input::all();
                
                $data['created_at'] = date('Y-m-d H:i:s');
               $data['updated_at'] = date('Y-m-d H:i:s');
                
		if(count($temp->get())>0){
                    
			$partner = $temp->first();
                         
                        if($partner->quota_bal<$data['amount']){
                            
                            return json_encode(
                                    array(
                                        'success'=>'no',
                                        'ecg_status'=>$ecg,
                                        'status'=>400,
                                        'message'=> "Insufficient Balance."
                                    
                                        )
                                    );
                        }
                        
                        $user = PartnerUser::where('user_partner',$partner->id)->first();
                        $branch = PartnerBranche::where('branch_partner',$partner->id)->first();
                        
                        $data['customer_id'] = $partner->id;
                        $data['partner'] = $partner->id;
                        
                        $data['user_id'] = $user->user_id;
                        $data['branch_id'] = $branch->branch_id;
                        
			$validator = Validator::make($data, $rules);

			if ($validator->fails())
			{
                                                        
                            return json_encode(
                                    array(
                                        'success'=>'no',
                                        'ecg_status'=>$ecg,
                                        'status'=>400,
                                        'message'=> $validator->messages()
                                    
                                        )
                                    );
			}
                        
                        $filter_key = trim($data['location_id']);
                        //check if location is valid smart meter location
                        //$isValidLocation = $db->SelectValue("SELECT count(*) as found from locations where id=$filter_key", 'found');
                        $loc = Location::where('id',$filter_key);
                        
                        if(count($loc->get())==0) {
                            return json_encode(array('success'=>'no',                                
                                'status'=>400,
                                'message' => 'Unsupported Location'
                                ));
                        }
                        
                        $location = $loc->first();
                        
                        //return status 400 if ecg is off
                        if($ecg == "0") {
                                                                                   
                             return json_encode(array('success'=>'no',
                                'ecg_status'=>$ecg,
                                'status'=>400,
                                'message' => 'System Unavailable '
                                 )
                                     );
                        }
                        
                        $data['request_id'] = Requst::createID();			
                        $data['location'] = $location->name;
                        $data['is_paid'] = 1;
			$data['type_id'] = 1; //[1=purchase request, 2=balance request,3=consumption balance] 
			
                        $request = Requst::create($data);
                        
                        //add transaction
                        $this->AddTransaction($request->id,$data);
                        
                        //debit Partner account
//                        $partner->quota_bal = $partner->quota_bal - $request->amount;
//                        $partner->save();
                        //generate payment invoice
                        $invoice = MomoTransation::MazzumaPrepaidInvoice($request);
                        
                        //check if error
                        if (strlen($invoice['error'])>0) {
                            
                            return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=>'System Unavailable'
                                               
                                    )
                                    );
                        
                            
                        } else { //invoice was successfull
                             
                            $respose_data = json_decode($invoice['data']);

                            if($respose_data->status=='error') {
                                
                                return json_encode(array(
                                    'success'=>'no',
                                    'status'=>400,
                                    'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$respose_data->data
                                        )
                                        ));
                            }
                            
                            return Response::json(array(
                                'success'=>'yes',
                                'ecg_status'=>$ecg,
                                'status'=>200,
                                'message'=>'Transaction added successfully',
                                'request'=> array(
                                    'amount'=>$request['amount'],
                                    //'total'=> number_format($requst['amount'] + MomoTransation::getOrigginFee($requst['amount']), 2, '.', ','),
                                    'location'=>$request['location'],
                                    'id'=>$request['request_id'])
                            ));
                        }
		}
		return json_encode(array(
                    'success'=>'no',
                    'ecg_status'=>$ecg,
                    'status'=>400,
                    'message' =>'Invalid API Key',
                                
                    )
                        );
                
        }
        
	public function apiPostInitiateNewResellerRequest($api_key,$user,$branch){
             $rules = array(		
		'meter_code' => 'required|numeric',
                'amount' => 'required|numeric',
                'location_id' => 'required',
                'meter_owner' => 'required',
                'customer_id' => 'required|numeric'
                );

        //check ecg status            
            $ecg = EcgStatus::currentStatus();           
            //
		$temp = Partner::where('api_key',$api_key);
                               
                $data = Input::all();
                
                                                
               $data['created_at'] = date('Y-m-d H:i:s');
               $data['updated_at'] = date('Y-m-d H:i:s');
                
		if(count($temp->get())>0){
                    
			$partner = $temp->first();
                         
                        if($partner->quota_bal<$data['amount']){
                            
                            return json_encode(
                                    array(
                                        'success'=>'no',
                                        'ecg_status'=>$ecg,
                                        'status'=>400,
                                        'message'=> "Insufficient Balance."
                                    
                                        )
                                    );
                        }
                                                                         
                        $data['customer_id'] = $partner->id;
                        $data['partner'] = $partner->id;
                        $data['user_id'] = $user;
                        $data['branch_id'] = $branch;
                        
			$validator = Validator::make($data, $rules);

			if ($validator->fails())
			{
                                                        
                            return json_encode(
                                    array(
                                        'success'=>'no',
                                        'ecg_status'=>$ecg,
                                        'status'=>400,
                                        'message'=> $validator->messages()
                                    
                                        )
                                    );
			}
                        
                        $filter_key = trim($data['location_id']);
                        //check if location is valid smart meter location
                        //$isValidLocation = $db->SelectValue("SELECT count(*) as found from locations where id=$filter_key", 'found');
                        $loc = Location::where('id',$filter_key);
                        
                        if(count($loc->get())==0) {
                            return json_encode(array('success'=>'no',                                
                                'status'=>400,
                                'message' => 'Unsupported Location'
                                ));
                        }
                        
                        $location = $loc->first();
                        
                        //return status 400 if ecg is off
                        if($ecg == "0") {
                                                                                   
                             return json_encode(array('success'=>'no',
                                'ecg_status'=>$ecg,
                                'status'=>400,
                                'message' => 'System Unavailable '
                                 )
                                     );
                        }
                        
                        $data['request_id'] = Requst::createID();			
                        $data['location'] = $location->name;
                        $data['is_paid'] = 1;
			$data['type_id'] = 1; //[1=purchase request, 2=balance request,3=consumption balance] 
                        
			$request = Requst::create($data);
                        
                        //return json_encode($request);
                        //add transaction
                        $this->AddTransaction($request->id,$data);
                        
                        //debit Partner account
//                        $partner->quota_bal = $partner->quota_bal - $request->amount;
//                        $partner->save();
                        //generate payment invoice
                        $invoice = MomoTransation::MazzumaPrepaidInvoice($request);
                        
                        //check if error
                        if (strlen($invoice['error'])>0) {
                            
                            return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=>'System Unavailable'
                                               
                                    )
                                    );
                        
                            
                        } else { //invoice was successfull
                             
                            $respose_data = json_decode($invoice['data']);

                            if($respose_data->status=='error') {
                                
                                return json_encode(array(
                                    'success'=>'no',
                                    'status'=>400,
                                    'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$respose_data->data
                                        )
                                        ));
                            }
                            
                            return Response::json(array(
                                'success'=>'yes',
                                'ecg_status'=>$ecg,
                                'status'=>200,
                                'message'=>'Transaction added successfully',
                                'request'=> array(
                                    'amount'=>$request['amount'],
                                    //'total'=> number_format($requst['amount'] + MomoTransation::getOrigginFee($requst['amount']), 2, '.', ','),
                                    'location'=>$request['location'],
                                    'id'=>$request['request_id']),
                                'invoice'=>array(
                                    'checkout_url'=> MomoPayment::$MazzumaPrepaidCheckout_url.$request['request_id'],
                                    'cancel_url'=>$invoice['cancelurl'],
                                    'return_url'=>$invoice['returnurl'],
                                    'status_url'=>MomoPayment::$invoicesuccess_url.$request['request_id'])
                            ));
                        }
		}
		return json_encode(array(
                    'success'=>'no',
                    'ecg_status'=>$ecg,
                    'status'=>400,
                    'message' =>'Invalid API Key',
                                
                    )
                        );
                
        }
        
        public function CheckTransactionStatus($api_key, $referenceid) {
            
            //check if payment was successful
            $temp = Partner::where('api_key',$api_key);
            
            if(count($temp->get())>0){                    
                
                $request = Requst::where('request_id',$referenceid)->get();
            
                if(count($request)==0) {
                    return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=>'Invalid Request id.'
                                    ));
                }
                
                $rq = $request->first();
            
            $transaction = MomoTransation::where('requst_id',$rq->id)->get();
            
            
            if(count($transaction)==0) {
                return json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Transaction not found.'
                                ));
            }
            
            $response = array();
            
            $tp = $transaction->first();
             
            if($tp->is_sold == 1) {
                $response = array(
                            'success'=>'yes',
                            'status'=>200,
                            'message'=>'Credit sold.'
                                );
            } else {
                $response = array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Transaction pending.'
                                );
            }
            
             return json_encode($response);
                
            } else {
                return json_encode(array(
                    'success'=>'no',                    
                    'status'=>400,
                    'message' =>'Invalid API Key',
                                
                    ));
            }
            
        }
        
        
         public function AddTransaction($id,$request)
	{
		$data = array();
                
                $origgin_charge = $request['type_id'] == 1 ? 0.00 :1.00;
                
                $api_charges = 0.20;
                
                $data['requst_id'] = $id;
		$data['ecg_amount'] = $request['type_id'] == 1 ?$request['amount']:0.00;
		$data['origgin_charge'] = $origgin_charge ;                
		$data['amount'] = $request['type_id'] == 1 ? $request['amount'] :1.00;
		$data['charges'] = $request['type_id'] == 1 ? 0.00 :$api_charges ;
		$data['amount_after_charges'] = $request['type_id'] == 1 ? 0.00 :0.8;
		$data['transaction_id'] = $request['request_id'];
		$data['response_code'] = '0000'; //pending	
		$data['client_refrence'] = $request['request_id'];
		//$data['external_transaction_id'] = $temp_data['Data']['SalesInvoiceId'];
                $data['pay_number'] = 'None';
                $data['payment_type'] = 3;
                $data['network'] = 'None';
		
                
		$transaction = MomoTransation::create($data);

//                $db = new DBConnector();
//                $transaction = $db->Insert($data, 'momo_transations');
         

		return $transaction;
		
	}
        
        
}
