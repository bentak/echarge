<?php
include_once 'dbconnect.php';

class PartnerBranchesController extends \BaseController {

    private $table = 'partner_branches';
    /**
     * Display a listing of locations
     *
     * @return Response
     */
    public function index()
    {
            $data['pagetab'] = 'partners';
            $data['branches'] = PartnerBranche::orderBy('branch_name','ASC')->get();

            return View::make('branches.index', $data);
    }

    public function locate($location)
    {
        $db = new DBConnector();
        $filter_key = trim($location);
        //check if location is valid smart meter location
        $ValidLocations = $db->Select("SELECT branch_name as name,LOCATE('$filter_key', branch_name) as p from partner_branches where branch_name RLIKE '$filter_key' ORDER BY p ASC LIMIT 10");

        return  json_encode(array(
                 'success'=>'yes',
                 'status'=>200,
                 'data'=> $ValidLocations
                     ));
    }


    function filterBranchAPI($api_key) {

       $rows = Input::get('_display');
        $from_date = Input::get('from_date');
        $to_date = Input::get('to_date');
        $filter = Input::get('filter');
        $filter_key = Input::get('filter_key');
        $offset = Input::get('offset');

        $temp = Partner::where('api_key',$api_key);

        if(count($temp->get())==0){               
            return json_encode(array(
                'success'=>'no',                    
                'status'=>400,
                'message' =>'Invalid API Key'                                
                )
                    );                
        } 

        $partner = $temp->first();

        $limit = $offset + $rows;

    switch ($filter) {
        case 0:
            $filter_sring = strlen($filter_key)>0? "branch_name RLIKE '$filter_key'":'';                
            break;
        case 1:
            $filter_sring = strlen($filter_key)>0? "branch_location RLIKE '$filter_key'":'';                
            break;
        case 2:
            $filter_sring = strlen($filter_key)>0? "user_name RLIKE '$filter_key'":'';                
            break;

        default:
            $filter_sring='';
            break;
    }

    //string for date 
    $date_string =''; $request_date='';
    if(strlen($from_date)>0 && strlen($to_date)>0){
        $date_string = "DATE($this->table.created_at) BETWEEN '$from_date' AND '$to_date'";
        $request_date="BETWEEN '$from_date' AND '$to_date'";
    } elseif (strlen($from_date)>0) {            
        $date_string = "DATE($this->table.created_at) BETWEEN '$from_date' AND '$from_date'";
        $request_date="BETWEEN '$from_date' AND '$from_date'";
    } elseif(strlen($to_date)>0) {
        $request_date="BETWEEN '$to_date' AND '$to_date'";
        $date_string = "DATE($this->table.created_at) BETWEEN '$to_date' AND '$to_date'";
    }


    $where = strlen($filter_sring)>0 ? "WHERE branch_partner=$partner->id AND $filter_sring":"WHERE branch_partner=$partner->id ";

    if (strlen($date_string)>0 && strlen($where)>0 ){
        $where .= " AND $date_string";
    } elseif (strlen($date_string)>0 && strlen($where)==0) {
        $where .= "WHERE $date_string";
    }

    $q = "SELECT partner_branches.branch_id as id,branch_name,created_at,branch_location,m.user_name AS manager FROM $this->table "
                    . "LEFT JOIN (SELECT user_id,user_name,user_branch FROM partner_users WHERE account_level=1) m "
            . "ON $this->table.branch_id=m.user_branch $where GROUP BY branch_name ORDER BY id DESC ";
    
    $db = new DBConnector();
    
    $branches = $db->Select($q);    
    
    $res = array();
    
    foreach ($branches as $branch) {
        $query = "SELECT IFNULL(SUM(amount),0.00) as sales FROM requsts "
                . "WHERE branch_id=".$branch['id']." AND is_sold=1 ".(strlen($request_date)>0?"AND DATE(sold_at) $request_date":"");
               
        $branch['sales'] = $db->SelectValue($query,'sales');
        $res[] = $branch;
    }
    
    if(is_array($branches)){
        if(count($res)>0) {
            echo json_encode(array('status'=>'ok','message'=>count($res).' results found.','data'=>$res));
        }
        else {
            echo json_encode(array('status'=>'ok','message'=>'No Branches found.','data'=>$res));
        }  
    } else {
        echo json_encode(array('status'=>'error','message'=>$branches));
    }


} 
        
    function addBranchAPI($api_key) {
        
        $data = Input::all();
        
        $temp = Partner::where('api_key',$api_key);

        if(count($temp->get())==0){               
            return json_encode(array(
                'success'=>'no',                    
                'status'=>400,
                'message' =>'Invalid API Key'                                
                )
                    );                
        }
        
        $partner = $temp->first();
            
        $branch = array ('branch_name'=> $data['branch_name'],
            'branch_partner'=>$partner->id,
            'branch_location'=> $data['branch_location'],
                );
        $validator = Validator::make($branch, PartnerBranche::$rules);

        if ($validator->fails())
        {
            return json_encode(array(
                'success'=>'no',                    
                'status'=>400,
                'message' =>$validator->messages()                                
                )
                    ); 
               
        }

        $created = PartnerBranche::create($branch);

        return json_encode(array(
                'success'=>'yes',                    
                'status'=>200,
                'message' =>'Branch Added Successfully.'                                
                )
                    );
           
        
    }
    
    function updateBranchAPI($id,$api_key) {
        
        $data = Input::all();
        
        $temp = Partner::where('api_key',$api_key);

        if(count($temp->get())==0){               
            return json_encode(array(
                'success'=>'no',                    
                'status'=>400,
                'message' =>'Invalid API Key'                                
                )
                    );                
        }        
        //$partner = $temp->first();
        
        $btemp = PartnerBranche::where('branch_id',$id);

        if(count($btemp->get())==0){               
            return json_encode(array(
                'success'=>'no',                    
                'status'=>400,
                'message' =>'Invalid Branch ID.'                                
                )
                    );                
        }        
        $branch = $temp->first();        
            
        $input = array ('branch_name'=> $data['branch_name'],            
            'branch_location'=> $data['branch_location'],
                );
        $validator = Validator::make($input, PartnerBranche::$rules);

        if ($validator->fails())
        {
            return json_encode(array(
                'success'=>'no',                    
                'status'=>400,
                'message' =>$validator->messages()                                
                )
                    ); 
               
        }

        $branch->update($input);

        return json_encode(array(
                'success'=>'yes',                    
                'status'=>200,
                'message' =>'Branch Updated Successfully.'                                
                )
                    );
           
        
    }

	/**
	 * Show the form for creating a new location
	 *
	 * @return Response
	 */
	public function create()
	{
            $data['partners'] = Partner::orderBy('partner_name','ASC')->get();	
            return View::make('branches.create', $data);
	}

	/**
	 * Store a newly created location in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), Location::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		PartnerBranche::create($data);

		return Redirect::route('branches.index');
	}

	/**
	 * Display the specified location.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$location = PartnerBranche::findOrFail($id);

		return View::make('locations.show', compact('location'));
	}

	/**
	 * Show the form for editing the specified location.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$location = PartnerBranche::find($id);

		return View::make('locations.edit', compact('location'));
	}

	/**
	 * Update the specified location in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$location = PartnerBranche::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Location::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$location->update($data);

		return Redirect::route('locations.index');
	}

	/**
	 * Remove the specified location from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		PartnerBranche::destroy($id);

		return Redirect::route('locations.index');
	}

}
