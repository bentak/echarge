<?php

class UsersController extends \BaseController {

	/**
	 * Display a listing of users
	 *
	 * @return Response
	 */
	public function index()
	{
		$users = User::all();

		return View::make('users.index', compact('users'));
	}

	/**
	 * Show the form for creating a new user
	 *
	 * @return Response
	 */
	public function create()
	{
		

		return View::make('users.create');
	}

	/**
	 * Store a newly created user in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		

		$validator = Validator::make($data = Input::all(), User::$rules);

		if ($validator->fails())
		{
			Session::flash('mt', 'warning');
			Session::flash('ms', 'Please check error(s) indicated and try again.');
			return Redirect::back()->withErrors($validator)->withInput();
		}

		User::create($data);

		Session::flash('mt', 'success');
		Session::flash('ms', 'User successfully registered.');
		return Redirect::route('users.index');
	}

	/**
	 * Display the specified user.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$user = User::findOrFail($id);

		return View::make('users.show', compact('user'));
	}

	/**
	 * Show the form for editing the specified user.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		

		$user = User::find($id);

		return View::make('users.edit', compact('user'));
	}

	/**
	 * Update the specified user in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		

		$user = User::findOrFail($id);

		$data = Input::all();

		$rules = User::$update_rules1;

		if($user->email == $data['email']) $rules = User::$update_rules2;

		$validator = Validator::make($data, $rules);

		if ($validator->fails())
		{
			Session::flash('mt', 'warning');
			Session::flash('ms', 'Please check error(s) indicated and try again.');
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$user->update($data);

		Session::flash('mt', 'success');
		Session::flash('ms', 'Successfully updated user');
		return Redirect::route('users.index');
	}

	/**
	 * Remove the specified user from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		

		User::destroy($id);

		Session::flash('mt', 'success');
		Session::flash('ms', 'Successfully deleted user');
		return Redirect::route('users.index');
	}


	public function signin()
	{
		if(Auth::check()){

		}
			
		$rules = array(
	    'email'=>'required|email',
	   	'password'=>'required|between:6,20',
		);
		
		$validator = Validator::make(Input::all(), $rules);
		
		if ($validator->fails()) {
			Session::flash('mt', 'warning');
			Session::flash('ms', 'Wrong email and/or password. Please check and try again.');
			
			return Redirect::to('signin')
				->withErrors($validator)
				->withInput(Input::except('password'));
		} else { 
			$email       = Input::get('email');
			$password     = Input::get('password');
			
			if (Auth::attempt(array('email' => $email, 'password' => $password))){
				
				Session::flash('mt', 'success');
				Session::flash('ms', 'Successfully Signed in!');
				return Redirect::intended('');
				
				} else { 
					Session::flash('mt', 'warning');
					Session::flash('ms', 'Something went wrong. Please try again.');
					return Redirect::to('signin');
				}
			}
		
	}

	public function profile()
	{
		$user = Auth::user();

		return View::make('users.profile', compact('user'));
	}

	public function profileUpdate()
	{
		$user = User::findOrFail(Auth::user()->id);

		$data = Input::all();

		$rules = User::$profile_rules;
		if(Auth::user()->email == $data['email']) $rules = User::$profile_rules2;

		$validator = Validator::make($data, $rules);

		if ($validator->fails())
		{
			Session::flash('mt', 'warning');
			Session::flash('ms', 'Please check error(s) indicated and try again.');
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$user->update($data);

		Session::flash('mt', 'success');
		Session::flash('ms', 'Profile successfully updated');
		return Redirect::back();
	}

	public function changePassword()
	{
		$user = User::findOrFail(Auth::user()->id);

		$data = Input::all();

		$validator = Validator::make($data, User::$pc_rules);

		if ($validator->fails())
		{
			Session::flash('mt', 'warning');
			Session::flash('ms', 'Please check error(s) indicated and try again.');
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$user->update($data);

		Session::flash('mt', 'success');
		Session::flash('ms', 'Password successfully changed');
		return Redirect::back();
	}

	public function getSignin(){
		if(Auth::check()){
			Session::flash('mt', 'success');
			Session::flash('ms', 'You are already signed in!');
		} 
		
		return Redirect::to('/');
	}
	
	public function signout(){
			Session::flush();
			Auth::logout();
			Session::flash('mt', 'success');
			Session::flash('ms', 'You have successfully logged out.');
			return Redirect::to('');
	}

	public function apiLogin(){
		
		$username     = Input::get('username');
		$password     = Input::get('password');
		
		if (Auth::attempt(array('username' => $username, 'password' => $password))){
			return json_encode(array('user_exists'=>'yes','status'=>200,'user_id'=>Auth::user()->id));
		}

		return json_encode(array('user_exists'=>'no','status'=>200));
	}

}
