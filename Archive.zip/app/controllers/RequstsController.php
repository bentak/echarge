<?php
include_once 'dbconnect.php';

class RequstsController extends \BaseController {

    
        public function recent($recentid)
	{       
            $db = new DBConnector();
            
            $query = "SELECT requsts.*,phone,name,email FROM requsts ";
            $query .= "JOIN customers ON customer_id=customers.id ";
            $query .= "WHERE is_paid=0 AND requsts.id>$recentid";
            
            $new = $db->Select($query);
            //$new = MomoTransation::where('is_sold',0)->where('response_code','0000')->where('id','>',$recentid)->get();
                
            return Response::json(array(
                'status'=>'ok',
                'data'=>$new));                
	}
        
	/**
	 * Display a listing of requsts
	 *
	 * @return Response
	 */
	public function index($from="",$to="")
	{
            $data['pagetab'] = 'requests';
            $data['requests'] = strlen($from)==0 && strlen($to)==0 ?
                    Requst::where('is_paid',0)->where('created_at','>=',date('Y-m-d 00:00:00'))->where('created_at','<=',date('Y-m-d 23:59:59'))->orderBy('id','DESC')->get():                    
                    Requst::where('is_paid',0)->where('created_at','>=',date($from.' 00:00:00'))->where('created_at','<=',date($to.' 23:59:59'))->orderBy('id','DESC')->get();
            
            $data['from'] = strlen($from)==0?date('Y-m-d'): $from;
            $data['to'] = strlen($to)==0?date('Y-m-d'): $to;
            
            return View::make('requsts.index', $data);
	}

	/**
	 * Show the form for creating a new requst
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('requsts.create');
	}

	/**
	 * Store a newly created requst in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), Requst::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		Requst::create($data);

		return Redirect::route('requsts.index');
	}

	/**
	 * Display the specified requst.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$requst = Requst::findOrFail($id);

		return View::make('requsts.show', compact('requst'));
	}

	/**
	 * Show the form for editing the specified requst.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$requst = Requst::find($id);

		return View::make('requsts.edit', compact('requst'));
	}

	/**
	 * Update the specified requst in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$requst = Requst::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Requst::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$requst->update($data);

		return Redirect::route('requsts.index');
	}

	/**
	 * Remove the specified requst from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Requst::destroy($id);

		return Redirect::route('requsts.index');
	}

	public function apiPostInitiateRequest($token){
            //check ecg status            
            $ecg = EcgStatus::currentStatus();
            
            //
		$temp = Customer::where('customer_token',$token);
                
                $data = Input::all();
                $data['created_at'] = date('Y-m-d H:i:s');
               $data['updated_at'] = date('Y-m-d H:i:s');

		if(count($temp->get())>0){
                    
			$customer = $temp->first();
                        
                         //raw mysql code
                            $db = new DBConnector(); 
                            
                        if($customer->block_exception!=1) {
                            
                            $is_blocked = BlockedList::customerBlockedStatus($customer->id);
                        
                            if($is_blocked == TRUE) {
                                
                                $data['type_id'] = 1;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'oldapp-customer blocked';
                                $db->Insert($data,"denied_requests");
                            
                                //send error response
                                //return json_encode(array('request_initiated'=>'no','status'=>400, 'errors' => 'customer blocked' ));
                                 header('HTTP/1.1 404 Customer blocked');
                                 exit();
                            }                                   

                             //get request that have come in the last 15min
                             //$max_requests = Requst::where('customer_id',$customer->id)->where('DATE(created_at)',$todays_date);
                             $max_requests = $db->SelectValue("SELECT COUNT(*) AS requests FROM requsts WHERE customer_id=$customer->id AND is_paid=0",'requests');

                             if($max_requests>=5) {

                                $data['type_id'] = 1;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'oldapp-maximum requests ecxeeded';
                                $db->Insert($data,"denied_requests");
                            
                                 $add_block = array(
                                     'blocked_customer'=>$customer->id,
                                     'blocked_contact'=>$customer->phone,
                                     'created_at'=>date('Y-m-d H:i:s')
                                     );

                                 $block_added = $db->Insert($add_block,"blocked_lists");
                                 //send error response
                                 //return json_encode(array('request_initiated'=>'no','status'=>400, 'errors' => 'max request exceeded for today' ));

                                 header('HTTP/1.1 404 Maximum request exceeded');
                                  exit();
                             }
                        }

			
                        $data['customer_id'] = $customer->id;
                        
			$validator = Validator::make($data, Requst::$initiateRules);

			if ($validator->fails())
			{
                            $data['type_id'] = 1;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'oldapp-invalid fields';
                            $db->Insert($data,"denied_requests");
                            
				return json_encode(array('request_initiated'=>'no','ecg_status'=>$ecg,'status'=>400,'errors'=>$validator->messages()));
			}
                        
                        $filter_key = $data['location'];
                        //check if location is valid smart meter location
                        $isValidLocation = $db->SelectValue("SELECT count(*) as found from locations where description RLIKE '$filter_key'", 'found');
                        
                        if($isValidLocation==0) {
                            
                            $data['type_id'] = 1;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'oldapp-unsupported location';
                            $db->Insert($data,"denied_requests");
                            
                            header('HTTP/1.1 404 Unsupported location');
                             exit();
//                            return json_encode(array('request_initiated'=>'no',                                
//                                'status'=>400,
//                                'errors' => 'Invalid Location. Sorry, your current location is not in the ECG smart meter location range.' ));
                        }
                        
                        //return status 400 if ecg is off
                        if($ecg == "0") {
                            
                            $data['type_id'] = 1;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'oldapp-system offline';
                            $db->Insert($data,"denied_requests");
                            
                            header('HTTP/1.1 404 ECG system offline');
                             exit();
                            //return json_encode(array('request_initiated'=>'no','ecg_status'=>$ecg,'status'=>400, 'errors' => 'Server offline' ));
                        }
                        
                        //$data['request_id'] = Requst::createID();			
			$data['type_id'] = 1; //[1=purchase request, 2=balance request,3=consumption balance] 
			$data['reject_reason'] = 'app expired';
                        $db->Insert($data,"denied_requests");
                        
                        return Response::json(array(
                            'request_initiated'=>'no',
                            'ecg_status'=>$ecg,
                            'status'=>400,
                            'errors'=> 'app expired')
                                );
                 
		}
		return json_encode(array('request_initiated'=>'no','ecg_status'=>$ecg,'status'=>400, 'errors' => 'Invalid token' ));
	}
                
	public function apiPostInitiateNewRequest($token){
            //check ecg status            
            $ecg = EcgStatus::currentStatus();
            
            //
		$temp = Customer::where('customer_token',$token);
                               
                $data = Input::all();
                
                $data['created_at'] = date('Y-m-d H:i:s');
               $data['updated_at'] = date('Y-m-d H:i:s');
                
		if(count($temp->get())>0){
                    
			$customer = $temp->first();
                        
                        //raw mysql code
                           $db = new DBConnector();
                        
                        if($customer->block_exception!=1) {
                            
                            $is_blocked = BlockedList::customerBlockedStatus($customer->id);
                        
                            if($is_blocked == TRUE) {
                                
                                $data['type_id'] = 1;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'customer blocked';
                                $db->Insert($data,"denied_requests");
                            
                                //send error response
                                return json_encode(array('request_initiated'=>'no',
                                    'status'=>400, 
                                    'errors' => array(
                                        'title'=>'Customer Block',
                                        'message'=>'Dear customer, your number has been blocked because you have exceeded the maximum request attempts permissible by this app. Kindly call 0237583931 for assistance. Thank you.'
                                        )
                                    )
                                        );
                            }                                        

                            //get request that have come in the last 15min
                            //$max_requests = Requst::where('customer_id',$customer->id)->where('DATE(created_at)',$todays_date);
                            $max_requests = $db->SelectValue("SELECT COUNT(*) AS requests FROM requsts WHERE customer_id=$customer->id AND is_paid=0",'requests');

                            if($max_requests>5) {
                                
                                $data['type_id'] = 1;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'maximum requests exceeded';
                                $db->Insert($data,"denied_requests");

                                $add_block = array(
                                    'blocked_customer'=>$customer->id,
                                    'blocked_contact'=>$customer->phone,
                                    'created_at'=>date('Y-m-d H:i:s')
                                    );

                                $block_added = $db->Insert($add_block,"blocked_lists");
                                //send error response
                                return json_encode(array('request_initiated'=>'no',
                                     'status'=>400, 
                                     'errors' => array(
                                         'title'=>'Customer Block',
                                         'message'=>'Dear customer, your number has been blocked because you have exceeded the maximum request attempts permissible by this app. Kindly call 0237583931 for assistance. Thank you.'
                                         )
                                    )
                                        );
                            }                        
                            
                        }
			
                        $data['customer_id'] = $customer->id;
			$validator = Validator::make($data, Requst::$initiateRules);

			if ($validator->fails())
			{
                            $data['type_id'] = 1;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'invalid fields';
                            $db->Insert($data,"denied_requests");
                            
				return json_encode(
                                        array(
                                            'request_initiated'=>'no',
                                            'ecg_status'=>$ecg,
                                            'status'=>400,
                                            'errors'=> array(
                                                'title'=>'Wrong Values',
                                                'message'=>$validator->messages()
                                        )
                                            )
                                        );
			}
                        
                        $filter_key = trim($data['location']);
                        //check if location is valid smart meter location
                        $isValidLocation = $db->SelectValue("SELECT count(*) as found from locations where description RLIKE '$filter_key'", 'found');
                                
                        if($isValidLocation==0) {
                            
                            $data['type_id'] = 1;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'unsupported location';
                            $db->Insert($data,"denied_requests");
                            
                            return json_encode(array('request_initiated'=>'no',                                
                                'status'=>400,
                                'errors' => array(
                                                'title'=>'Unsupported Location',
                                                'message'=>'Sorry, your current location is not in our catchment areas.'
                                        )
                                ));
                        }
                        
                        //return status 400 if ecg is off
                        if($ecg == "0") {
                            
                            $data['type_id'] = 1;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'system offline';
                            $db->Insert($data,"denied_requests");
                            
                             return json_encode(array('request_initiated'=>'no',
                                'ecg_status'=>$ecg,
                                'status'=>400,
                                'errors' => array(
                                                'title'=>'System Unavailable ',
                                                'message'=>'Sorry, the system is currently unavailable. Please try again later.'
                                        ) 
                                 )
                                     );
                        }
                        
                        $data['request_id'] = Requst::createID();
			$data['customer_id'] = $customer->id;
			$data['type_id'] = 1; //[1=purchase request, 2=balance request,3=consumption balance] 
			$requst = Requst::create($data);
                        
                        //generate payment invoice
                        $invoice = MomoTransation::MazzumaPrepaidInvoice($requst);
                        
                        //check if error
                        if (strlen($invoice['error'])>0) {
                            
                            return json_encode(array(
                                'request_initiated'=>'no',
                                'status'=>400,
                                'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$invoice['error']
                                        )
                                    )
                                    );
                        
                            
                        } else { //invoice was successfull
                             
                            $respose_data = json_decode($invoice['data']);
                            
//                            echo print_r($respose_data);
//                            exit();
//                            
                            if($respose_data->status=='Error') {
                                
                                return json_encode(array(
                                    'request_initiated'=>'no',
                                    'status'=>400,
                                    'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$respose_data->data
                                        )
                                        ));
                            }
                            
                            return Response::json(array(
                                'request_initiated'=>'yes',
                                'ecg_status'=>$ecg,
                                'status'=>200,
                                'request'=> array(
                                    'amount'=>$requst['amount'],
                                    'total'=> number_format($requst['amount'] + MomoTransation::getOrigginFee($requst['amount']), 2, '.', ','),
                                    'location'=>$requst['location'],
                                    'request_id'=>$requst['request_id']),
                                'invoice'=>array(
                                    'checkout_url'=>$respose_data->data->checkoutUrl,
                                    'cancel_url'=>$invoice['cancelurl'],
                                    'return_url'=>$invoice['returnurl'],
                                    'status_url'=>$invoice['statusurl'])
                            ));
                        }
		}
		return json_encode(array(
                    'request_initiated'=>'no',
                    'ecg_status'=>$ecg,
                    'status'=>400,
                    'errors' => array(
                                'title'=>'Wrong Token',
                                'message'=>'Customer token is invalid.'
                                )
                    )
                        );
                
        }
                
	public function api2PostInitiateNewRequest($token){
            //check ecg status            
            $ecg = EcgStatus::currentStatus();
            
            //
		$temp = Customer::where('customer_token',$token);
                               
                $data = Input::all();
                
                $data['created_at'] = date('Y-m-d H:i:s');
               $data['updated_at'] = date('Y-m-d H:i:s');
                
		if(count($temp->get())>0){
                    
			$customer = $temp->first();
                        
                        //raw mysql code
                           $db = new DBConnector();
                        
                        if($customer->block_exception!=1) {
                            
                            $is_blocked = BlockedList::customerBlockedStatus($customer->id);
                        
                            if($is_blocked == TRUE) {
                                
                                $data['type_id'] = 1;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'customer blocked';
                                $db->Insert($data,"denied_requests");
                            
                                //send error response
                                return json_encode(array('request_initiated'=>'no',
                                    'status'=>400, 
                                    'errors' => array(
                                        'title'=>'Customer Block',
                                        'message'=>'Dear customer, your number has been blocked because you have exceeded the maximum request attempts permissible by this app. Kindly call 0237583931 for assistance. Thank you.'
                                        )
                                    )
                                        );
                            }                                        

                            //get request that have come in the last 15min
                            //$max_requests = Requst::where('customer_id',$customer->id)->where('DATE(created_at)',$todays_date);
                            $max_requests = $db->SelectValue("SELECT COUNT(*) AS requests FROM requsts WHERE customer_id=$customer->id AND is_paid=0",'requests');

                            if($max_requests>5) {
                                
                                $data['type_id'] = 1;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'maximum requests exceeded';
                                $db->Insert($data,"denied_requests");

                                $add_block = array(
                                    'blocked_customer'=>$customer->id,
                                    'blocked_contact'=>$customer->phone,
                                    'created_at'=>date('Y-m-d H:i:s')
                                    );

                                $block_added = $db->Insert($add_block,"blocked_lists");
                                //send error response
                                return json_encode(array('request_initiated'=>'no',
                                     'status'=>400, 
                                     'errors' => array(
                                         'title'=>'Customer Block',
                                         'message'=>'Dear customer, your number has been blocked because you have exceeded the maximum request attempts permissible by this app. Kindly call 0237583931 for assistance. Thank you.'
                                         )
                                    )
                                        );
                            }                        
                            
                        }
			
                        $data['customer_id'] = $customer->id;
			$validator = Validator::make($data, Requst::$initiateRules);

			if ($validator->fails())
			{
                            $data['type_id'] = 1;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'invalid fields';
                            $db->Insert($data,"denied_requests");
                            
				return json_encode(
                                        array(
                                            'request_initiated'=>'no',
                                            'ecg_status'=>$ecg,
                                            'status'=>400,
                                            'errors'=> array(
                                                'title'=>'Wrong Values',
                                                'message'=>$validator->messages()
                                        )
                                            )
                                        );
			}
                        
                        $filter_key = trim($data['location']);
                        //check if location is valid smart meter location
                        $isValidLocation = $db->SelectValue("SELECT count(*) as found from locations where description RLIKE '$filter_key'", 'found');
                                
                        if($isValidLocation==0) {
                            
                            $data['type_id'] = 1;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'unsupported location';
                            $db->Insert($data,"denied_requests");
                            
                            return json_encode(array('request_initiated'=>'no',                                
                                'status'=>400,
                                'errors' => array(
                                                'title'=>'Unsupported Location',
                                                'message'=>'Sorry, your current location is not in our catchment areas.'
                                        )
                                ));
                        }
                        
                        //return status 400 if ecg is off
                        if($ecg == "0") {
                            
                            $data['type_id'] = 1;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'system offline';
                            $db->Insert($data,"denied_requests");
                            
                             return json_encode(array('request_initiated'=>'no',
                                'ecg_status'=>$ecg,
                                'status'=>400,
                                'errors' => array(
                                                'title'=>'System Unavailable ',
                                                'message'=>'Sorry, the system is currently unavailable. Please try again later.'
                                        ) 
                                 )
                                     );
                        }
                        
                        $data['request_id'] = Requst::createID();
			$data['customer_id'] = $customer->id;
			$data['type_id'] = 1; //[1=purchase request, 2=balance request,3=consumption balance] 
			$requst = Requst::create($data);
                        
                        //generate payment invoice
                        $invoice = MomoTransation::MazzumaPrepaidInvoice($requst);
                        
                        //check if error
                        if (strlen($invoice['error'])>0) {
                            
                            return json_encode(array(
                                'request_initiated'=>'no',
                                'status'=>400,
                                'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$invoice['error']
                                        )
                                    )
                                    );
                        
                            
                        } else { //invoice was successfull
                             
                            $respose_data = json_decode($invoice['data']);
                            
//                            echo print_r($respose_data);
//                            exit();
//                            
                            if($respose_data->status=='Error') {
                                
                                return json_encode(array(
                                    'request_initiated'=>'no',
                                    'status'=>400,
                                    'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$respose_data->data
                                        )
                                        ));
                            }
                            
                            return Response::json(array(
                                'request_initiated'=>'yes',
                                'ecg_status'=>$ecg,
                                'status'=>200,
                                'request'=> array(
                                    'amount'=>$requst['amount'],
                                    'total'=> number_format($requst['amount'] + MomoTransation::getOrigginFee($requst['amount']), 2, '.', ','),
                                    'location'=>$requst['location'],
                                    'request_id'=>$requst['request_id']),
                                'invoice'=>array(
                                    'checkout_url'=> MomoPayment::$MazzumaPrepaidCheckout_url.$requst['request_id'],
                                    'cancel_url'=>$invoice['cancelurl'],
                                    'return_url'=>$invoice['returnurl'],
                                    'status_url'=>MomoPayment::$invoicesuccess_url.$requst['request_id'])
                            ));
                        }
		}
		return json_encode(array(
                    'request_initiated'=>'no',
                    'ecg_status'=>$ecg,
                    'status'=>400,
                    'errors' => array(
                                'title'=>'Wrong Token',
                                'message'=>'Customer token is invalid.'
                                )
                    )
                        );
                
        }
        
	public function apiV2PostInitiateNewRequest($token){
            //check ecg status            
            $ecg = EcgStatus::currentStatus();
            
            //
		$temp = Customer::where('customer_token',$token);
                               
                $data = Input::all();
                
                $data['created_at'] = date('Y-m-d H:i:s');
               $data['updated_at'] = date('Y-m-d H:i:s');
                
		if(count($temp->get())>0){
                    
			$customer = $temp->first();
                        
                        //raw mysql code
                           $db = new DBConnector();
                        
                        if($customer->block_exception!=1) {
                            
                            $is_blocked = BlockedList::customerBlockedStatus($customer->id);
                        
                            if($is_blocked == TRUE) {
                                
                                $data['type_id'] = 1;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'customer blocked';
                                $db->Insert($data,"denied_requests");
                            
                                //send error response
                                return json_encode(array('request_initiated'=>'no',
                                    'status'=>400, 
                                    'errors' => array(
                                        'title'=>'Customer Block',
                                        'message'=>'Dear customer, your number has been blocked because you have exceeded the maximum request attempts permissible by this app. Kindly call 0237583931 for assistance. Thank you.'
                                        )
                                    )
                                        );
                            }                                        

                            //get request that have come in the last 15min
                            //$max_requests = Requst::where('customer_id',$customer->id)->where('DATE(created_at)',$todays_date);
                            $max_requests = $db->SelectValue("SELECT COUNT(*) AS requests FROM requsts WHERE customer_id=$customer->id AND is_paid=0",'requests');

                            if($max_requests>5) {
                                
                                $data['type_id'] = 1;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'maximum requests exceeded';
                                $db->Insert($data,"denied_requests");

                                $add_block = array(
                                    'blocked_customer'=>$customer->id,
                                    'blocked_contact'=>$customer->phone,
                                    'created_at'=>date('Y-m-d H:i:s')
                                    );

                                $block_added = $db->Insert($add_block,"blocked_lists");
                                //send error response
                                return json_encode(array('request_initiated'=>'no',
                                     'status'=>400, 
                                     'errors' => array(
                                         'title'=>'Customer Block',
                                         'message'=>'Dear customer, your number has been blocked because you have exceeded the maximum request attempts permissible by this app. Kindly call 0237583931 for assistance. Thank you.'
                                         )
                                    )
                                        );
                            }                        
                            
                        }
			
                        $data['customer_id'] = $customer->id;
			$validator = Validator::make($data, Requst::$initiateRules);

			if ($validator->fails())
			{
                            $data['type_id'] = 1;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'invalid fields';
                            $db->Insert($data,"denied_requests");
                            
				return json_encode(
                                        array(
                                            'request_initiated'=>'no',
                                            'ecg_status'=>$ecg,
                                            'status'=>400,
                                            'errors'=> array(
                                                'title'=>'Wrong Values',
                                                'message'=>$validator->messages()
                                        )
                                            )
                                        );
			}
                        
                        $filter_key = trim($data['location']);
                        //check if location is valid smart meter location
                        $isValidLocation = $db->SelectValue("SELECT count(*) as found from locations where description RLIKE '$filter_key'", 'found');
                                
                        if($isValidLocation==0) {
                            
                            $data['type_id'] = 1;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'unsupported location';
                            $db->Insert($data,"denied_requests");
                            
                            return json_encode(array('request_initiated'=>'no',                                
                                'status'=>400,
                                'errors' => array(
                                                'title'=>'Unsupported Location',
                                                'message'=>'Sorry, your current location is not in our catchment areas.'
                                        )
                                ));
                        }
                        
                        //return status 400 if ecg is off
                        if($ecg == "0") {
                            
                            $data['type_id'] = 1;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'system offline';
                            $db->Insert($data,"denied_requests");
                            
                             return json_encode(array('request_initiated'=>'no',
                                'ecg_status'=>$ecg,
                                'status'=>400,
                                'errors' => array(
                                                'title'=>'System Unavailable ',
                                                'message'=>'Sorry, the system is currently unavailable. Please try again later.'
                                        ) 
                                 )
                                     );
                        }
                        
                        $data['request_id'] = Requst::createID();
			$data['customer_id'] = $customer->id;
			$data['type_id'] = 1; //[1=purchase request, 2=balance request,3=consumption balance] 
			$requst = Requst::create($data);
                        
                        //generate payment invoice
                        $invoice = MomoTransation::MazzumaPrepaidInvoice($requst);
                        
                        //check if error
                        if (strlen($invoice['error'])>0) {
                            
                            return json_encode(array(
                                'request_initiated'=>'no',
                                'status'=>400,
                                'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$invoice['error']
                                        )
                                    )
                                    );
                        
                            
                        } else { //invoice was successfull
                             
                            $respose_data = json_decode($invoice['data']);
                            
//                            echo print_r($respose_data);
//                            exit();
//                            
                            if($respose_data->status=='Error') {
                                
                                return json_encode(array(
                                    'request_initiated'=>'no',
                                    'status'=>400,
                                    'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$respose_data->data
                                        )
                                        ));
                            }
                            
                            return Response::json(array(
                                'request_initiated'=>'yes',
                                'ecg_status'=>$ecg,
                                'status'=>200,
                                'request'=> array(
                                    'amount'=>$requst['amount'],
                                    'total'=> number_format($requst['amount'] + MomoTransation::getOrigginFee($requst['amount']), 2, '.', ','),
                                    'location'=>$requst['location'],
                                    'request_id'=>$requst['request_id']),
                                'invoice'=>array(
                                    'checkout_url'=> MomoPayment::$MazzumaPrepaidCheckout_url.$requst['request_id'],
                                    'cancel_url'=>$invoice['cancelurl'],
                                    'return_url'=>$invoice['returnurl'],
                                    'status_url'=>MomoPayment::$invoicesuccess_url.$requst['request_id'])
                            ));
                        }
		}
		return json_encode(array(
                    'request_initiated'=>'no',
                    'ecg_status'=>$ecg,
                    'status'=>400,
                    'errors' => array(
                                'title'=>'Wrong Token',
                                'message'=>'Customer token is invalid.'
                                )
                    )
                        );
                
        }        
        
        public function apiPostCheckBalance($token){
            //check ecg status            
            $ecg = EcgStatus::currentStatus();
            
            //
		$temp = Customer::where('customer_token',$token);
                
                $data = Input::all();
               $data['created_at'] = date('Y-m-d H:i:s');
               $data['updated_at'] = date('Y-m-d H:i:s');
                
		if(count($temp->get())>0){
                    
			$customer = $temp->first();
                        
                         $data['customer_id'] = $customer->id;
                         //raw mysql code
                           $db = new DBConnector();  
                           
                        if($customer->block_exception!=1) {
                            
                            $is_blocked = BlockedList::customerBlockedStatus($customer->id);
                        
                            if($is_blocked == TRUE) {
                                
                                $data['type_id'] = 2;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'customer blocked';
                                $db->Insert($data,"denied_requests");
                                
                                //send error response
                                return json_encode(array('request_initiated'=>'no',
                                    'status'=>400, 
                                    'errors' => array(
                                        'title'=>'Customer Block',
                                        'message'=>'Dear customer, your number has been blocked because you have exceeded the maximum request attempts permissible by this app. Kindly call 0237583931 for assistance. Thank you.'
                                        )
                                    )
                                        );

                            }                                 

                            //get request that have come in the last 15min
                            //$max_requests = Requst::where('customer_id',$customer->id)->where('DATE(created_at)',$todays_date);
                            $max_requests = $db->SelectValue("SELECT COUNT(*) AS requests FROM requsts WHERE customer_id=$customer->id AND is_paid=0",'requests');

                            if($max_requests>=5) {
                                
                                $data['type_id'] = 2;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'maximum request exceeded';
                                $db->Insert($data,"denied_requests");
                                
                                $add_block = array(
                                    'blocked_customer'=>$customer->id,
                                    'blocked_contact'=>$customer->phone,
                                    'created_at'=>date('Y-m-d H:i:s')
                                    );

                                $db->Insert($add_block,"blocked_lists");
                                //send error response
                                return json_encode(array('request_initiated'=>'no',
                                     'status'=>400, 
                                     'errors' => array(
                                         'title'=>'Customer Block',
                                         'message'=>'Dear customer, your number has been blocked because you have exceeded the maximum request attempts permissible by this app. Kindly call 0237583931 for assistance. Thank you.'
                                         )
                                    )
                                        );
                            }
                            
                        }

			$validator = Validator::make($data, Requst::$initiateRules);

			if ($validator->fails())
			{
                            $data['type_id'] = 2;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'invalid fields';
                            $db->Insert($data,"denied_requests");
                            
				return json_encode(
                                        array(
                                            'request_initiated'=>'no',
                                            'ecg_status'=>$ecg,
                                            'status'=>400,
                                            'errors'=> array(
                                                'title'=>'Wrong Values',
                                                'message'=>$validator->messages()
                                        )
                                            )
                                        );
			}
                        
                        $filter_key = trim($data['location']);
                        //check if location is valid smart meter location
                        $isValidLocation = $db->SelectValue("SELECT count(*) as found from locations where description RLIKE '$filter_key'", 'found');
                                
                        if($isValidLocation==0) {
                            
                            $data['type_id'] = 2;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'unsupported location';
                            $db->Insert($data,"denied_requests");
                            
                            return json_encode(array('request_initiated'=>'no',                                
                                'status'=>400,
                                'errors' => array(
                                                'title'=>'Unsupported Location',
                                                'message'=>'Sorry, your current location is not in our catchment areas.'
                                        )
                                ));
                        }
                        
                        //return status 400 if ecg is off
                        if($ecg == "0") {
                            
                            $data['type_id'] = 2;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'system offline';
                            $db->Insert($data,"denied_requests");
                            
                             return json_encode(array('request_initiated'=>'no',
                                'ecg_status'=>$ecg,
                                'status'=>400,
                                'errors' => array(
                                                'title'=>'System Unavailable ',
                                                'message'=>'Sorry, the system is currently unavailable. Please try again later.'
                                        ) 
                                 )
                                     );
                        }
                        
                        $data['amount'] = 1.0;                        
			$data['request_id'] = Requst::createID();
			$data['customer_id'] = $customer->id;
			$data['type_id'] = 2; //[1=purchase request, 2=balance request,3=consumption balance]
                        
			$requst = Requst::create($data);
                        
                        //generate payment invoice
                        $invoice = MomoTransation::MazzumaBalanceInvoice($requst);
                        
                        //check if error
                        if (strlen($invoice['error'])>0) {
                            
                            return json_encode(array(
                                'request_initiated'=>'no',
                                'status'=>400,
                                'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$invoice['error']
                                        )
                                    )
                                    );
                        
                            
                        } else { //invoice was successfull
                             
                            $respose_data = json_decode($invoice['data']);
                            
//                            echo print_r($respose_data);
//                            exit();
//                            
                            if($respose_data->status=='Error') {
                                
                                return json_encode(array(
                                    'request_initiated'=>'no',
                                    'status'=>400,
                                    'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$respose_data->data
                                        )
                                        ));
                            }
                            
                            return Response::json(array(
                                'request_initiated'=>'yes',
                                'ecg_status'=>$ecg,
                                'status'=>200,
                                'request'=> array(
                                    'amount'=>$requst['amount'],
                                    'total'=>$requst['amount'],
                                    'location'=>$requst['location'],
                                    'request_id'=>$requst['request_id']),
                                'invoice'=>array(
                                    'checkout_url'=>$respose_data->data->checkoutUrl,
                                    'cancel_url'=>$invoice['cancelurl'],
                                    'return_url'=>$invoice['returnurl'],
                                    'status_url'=>$invoice['statusurl'])
                            ));
                        }
		}
		return json_encode(array(
                    'request_initiated'=>'no',
                    'ecg_status'=>$ecg,
                    'status'=>400,
                    'errors' => array(
                                'title'=>'Wrong Token',
                                'message'=>'Customer token is invalid.'
                                )
                    )
                        );
	}
        
        public function api2PostCheckBalance($token){
            //check ecg status            
            $ecg = EcgStatus::currentStatus();
            
            //
		$temp = Customer::where('customer_token',$token);
                
                $data = Input::all();
               $data['created_at'] = date('Y-m-d H:i:s');
               $data['updated_at'] = date('Y-m-d H:i:s');
                
		if(count($temp->get())>0){
                    
			$customer = $temp->first();
                        
                         $data['customer_id'] = $customer->id;
                         //raw mysql code
                           $db = new DBConnector();  
                           
                        if($customer->block_exception!=1) {
                            
                            $is_blocked = BlockedList::customerBlockedStatus($customer->id);
                        
                            if($is_blocked == TRUE) {
                                
                                $data['type_id'] = 2;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'customer blocked';
                                $db->Insert($data,"denied_requests");
                                
                                //send error response
                                return json_encode(array('request_initiated'=>'no',
                                    'status'=>400, 
                                    'errors' => array(
                                        'title'=>'Customer Block',
                                        'message'=>'Dear customer, your number has been blocked because you have exceeded the maximum request attempts permissible by this app. Kindly call 0237583931 for assistance. Thank you.'
                                        )
                                    )
                                        );

                            }                                 

                            //get request that have come in the last 15min
                            //$max_requests = Requst::where('customer_id',$customer->id)->where('DATE(created_at)',$todays_date);
                            $max_requests = $db->SelectValue("SELECT COUNT(*) AS requests FROM requsts WHERE customer_id=$customer->id AND is_paid=0",'requests');

                            if($max_requests>=5) {
                                
                                $data['type_id'] = 2;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'maximum request exceeded';
                                $db->Insert($data,"denied_requests");
                                
                                $add_block = array(
                                    'blocked_customer'=>$customer->id,
                                    'blocked_contact'=>$customer->phone,
                                    'created_at'=>date('Y-m-d H:i:s')
                                    );

                                $db->Insert($add_block,"blocked_lists");
                                //send error response
                                return json_encode(array('request_initiated'=>'no',
                                     'status'=>400, 
                                     'errors' => array(
                                         'title'=>'Customer Block',
                                         'message'=>'Dear customer, your number has been blocked because you have exceeded the maximum request attempts permissible by this app. Kindly call 0237583931 for assistance. Thank you.'
                                         )
                                    )
                                        );
                            }
                            
                        }

			$validator = Validator::make($data, Requst::$initiateRules);

			if ($validator->fails())
			{
                            $data['type_id'] = 2;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'invalid fields';
                            $db->Insert($data,"denied_requests");
                            
				return json_encode(
                                        array(
                                            'request_initiated'=>'no',
                                            'ecg_status'=>$ecg,
                                            'status'=>400,
                                            'errors'=> array(
                                                'title'=>'Wrong Values',
                                                'message'=>$validator->messages()
                                        )
                                            )
                                        );
			}
                        
                        $filter_key = trim($data['location']);
                        //check if location is valid smart meter location
                        $isValidLocation = $db->SelectValue("SELECT count(*) as found from locations where description RLIKE '$filter_key'", 'found');
                                
                        if($isValidLocation==0) {
                            
                            $data['type_id'] = 2;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'unsupported location';
                            $db->Insert($data,"denied_requests");
                            
                            return json_encode(array('request_initiated'=>'no',                                
                                'status'=>400,
                                'errors' => array(
                                                'title'=>'Unsupported Location',
                                                'message'=>'Sorry, your current location is not in our catchment areas.'
                                        )
                                ));
                        }
                        
                        //return status 400 if ecg is off
                        if($ecg == "0") {
                            
                            $data['type_id'] = 2;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'system offline';
                            $db->Insert($data,"denied_requests");
                            
                             return json_encode(array('request_initiated'=>'no',
                                'ecg_status'=>$ecg,
                                'status'=>400,
                                'errors' => array(
                                                'title'=>'System Unavailable ',
                                                'message'=>'Sorry, the system is currently unavailable. Please try again later.'
                                        ) 
                                 )
                                     );
                        }
                        
                        $data['amount'] = 1.0;                        
			$data['request_id'] = Requst::createID();
			$data['customer_id'] = $customer->id;
			$data['type_id'] = 2; //[1=purchase request, 2=balance request,3=consumption balance]
                        
			$requst = Requst::create($data);
                        
                        //generate payment invoice
                        $invoice = MomoTransation::MazzumaBalanceInvoice($requst);
                        
                        //check if error
                        if (strlen($invoice['error'])>0) {
                            
                            return json_encode(array(
                                'request_initiated'=>'no',
                                'status'=>400,
                                'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$invoice['error']
                                        )
                                    )
                                    );
                        
                            
                        } else { //invoice was successfull
                             
                            $respose_data = json_decode($invoice['data']);
                            
//                            echo print_r($respose_data);
//                            exit();
//                            
                            if($respose_data->status=='Error') {
                                
                                return json_encode(array(
                                    'request_initiated'=>'no',
                                    'status'=>400,
                                    'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$respose_data->data
                                        )
                                        ));
                            }
                            
                            return Response::json(array(
                                'request_initiated'=>'yes',
                                'ecg_status'=>$ecg,
                                'status'=>200,
                                'request'=> array(
                                    'amount'=>$requst['amount'],
                                    'total'=>$requst['amount'],
                                    'location'=>$requst['location'],
                                    'request_id'=>$requst['request_id']),
                                'invoice'=>array(
                                    'checkout_url'=>$respose_data->data->checkoutUrl,
                                    'cancel_url'=>$invoice['cancelurl'],
                                    'return_url'=>$invoice['returnurl'],
                                    'status_url'=>$invoice['statusurl'])
                            ));
                        }
		}
		return json_encode(array(
                    'request_initiated'=>'no',
                    'ecg_status'=>$ecg,
                    'status'=>400,
                    'errors' => array(
                                'title'=>'Wrong Token',
                                'message'=>'Customer token is invalid.'
                                )
                    )
                        );
	}
        
        public function apiV2PostCheckBalance($token){
            //check ecg status            
            $ecg = EcgStatus::currentStatus();
            
            //
		$temp = Customer::where('customer_token',$token);
                
                $data = Input::all();
               $data['created_at'] = date('Y-m-d H:i:s');
               $data['updated_at'] = date('Y-m-d H:i:s');
                
		if(count($temp->get())>0){
                    
			$customer = $temp->first();
                        
                         $data['customer_id'] = $customer->id;
                         //raw mysql code
                           $db = new DBConnector();  
                           
                        if($customer->block_exception!=1) {
                            
                            $is_blocked = BlockedList::customerBlockedStatus($customer->id);
                        
                            if($is_blocked == TRUE) {
                                
                                $data['type_id'] = 2;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'customer blocked';
                                $db->Insert($data,"denied_requests");
                                
                                //send error response
                                return json_encode(array('request_initiated'=>'no',
                                    'status'=>400, 
                                    'errors' => array(
                                        'title'=>'Customer Block',
                                        'message'=>'Dear customer, your number has been blocked because you have exceeded the maximum request attempts permissible by this app. Kindly call 0237583931 for assistance. Thank you.'
                                        )
                                    )
                                        );

                            }                                 

                            //get request that have come in the last 15min
                            //$max_requests = Requst::where('customer_id',$customer->id)->where('DATE(created_at)',$todays_date);
                            $max_requests = $db->SelectValue("SELECT COUNT(*) AS requests FROM requsts WHERE customer_id=$customer->id AND is_paid=0",'requests');

                            if($max_requests>=5) {
                                
                                $data['type_id'] = 2;
                                $data['customer_id'] = $customer->id;
                                $data['reject_reason'] = 'maximum request exceeded';
                                $db->Insert($data,"denied_requests");
                                
                                $add_block = array(
                                    'blocked_customer'=>$customer->id,
                                    'blocked_contact'=>$customer->phone,
                                    'created_at'=>date('Y-m-d H:i:s')
                                    );

                                $db->Insert($add_block,"blocked_lists");
                                //send error response
                                return json_encode(array('request_initiated'=>'no',
                                     'status'=>400, 
                                     'errors' => array(
                                         'title'=>'Customer Block',
                                         'message'=>'Dear customer, your number has been blocked because you have exceeded the maximum request attempts permissible by this app. Kindly call 0237583931 for assistance. Thank you.'
                                         )
                                    )
                                        );
                            }
                            
                        }

			$validator = Validator::make($data, Requst::$initiateRules);

			if ($validator->fails())
			{
                            $data['type_id'] = 2;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'invalid fields';
                            $db->Insert($data,"denied_requests");
                            
				return json_encode(
                                        array(
                                            'request_initiated'=>'no',
                                            'ecg_status'=>$ecg,
                                            'status'=>400,
                                            'errors'=> array(
                                                'title'=>'Wrong Values',
                                                'message'=>$validator->messages()
                                        )
                                            )
                                        );
			}
                        
                        $filter_key = trim($data['location']);
                        //check if location is valid smart meter location
                        $isValidLocation = $db->SelectValue("SELECT count(*) as found from locations where description RLIKE '$filter_key'", 'found');
                                
                        if($isValidLocation==0) {
                            
                            $data['type_id'] = 2;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'unsupported location';
                            $db->Insert($data,"denied_requests");
                            
                            return json_encode(array('request_initiated'=>'no',                                
                                'status'=>400,
                                'errors' => array(
                                                'title'=>'Unsupported Location',
                                                'message'=>'Sorry, your current location is not in our catchment areas.'
                                        )
                                ));
                        }
                        
                        //return status 400 if ecg is off
                        if($ecg == "0") {
                            
                            $data['type_id'] = 2;
                            $data['customer_id'] = $customer->id;
                            $data['reject_reason'] = 'system offline';
                            $db->Insert($data,"denied_requests");
                            
                             return json_encode(array('request_initiated'=>'no',
                                'ecg_status'=>$ecg,
                                'status'=>400,
                                'errors' => array(
                                                'title'=>'System Unavailable ',
                                                'message'=>'Sorry, the system is currently unavailable. Please try again later.'
                                        ) 
                                 )
                                     );
                        }
                        
                        $data['amount'] = 1.0;                        
			$data['request_id'] = Requst::createID();
			$data['customer_id'] = $customer->id;
			$data['type_id'] = 2; //[1=purchase request, 2=balance request,3=consumption balance]
                        
			$requst = Requst::create($data);
                        
                        //generate payment invoice
                        $invoice = MomoTransation::MazzumaBalanceInvoice($requst);
                        
                        //check if error
                        if (strlen($invoice['error'])>0) {
                            
                            return json_encode(array(
                                'request_initiated'=>'no',
                                'status'=>400,
                                'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$invoice['error']
                                        )
                                    )
                                    );
                        
                            
                        } else { //invoice was successfull
                             
                            $respose_data = json_decode($invoice['data']);
                            
//                            echo print_r($respose_data);
//                            exit();
//                            
                            if($respose_data->status=='Error') {
                                
                                return json_encode(array(
                                    'request_initiated'=>'no',
                                    'status'=>400,
                                    'errors'=>array(
                                                'title'=>'System Unavailable',
                                                'message'=>$respose_data->data
                                        )
                                        ));
                            }
                            
                            return Response::json(array(
                                'request_initiated'=>'yes',
                                'ecg_status'=>$ecg,
                                'status'=>200,
                                'request'=> array(
                                    'amount'=>$requst['amount'],
                                    'total'=>$requst['amount'],
                                    'location'=>$requst['location'],
                                    'request_id'=>$requst['request_id']),
                                'invoice'=>array(
                                    'checkout_url'=>$respose_data->data->checkoutUrl,
                                    'cancel_url'=>$invoice['cancelurl'],
                                    'return_url'=>$invoice['returnurl'],
                                    'status_url'=>$invoice['statusurl'])
                            ));
                        }
		}
		return json_encode(array(
                    'request_initiated'=>'no',
                    'ecg_status'=>$ecg,
                    'status'=>400,
                    'errors' => array(
                                'title'=>'Wrong Token',
                                'message'=>'Customer token is invalid.'
                                )
                    )
                        );
	}
        
        
        public function addAsPaid($id)
	{
		$request = Requst::where('id',$id)->first();
                                        
                if($request != null) {
                    
                    $trans = $this->AddMPayDebitTransaction($request);
                    
                    $db = new DBConnector();
                    $update = array('is_paid'=>1,'is_rejected'=>0,'paid_at'=>date('Y-m-d H:i:s'));
                    $where = array('id'=>$id);                    
                   
                    $db->Update($update, "requsts", $where);
                }
                

//                $request->is_paid =1;
//                $request->is_rejected =0;
//                $request->paid_at=date('Y-m-d H:i:s');
//                
//                $request->save();
                
			//return View::make('transactions.add_as_sale', compact('transaction'));
		return Redirect::back();
                //return $r;
	}
        
        public function AddMPayDebitTransaction($request){
            
		$data = array();
                
                $origgin_charge = MomoTransation::getOrigginFee(doubleval(str_replace(',', '', $request->amount)));
                
                $api_charges = doubleval(str_replace(',', '', $request->amount))+$origgin_charge <= 50.00 ? 0.5: 0.015*(doubleval(str_replace(',', '', $request->amount))+$origgin_charge);
                
                $token = AccountVerification::NumericToken(8);
                
                $data['requst_id'] = $request->id;
		$data['ecg_amount'] = $request->type_id == 1 ?doubleval(str_replace(',', '', $request->amount)):0.00;
		$data['origgin_charge'] = $request->type_id == 1 ?$origgin_charge:1.00;
                
		$data['amount'] = $request->type_id == 1 ? doubleval(str_replace(',', '', $request->amount)) + $origgin_charge:1.00;
		$data['charges'] = $api_charges;
		$data['amount_after_charges'] = $request->type_id == 1 ? doubleval(str_replace(',', '', $request->amount)) + $origgin_charge:1.00;
		$data['transaction_id'] = $token;
		$data['response_code'] = '0000'; //pending	
		$data['client_refrence'] = $token;
		//$data['external_transaction_id'] = $temp_data['Data']['SalesInvoiceId'];
                $data['pay_number'] = $request->customer->phone;
                $data['payment_type'] = 3;
                $data['network'] = "mtn";
                $data['is_paid'] = 1;
                $data['paid_at'] = date('Y-m-d H:i:s');
                
		$transaction = MomoTransation::create($data);

//                $db = new DBConnector();
//                $transaction = $db->Insert($data, 'momo_transations');
         

		return $transaction;
		
	}
         
}
