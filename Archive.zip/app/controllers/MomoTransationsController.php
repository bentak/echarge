<?php

include_once 'dbconnect.php';

class MomoTransationsController extends \BaseController {

	public function callback()
	{
		
		$temp_data = Input::all();
		$data = array();
		$data['amount'] = $temp_data['Data']['Amount'];
		$data['charges'] = $temp_data['Data']['Charges'];
		$data['amount_after_charges'] = $temp_data['Data']['AmountAfterCharges'];
		$data['transaction_id'] = $temp_data['Data']['TransactionId'];
		$data['response_code'] = $temp_data['ResponseCode'];
		//$data['description'] = $temp_data['Data']['AmountAfterCharges'];
		$data['client_refrence'] = $temp_data['Data']['ClientReference'];
		$data['external_transaction_id'] = $temp_data['Data']['ExternalTransactionId'];
                $data['pay_number'] = $temp_data['Data']['MobileNumber'];
                $data['payment_type'] = 1;
                

		$requst = Requst::where('request_id',$temp_data['Data']['ClientReference'])->first();
		$data['requst_id'] = $requst->id;
		$data['ecg_amount'] = $requst->amount;
		$data['origgin_charge'] = MomoTransation::getOrigginFee($requst->amount);
                
		//$transaction = MomoTransation::create($data);

                $db = new DBConnector();
                $transaction = $db->Insert($data, 'momo_transations');
                
		if($data['response_code'] == '0000'){
			$requst->is_paid = 1;
			$requst->paid_at = date('Y-m-d H:i:s');
		}
		$requst->save();

		return $transaction;		
	}
        
	public function CheckoutCallback()
	{
		$temp_data = Input::all();
		$data = array();
		$data['amount'] = $temp_data['Data']['Amount'];
		$data['charges'] = 0.0;
		$data['amount_after_charges'] = $temp_data['Data']['Amount'];
		$data['transaction_id'] = $temp_data['Data']['CheckoutId'];
		$data['response_code'] = $temp_data['ResponseCode'];		
		$data['client_refrence'] = $temp_data['Data']['ClientReference'];
		$data['external_transaction_id'] = $temp_data['Data']['SalesInvoiceId'];
                $data['pay_number'] = $temp_data['Data']['CustomerPhoneNumber'];
                $data['payment_type'] = 1;
                
                
		$requst = Requst::where('request_id',$temp_data['Data']['ClientReference'])->first();
                
		$data['requst_id'] = $requst->id;
		$data['ecg_amount'] = $requst->amount;
		$data['origgin_charge'] = MomoTransation::getOrigginFee($requst->amount);
                
//		$transaction = MomoTransation::create($data);

                $db = new DBConnector();
                $transaction = $db->Insert($data, 'momo_transations');
                
                
		if($data['response_code'] == '0000'){
			$requst->is_paid = 1;
			$requst->paid_at = date('Y-m-d H:i:s');
		}
		$requst->save();

		return $transaction;
		
	}
        
	public function MyGHPayCallback()
	{
            
            
		$temp_data = Input::all();
		$data = array();
                
                $requst = Requst::where('request_id',$temp_data['clientref'])->first();
                $origgin_charge = MomoTransation::getOrigginFee($requst->amount);
                
                $data['requst_id'] = $requst->id;
		$data['ecg_amount'] = $requst->amount;
		$data['origgin_charge'] = $origgin_charge;
                
		$data['amount'] = $requst->amount + $origgin_charge;
		$data['charges'] = 0.0;
		$data['amount_after_charges'] = $requst->amount + $origgin_charge;
		$data['transaction_id'] = $temp_data['refCode'];
		$data['response_code'] = $temp_data['statusCode']==1?'0000':'0001';		
		$data['client_refrence'] = $temp_data['ClientReference'];
		//$data['external_transaction_id'] = $temp_data['Data']['SalesInvoiceId'];
                $data['pay_number'] = ['paymentMode'];
                $data['payment_type'] = 2;
                
		
                
//		$transaction = MomoTransation::create($data);

                $db = new DBConnector();
                $transaction = $db->Insert($data, 'momo_transations');
                
                
		if($data['response_code'] == '0000'){
			$requst->is_paid = 1;
			$requst->paid_at = date('Y-m-d H:i:s');
		}
		$requst->save();

		return $transaction;
		
	}
	public function MyGHPayBalanceCallback()
	{
            
            
		$temp_data = Input::all();
		$data = array();
                
                $requst = Requst::where('request_id',$temp_data['clientref'])->first();
                $origgin_charge = 1.0;
                
                $data['requst_id'] = $requst->id;
		$data['ecg_amount'] = 0.0;
		$data['origgin_charge'] = $origgin_charge;
                
		$data['amount'] =  $origgin_charge;
		$data['charges'] = 0.0;
		$data['amount_after_charges'] = $origgin_charge;
		$data['transaction_id'] = $temp_data['refCode'];
		$data['response_code'] = $temp_data['statusCode']==1?'0000':'0001';
		$data['client_refrence'] = $temp_data['ClientReference'];
		//$data['external_transaction_id'] = $temp_data['Data']['SalesInvoiceId'];
                $data['pay_number'] = ['paymentMode'];
                $data['payment_type'] = 2;
                
		
                
//		$transaction = MomoTransation::create($data);

                $db = new DBConnector();
                $transaction = $db->Insert($data, 'momo_transations');
                
                
		if($data['response_code'] == '0000'){
			$requst->is_paid = 1;
			$requst->paid_at = date('Y-m-d H:i:s');
		}
		$requst->save();

		return $transaction;
		
	}
        
	public function BalanceCheckoutCallback()
	{
		$temp_data = Input::all();
		$data = array();
		$data['amount'] = 1.0;
		$data['charges'] = 0.0;
		$data['amount_after_charges'] = $temp_data['Data']['Amount'];
		$data['transaction_id'] = $temp_data['Data']['CheckoutId'];
		$data['response_code'] = $temp_data['ResponseCode'];		
		$data['client_refrence'] = $temp_data['Data']['ClientReference'];
		$data['external_transaction_id'] = $temp_data['Data']['SalesInvoiceId'];
                $data['pay_number'] = $temp_data['Data']['CustomerPhoneNumber'];
                $data['payment_type'] = 1;
                
		$requst = Requst::where('request_id',$temp_data['Data']['ClientReference'])->first();
                
		$data['requst_id'] = $requst->id;
		$data['ecg_amount'] = 0.0;
		$data['origgin_charge'] = $temp_data['Data']['Amount'];
                
                
                $db = new DBConnector();
                $transaction = $db->Insert($data, 'momo_transations');
                
		//$transaction = MomoTransation::create($data);

		if($data['response_code'] == '0000'){
			$requst->is_paid = 1;
			$requst->paid_at = date('Y-m-d H:i:s');
		}
		$requst->save();

		return $transaction;
		
	}
        
        public function MazzumaCallback($request, $response)
	{
		$data = array();                
                
                $origgin_charge = MomoTransation::getOrigginFee($request->amount);
                
                $data['requst_id'] = $request->id;
		$data['ecg_amount'] = $request->amount;
		$data['origgin_charge'] = $origgin_charge;
                
		$data['amount'] = $request->amount + $origgin_charge;
		$data['charges'] = 0.0;
		$data['amount_after_charges'] = $request->amount + $origgin_charge;
		$data['transaction_id'] = $response->id ? $response->id:$response->code;
		$data['response_code'] = '0000';		
		$data['client_refrence'] = $request->request_id;
		//$data['external_transaction_id'] = $temp_data['Data']['SalesInvoiceId'];
                $data['pay_number'] = Input::get('mm_number');
                $data['payment_type'] = 2;
                $data['network'] = Input::get('mm_network');
		
                
		$transaction = MomoTransation::create($data);

//                $db = new DBConnector();
//                $transaction = $db->Insert($data, 'momo_transations');
                
                
		if($data['response_code'] == '0000'){
			$request->is_paid = 1;
			$request->paid_at = date('Y-m-d H:i:s');
		}
		$request->save();

		return $transaction;
		
	}
	public function MazzumaBalanceCallback($request, $response)
	{
		$data = array();
               
                $origgin_charge = 1.0;
                
                $data['requst_id'] = $request->id;
		$data['ecg_amount'] = 0.0;
		$data['origgin_charge'] = $origgin_charge;
                
		$data['amount'] =  $origgin_charge;
		$data['charges'] = 0.0;
		$data['amount_after_charges'] = $origgin_charge;
		$data['transaction_id'] = $response->id ? $response->id:$response->code;
		$data['response_code'] = '0000';		
		$data['client_refrence'] = $request->request_id;
		//$data['external_transaction_id'] = $temp_data['Data']['SalesInvoiceId'];
                $data['pay_number'] = Input::get('mm_number');
                $data['payment_type'] = 2;
                $data['network'] = Input::get('mm_network');
                
		
                
		$transaction = MomoTransation::create($data);

//                $db = new DBConnector();
//                $transaction = $db->Insert($data, 'momo_transations');
                
                
		if($data['response_code'] == '0000'){
			$request->is_paid = 1;
			$request->paid_at = date('Y-m-d H:i:s');
		}
		$request->save();

		return $transaction;
		
	}
        
        
               
        public function cancelCallback($referenceid) {            
            
           return json_encode(array('payment_status'=>'error','status'=>400, 'message' => 'Payment was unsuccessful.' ));

        }
        public function returnCallback($referenceid) {
            
                return json_encode(array('payment_status'=>'pending','status'=>200, 'message' => 'Payment successfully made.' ));

        }
        
        public function MyGHPayPrepaid($referenceid) {
            
            $request = Requst::where('request_id',$referenceid)->first();
            
            $data['clientref'] = $request->request_id;
            
            $origgin_charge = MomoTransation::getOrigginFee($request->amount);
            
            $data['amount'] = $origgin_charge + $request->amount;   
            
            $data['itemname'] = 'Prepaid Credit';
            
            $data['returnurl'] = MomoPayment::$MyGHPayCallback_url;           
            
            
            return View::make('momo_transations.pay',$data);
        }       
        
        
        public function MyGHPayBalance($referenceid) {
            
            $request = Requst::where('request_id',$referenceid)->first();
            
            $data['clientref'] = $request->request_id;
            
            $data['amount'] = 1.0;           
            
            $data['itemname'] = 'Credit Balance'; 
            
            $data['returnurl'] = MomoPayment::$MyGHPayBalancecallback_url;
            
            return View::make('momo_transations.pay',$data);
        }
        
        
        
        
        public function CompleteMazzumaPayment($referenceid) {
            
            $data = Input::all();
            
            
            $validator = Validator::make($data, MomoTransation::$payment_rules);
            
            if ($validator->fails())
            {
                return json_encode(array('success'=>'no','status'=>400,'errors'=>$validator->messages()));
            }
            
            $request = Requst::where('request_id',$referenceid)->first();
            
            if($request != NULL) {
                
                
                $pay_exists = $this->PaymentExists($referenceid);
                    
                if($pay_exists['exists'] == TRUE && $pay_exists['status']=='Successful') {

                        $this->MazzumaCallback($request,json_decode($pay_exists['message']));

                        return Response::json(array(
                         'success'=>'yes',                    
                         'status'=>200,
                         'message'=> 'Payment successful.'
                     ));

                    } else if($pay_exists['exists'] == TRUE && $pay_exists['status']=='Pending') {

                        return json_encode(array(
                             'success'=>'no',
                             'status'=>300,
                             'message'=> 'Payment pending.'
                                 ));
                    }
                
              $origgin_fee = MomoTransation::getOrigginFee($request->amount);
            
              $option= $this->getNetworkOption();              
              
              
              $invoice = array (
                  'sender'=> $data['mm_number'],
                  'network'=>$data['mm_network'],
                  'option'=>$option,
                  'price'=>$request->amount + $origgin_fee,
                  'id'=>$referenceid
                  );
              
              
              //echo 'initiating payment @ '.date('H:i:s');
             
            $payment_response = MomoPayment::processMazzumaPayment($invoice);           
           
            
            if(strlen($payment_response['error'])>0) {
                return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=>$payment_response['error']
                                    )
                                    );
            } else if(is_object($payment_response['data']) || strlen($payment_response['data'])>0){
                
                //echo 'response received @ '.date('H:i:s').$payment_response['data'];
                
               return $this->CheckAndSendResponse($payment_response, $request, 'MazzumaCallback');
                
            } else {
                
                //echo 'empty response received. @ '.date('H:i:s').' checking transaction status...\n. ';
                
                $pay_status = $this->CheckPaymentStatus($request->request_id);
                    
                   if($pay_status['status'] == TRUE) {
                       
                       $this->MazzumaCallback($request, json_decode($pay_status['message']));
                       
                       return Response::json(array(
                        'success'=>'yes',                    
                        'status'=>200,
                        'message'=> 'Payment successful.'
                    ));
                       
                   } else {
                       
                      return  json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=> 'Payment Unapproved.'
                                ));
                   } 
            }
              
              
            } else {
                
                return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=> 'Invalid request token.'
                                    ));
                
            }
            
             
                
        }        
        
        public function CompleteBalanceMazzumaPayment($referenceid) {           
            
            
            $data = Input::all();
            
            $validator = Validator::make($data, MomoTransation::$payment_rules);
            
            if ($validator->fails())
            {
                return json_encode(array('success'=>'no','status'=>400,'message'=>$validator->messages()));
            }
            
            $request = Requst::where('request_id',$referenceid)->first();
            
            if($request != NULL) {
                
                
               $pay_exists = $this->PaymentExists($referenceid);
                    
                if($pay_exists['exists'] == TRUE && $pay_exists['status']=='Successful') {
                        
                        $this->MazzumaBalanceCallback($request,json_decode($pay_exists['message']));

                        return Response::json(array(
                         'success'=>'yes',                    
                         'status'=>200,
                         'message'=> 'Payment successful.'
                     ));

                    } else if($pay_exists['exists'] == TRUE && $pay_exists['status']=='Pending') {

                        return json_encode(array(
                             'success'=>'no',
                             'status'=>300,
                             'message'=> 'Payment pending.'
                                 ));
                    }
                
              //$origgin_fee = MomoTransation::getOrigginFee($request->amount);
            
              $option= $this->getNetworkOption();             
             
              
              $invoice = array (
                  'sender'=> $data['mm_number'],
                  'network'=>$data['mm_network'],
                  'option'=>$option,
                  'price'=>1.0,
                  'id'=>$referenceid
                  );
              
              //echo 'initiating payment @ '.date('H:i:s');
            
                $payment_response = MomoPayment::processMazzumaPayment($invoice);

                if(strlen($payment_response['error'])>0) {
                    return json_encode(array(
                                    'success'=>'no',
                                    'status'=>400,
                                    'message'=>$payment_response['error']
                                        )
                                        );
                } else if(is_object($payment_response['data']) || strlen($payment_response['data'])>0){

                   //echo 'response received @ '.date('H:i:s').$payment_response['data'];

                    return $this->CheckAndSendResponse($payment_response, $request, 'MazzumaBalanceCallback');


                } else {

                    //echo 'empty response received @ '.date('H:i:s').' checking transaction status...\n. ';

                    $pay_status = $this->CheckPaymentStatus($request->request_id);
                    
                   if($pay_status['status'] == TRUE) {

                           $this->MazzumaBalanceCallback($request,json_decode($pay_status['message']));

                           return Response::json(array(
                            'success'=>'yes',                    
                            'status'=>200,
                            'message'=> 'Payment successful.'
                        ));

                       } else {

                           return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=> 'Payment Unapproved.'
                                    ));
                       }                

                }
                
            } else {
                
                return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=> 'Invalid request token.'
                                    ));
                
            }
            
                        
                
        }        
        
        public function MazzumaPaymentCheckout($referenceid) {
            
            $data = Input::all();
            
            
            $validator = Validator::make($data, MomoTransation::$payment_rules);
            
            if ($validator->fails())
            {
                return json_encode(array('success'=>'no','status'=>400,'errors'=>$validator->messages()));
            }
            
            $request = Requst::where('request_id',$referenceid)->first();
            
            if($request != NULL) {
                
                
                $pay_exists = $this->PaymentExists($referenceid);
                    
                if($pay_exists['exists'] == TRUE && $pay_exists['status']=='Successful') {

                        $request->type_id == 1?
                                $this->MazzumaCallback($request,json_decode($pay_exists['message'])):
                            $this->MazzumaBalanceCallback($request,json_decode($pay_exists['message']));                       

                        return Response::json(array(
                         'success'=>'yes',                    
                         'status'=>200,
                         'message'=> 'Payment successful.'
                     ));

                    } else if($pay_exists['exists'] == TRUE && $pay_exists['status']=='Pending') {

                        return json_encode(array(
                             'success'=>'no',
                             'status'=>300,
                             'message'=> 'Payment pending.'
                                 ));
                    }
                
              $origgin_fee = MomoTransation::getOrigginFee($request->amount);
            
              $option= $this->getNetworkOption();              
              
              
              $invoice = $request->type_id==1? array (
                  'sender'=> $data['mm_number'],
                  'network'=>$data['mm_network'],
                  'option'=>$option,
                  'price'=>$request->amount + $origgin_fee,
                  'id'=>$referenceid
                  ) : 
                  array (
                  'sender'=> $data['mm_number'],
                  'network'=>$data['mm_network'],
                  'option'=>$option,
                  'price'=>1.0,
                  'id'=>$referenceid
                  );
              
              
              //echo 'initiating payment @ '.date('H:i:s');
             
            $payment_response = MomoPayment::processMazzumaPayment($invoice);
            
            //return json_encode($payment_response);            
            
            if(strlen($payment_response['error'])>0) {
                return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=>$payment_response['error']
                                    )
                                    );
            } else if(is_object($payment_response['data']) || strlen($payment_response['data'])>0){
                
                                
                $response_data = json_decode($payment_response['data']);

                if(is_object($response_data) && !is_null($response_data)) {
                    
                    if($response_data->code!=1) {

                        return json_encode(array(
                            'success'=>'no',
                            'status'=>300,
                            'message'=>'Payment failed.'
                                ));
                    }
                    
                    $pay_exists = $this->CheckPaymentStatusWithoutLoop($request->request_id);
                    
                    if($pay_exists['status'] == TRUE) {

                        $callback = $request->type_id == 1?'MazzumaCallback':'MazzumaBalanceCallback';

                        call_user_func_array(array($this,"$callback"), array($request,$response_data));

                         return Response::json(array(
                          'success'=>'yes',                    
                          'status'=>200,
                          'message'=> 'Payment successful.'
                      ));

                    } else {

                        return json_encode(array(
                             'success'=>'pending',
                             'status'=>300,
                             'message'=> 'Payment pending.'
                                 ));
                    }                    
                    
                    
                } else {
                    
                    return json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Payment failed.'
                                ));
                }
                
            } else {
                
                return Response::json(array(
                         'success'=>'pending',                    
                         'status'=>300,
                         'message'=> 'payment pending'
                     )); 
            }
              
              
            } else {
                
                return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=> 'Invalid request token.'
                                    ));
                
            }
            
             
                
        }
        
        
        private function CheckAndSendResponse($payment_response,$request) {
            
             $response_data = json_decode($payment_response['data']);

                if(is_object($response_data) && !is_null($response_data)) {
                    
                    if($response_data->code!=1) {

                    return json_encode(array(
                        'success'=>'no',
                        'status'=>400,
                        'message'=>'Payment failed.'
                            ));
                    }
                    
                    $pay_status = $this->CheckPaymentStatus($request->request_id);
                    
                   if($pay_status['status'] == TRUE) {
                       
                       $callback = $request->type_id == 1?'MazzumaCallback':'MazzumaBalanceCallback';
                       
                       call_user_func_array(array($this,"$callback"), array($request,$response_data));
                       
                        return Response::json(array(
                         'success'=>'yes',                    
                         'status'=>200,
                         'message'=> 'Payment successful.'
                     ));
                       
                   } else {
                       
                       return json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=> 'Payment Unapproved.'
                                ));
                   }
                
                     
                
                } else {
                
                    return json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=> 'Payment failed.'
                                ));
                }  
        }
        
        
        private function CheckAndSendResponseWithoutLoop($payment_response,$request) {
            
             $response_data = json_decode($payment_response['data']);

                if(is_object($response_data) && !is_null($response_data)) {
                    
                    if($response_data->code!=1) {

                    return json_encode(array(
                        'success'=>'no',
                        'status'=>400,
                        'message'=>'Payment failed.'
                            ));
                    }
                    
                    $pay_status = $this->CheckPaymentStatusWithoutLoop($request->request_id);
                    
                   if($pay_status['status'] == TRUE) {
                       
                       $callback = $request->type_id == 1?'MazzumaCallback':'MazzumaBalanceCallback';
                       
                       call_user_func_array(array($this,"$callback"), array($request,$response_data));
                       
                        return Response::json(array(
                         'success'=>'yes',                    
                         'status'=>200,
                         'message'=> 'Payment successful.'
                     ));
                       
                   } else {
                       
                       return json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=> 'Payment Unapproved.'
                                ));
                   }
                
                     
                
                } else {
                
                    return json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=> 'Payment failed.'
                                ));
                }  
        }
        
        
        private function CheckPaymentStatus($referenceid) {
            
            //check if payment was successful    
                    $timeout = 0;
                    // check if payment is successfull
                    $paid_response = MomoPayment::CheckMazzumaPaymentStatus($referenceid);

                    $paid = json_decode($paid_response['data']);

                    while ($paid->status!='Successful') {

                        if($timeout >= 6){ // payment wasn't successful    

                            return array('status'=>FALSE,'message'=>$paid_response['data']);                            
                           
                        }

                        sleep(10);
                        
                        $paid_response = MomoPayment::CheckMazzumaPaymentStatus($referenceid);

                        $paid = json_decode($paid_response['data']);

                        $timeout += 1;
                    }

                    return array('status'=>TRUE,'message'=>$paid_response['data']);
        }
        
        
        private function CheckPaymentStatusWithoutLoop($referenceid) {
                  
            // check if payment is successfull
            $paid_response = MomoPayment::CheckMazzumaPaymentStatus($referenceid);

            $paid = json_decode($paid_response['data']);

           return $paid->status =='Successful'? 
                   array('status'=>TRUE,'message'=>$paid_response['data']):
                   array('status'=>FALSE,'message'=>$paid_response['data']);
                    
        }
        
        public function PaymentExists($referenceid) {
                  
            // check if payment is successfull
            $paid_response = MomoPayment::CheckMazzumaPaymentStatus($referenceid);
            
            if(strlen($paid_response['data'])>0){
                
                $paid = json_decode($paid_response['data']);

                return property_exists($paid, 'id')? 
                        array('exists'=>TRUE,'status'=>$paid->status):
                        array('exists'=>FALSE,'message'=>$paid->message);
                
            }            
                    
        }
        
        private function getNetworkOption() {
            $option = '';
            
            switch (Input::get('mm_network')){
                case 'airtel': 
                    $option = 'ratm';                  
                    break;
                case 'voda': 
                    $option = 'rvtm';                  
                    break;
                case 'tigo': 
                    $option = 'rttm';                  
                    break;
                default :
                    $option = 'rmtm';
                    break;
              }
              
              return $option;
        }

        /**
	 * Display a listing of momotransations
	 *
	 * @return Response
	 */
	public function index()
	{
		$momotransations = MomoTransation::all();

		return View::make('momotransations.index', compact('momotransations'));
	}

	/**
	 * Show the form for creating a new momotransation
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('momotransations.create');
	}

	/**
	 * Store a newly created momotransation in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), MomoTransation::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		MomoTransation::create($data);

		return Redirect::route('momotransations.index');
	}

	/**
	 * Display the specified momotransation.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$momotransation = MomoTransation::findOrFail($id);

		return View::make('momotransations.show', compact('momotransation'));
	}

	/**
	 * Show the form for editing the specified momotransation.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$momotransation = MomoTransation::find($id);

		return View::make('momotransations.edit', compact('momotransation'));
	}

	/**
	 * Update the specified momotransation in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$momotransation = MomoTransation::findOrFail($id);

		$validator = Validator::make($data = Input::all(), MomoTransation::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$momotransation->update($data);

		return Redirect::route('momotransations.index');
	}

	/**
	 * Remove the specified momotransation from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		MomoTransation::destroy($id);

		return Redirect::route('momotransations.index');
	}

        
        public function NsanoPaymentCheckout($referenceid) {
            
            $data = Input::all();
            
            
            $validator = Validator::make($data, MomoTransation::$payment_rules);
            
            if ($validator->fails())
            {
                return json_encode(array('success'=>'no','status'=>400,'errors'=>$validator->messages()));
            }
            
            $request = Requst::where('request_id',$referenceid)->first();
            
            if($request != NULL) {                
                
                $pay_exists = $this->PaymentExists($referenceid);
                    
                if($pay_exists['exists'] == TRUE && $pay_exists['status']=='Successful') {

                        $request->type_id == 1?
                                $this->MazzumaCallback($request,json_decode($pay_exists['message'])):
                            $this->MazzumaBalanceCallback($request,json_decode($pay_exists['message']));                       

                        return Response::json(array(
                         'success'=>'yes',                    
                         'status'=>200,
                         'message'=> 'Payment successful.'
                     ));

                    } else if($pay_exists['exists'] == TRUE && $pay_exists['status']=='Pending') {

                        return json_encode(array(
                             'success'=>'no',
                             'status'=>300,
                             'message'=> 'Payment pending.'
                                 ));
                    }
                
              $origgin_fee = MomoTransation::getOrigginFee($request->amount);
            
              $option= $this->getNetworkOption();              
              
              
              $invoice = $request->type_id==1? array (
                  'sender'=> $data['mm_number'],
                  'network'=>$data['mm_network'],
                  'option'=>$option,
                  'price'=>$request->amount + $origgin_fee,
                  'id'=>$referenceid
                  ) : 
                  array (
                  'sender'=> $data['mm_number'],
                  'network'=>$data['mm_network'],
                  'option'=>$option,
                  'price'=>1.0,
                  'id'=>$referenceid
                  );
              
              
              //echo 'initiating payment @ '.date('H:i:s');
             
            $payment_response = MomoPayment::processMazzumaPayment($invoice);
            
            //return json_encode($payment_response);            
            
            if(strlen($payment_response['error'])>0) {
                return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=>$payment_response['error']
                                    )
                                    );
            } else if(is_object($payment_response['data']) || strlen($payment_response['data'])>0){
                
                                
                $response_data = json_decode($payment_response['data']);

                if(is_object($response_data) && !is_null($response_data)) {
                    
                    if($response_data->code!=1) {

                        return json_encode(array(
                            'success'=>'no',
                            'status'=>300,
                            'message'=>'Payment failed.'
                                ));
                    }
                    
                    $pay_exists = $this->CheckPaymentStatusWithoutLoop($request->request_id);
                    
                    if($pay_exists['status'] == TRUE) {

                        $callback = $request->type_id == 1?'MazzumaCallback':'MazzumaBalanceCallback';

                        call_user_func_array(array($this,"$callback"), array($request,$response_data));

                         return Response::json(array(
                          'success'=>'yes',                    
                          'status'=>200,
                          'message'=> 'Payment successful.'
                      ));

                    } else {

                        return json_encode(array(
                             'success'=>'pending',
                             'status'=>300,
                             'message'=> 'Payment pending.'
                                 ));
                    }                    
                    
                    
                } else {
                    
                    return json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Payment failed.'
                                ));
                }
                
            } else {
                
                return Response::json(array(
                         'success'=>'pending',                    
                         'status'=>300,
                         'message'=> 'payment pending'
                     )); 
            }
              
              
            } else {
                
                return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=> 'Invalid request token.'
                                    ));
                
            }
            
             
                
        }
}
