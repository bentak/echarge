<?php

include_once 'dbconnect.php';

class MazzumaPaymentController extends \BaseController {

    const API_KEY ="5748847d27d70ee34876e85a8ec774085cb594a6";

        public $payment_rules = array(
                     'mm_name' => 'required|min:4',
                     'mm_network' => 'required',
                     'mm_number' => 'required|min:10',
                     'amount' => 'required',
                     'receiver' => 'required|min:10'
             );
        
        private $MazzumaRequestOptions = array(
        'price'=>'',
        'network'=>'',
        'recipient_number'=>'',
        'sender'=>'',
        'option'=>'',
        'apikey'=>'',        
        'orderID'=>''        
        );        
       
        
         public function AddNsanoDebitTransaction($request,$response)
	{
		$data = array();                
                
                $origgin_charge = MomoTransation::getOrigginFee($request->amount);
                
                $data['requst_id'] = $request->id;
		$data['ecg_amount'] = $request->type_id == 1 ?$request->amount:0.00;
		$data['origgin_charge'] = $request->type_id == 1 ?$origgin_charge:1.00;
                
		$data['amount'] = $request->type_id == 1 ? $request->amount + $origgin_charge:1.00;
		$data['charges'] = 0.0;
		$data['amount_after_charges'] = $request->type_id == 1 ? $request->amount + $origgin_charge:1.00;
		$data['transaction_id'] = $response->reference;
		$data['response_code'] = '0003'; //pending	
		$data['client_refrence'] = $response->reference;
		//$data['external_transaction_id'] = $temp_data['Data']['SalesInvoiceId'];
                $data['pay_number'] = Input::get('mm_number');
                $data['payment_type'] = 3;
                $data['network'] = Input::get('mm_network');
		
                
		$transaction = MomoTransation::create($data);

//                $db = new DBConnector();
//                $transaction = $db->Insert($data, 'momo_transations');
         

		return $transaction;
		
	}
         public function NsanoDebitCallback()
	{            
            
		$response_data = Input::all();
                
                $callback_response = file_get_contents('php://input');
                
                $file_date = PHP_EOL."Callback received at: ".date('Y-m-d H:i:s').PHP_EOL."Host : ".(array_key_exists('REMOTE_HOST', $_SERVER)?$_SERVER['REMOTE_HOST']:"").PHP_EOL."Address : ".$_SERVER['REMOTE_ADDR'].PHP_EOL;
                
                $log_file = file_put_contents($_SERVER['DOCUMENT_ROOT']."/Callback_log.txt", $file_date.$callback_response.PHP_EOL , FILE_APPEND | LOCK_EX);
                
                                
                $validator = Validator::make($response_data, MomoTransation::$callback_rules);

		if ($validator->fails())
		{

                    return json_encode(array('code'=>'01','msg'=>$validator->messages()));
		}               
                
                $transaction = MomoTransation::where('client_refrence',$response_data['reference'])->first();
                
                //return var_dump($transaction);
                
                if($transaction == NULL) {
//                    $this->NsanoCallbackResponse['msg'] = "Empty Request";                    
//                    $this->NsanoCallbackResponse['code'] = "01";
//                    $this->NsanoCallbackResponse['metadataID'] = $response_data['reference'];
                   return json_encode(array('code'=>'01','msg'=>'Invalid Reference ID.'));
                   //$this->sendResponse();                     
                 
                }
                
                $request = Requst::where('id',$transaction->requst_id)->first();                
                
		$transaction->response_code = $response_data['code'] == '00'?'0000':'0004';				               
                $transaction->description = $response_data['msg'];
                
		if($response_data['code'] == '00'){
                    
                    $transaction->transaction_id = $response_data['transactionID'];                    
                    
                    $request->is_paid = 1;
                    $request->paid_at = date('Y-m-d H:i:s');
		}
                
		$request->save();
                $transaction->save();
		
                //$this->NsanoCallbackResponse['metadataID'] = $response_data['reference'];
                
                //$this->sendResponse();               
               return json_encode(array('code'=>'00','msg'=>'Successful'));
	}
        
        public function ProccesMazzumaPayment($referenceid) {
            
            //$data = Input::all();            
            
            $input = file_get_contents('php://input');
            
            $data = json_decode($input, TRUE);
            
            $validator = Validator::make($data, $this->payment_rules);
            
            if ($validator->fails())
            {
                return json_encode(array('success'=>'no','status'=>400,'errors'=>$validator->messages()));
            }
          
                $pay_exists = $this->PaymentExists($referenceid);
                    
                if($pay_exists['exists'] == TRUE && $pay_exists['status']=='Successful') {

                       $this->MazzumaCallback(json_decode($pay_exists['message']));                       

                        return Response::json(array(
                         'success'=>'yes',                    
                         'status'=>200,
                         'message'=> 'Payment successful.'
                     ));

                    } else if($pay_exists['exists'] == TRUE && $pay_exists['status']=='Pending') {

                        return json_encode(array(
                             'success'=>'no',
                             'status'=>300,
                             'message'=> 'Payment pending.'
                                 ));
                    }
                
              //$origgin_fee = MomoTransation::getOrigginFee($data['amount']);
            
              $option= $this->getNetworkOption();              
                           
                           
            //$price_with_charges = doubleval($data['amount']) + (0.03*doubleval($data['amount']));
        
            $this->MazzumaRequestOptions['recipient_number'] = $data['receiver'];            
            $this->MazzumaRequestOptions['sender'] = $data['mm_number'];            
            $this->MazzumaRequestOptions['network'] = $data['mm_network'];           
            $this->MazzumaRequestOptions['option'] = $option;            
            $this->MazzumaRequestOptions['price'] = doubleval($data['amount']);
            $this->MazzumaRequestOptions['apikey'] = MazzumaPaymentController::API_KEY;            
            $this->MazzumaRequestOptions['orderID'] = $referenceid;
             
            $payment_response = $this->sendRequest();
            
            //return json_encode($payment_response);            
            
            if(strlen($payment_response['error'])>0) {
                return json_encode(array(
                                'success'=>'no',
                                'status'=>400,
                                'message'=>$payment_response['error']
                                    )
                                    );
            } else if(is_object($payment_response['data']) || strlen($payment_response['data'])>0){
                
                                
                $response_data = json_decode($payment_response['data']);

                if(is_object($response_data) && !is_null($response_data)) {
                    
                    if($response_data->code!=1) {

                        return json_encode(array(
                            'success'=>'no',
                            'status'=>300,
                            'message'=>'Payment failed.'
                                ));
                    }

                    return json_encode(array(
                         'success'=>'pending',
                         'status'=>300,
                         'message'=> 'Payment pending.'
                             ));                   
                    
                } else {
                    
                    return json_encode(array(
                            'success'=>'no',
                            'status'=>400,
                            'message'=>'Payment failed.'
                                ));
                }
                
            } else {
                
                return Response::json(array(
                         'success'=>'pending',                    
                         'status'=>300,
                         'message'=> 'payment pending'
                     )); 
            }
              
              
            
        }
        
        public function PaymentExists($referenceid) {
                  
            // check if payment is successfull
            $paid_response = $this->CheckMazzumaPaymentStatus($referenceid);
            
            if(strlen($paid_response['data'])>0){
                
                $paid = json_decode($paid_response['data']);

                return property_exists($paid, 'id')? 
                        array('exists'=>TRUE,'status'=>$paid->status):
                        array('exists'=>FALSE,'message'=>$paid->message);
                
            }            
                    
        }
        
        public function CheckPaymentStatus($referenceid) {
            
                      
            $paid_response = $this->CheckMazzumaPaymentStatus($referenceid);

            $paid = json_decode($paid_response['data']);
            
            //$pay_status = $this->CheckPaymentStatusWithoutLoop($referenceid);

            return $paid->status =='Successful'? 
                   json_encode(array(
                    'success'=>'yes',                    
                    'status'=>200,
                    'message'=> 'Payment successful.'
                   )):
                   json_encode(array(
                     'success'=>'pending',
                     'status'=>300,
                     'message'=> 'Payment Pending.'
                         ));

        }
        
        
        private function CheckPaymentStatusWithoutLoop($referenceid) {
                  
            // check if payment is successfull
            $paid_response = $this->CheckMazzumaPaymentStatus($referenceid);

            $paid = json_decode($paid_response['data']);

           return $paid->status =='Successful'? 
                   array('status'=>TRUE,'message'=>$paid_response['data']):
                   array('status'=>FALSE,'message'=>$paid_response['data']);
                    
        }
        
        private function CheckMazzumaPaymentStatus($paymentid) {           
            
            
            $request_url = "https://client.teamcyst.com/checktransaction.php?orderID=$paymentid";
       
            $curl = curl_init($request_url);
            
            //curl_setopt( $curl, CURLOPT_POST, true );  
            //curl_setopt( $curl, CURLOPT_POSTFIELDS, json_encode(self::$MazzumaRequestOptions) );  
            curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
            curl_setopt( $curl, CURLOPT_HTTPHEADER, array(                
                'Cache-Control: no-cache',
                'Content-Type: application/json',
              ));

            //disable SSL check CURLOPT_SSL_VERIFYPEER => false
            curl_setopt($curl, CURLOPT_CAINFO, $_SERVER['DOCUMENT_ROOT'] ."/cacert.pem");
            //Execute the request.
            $results = curl_exec($curl);

            $error = curl_error($curl);

            //Close the cURL handle.
            curl_close($curl);

            return array('data'=>$results,'error'=>$error);
        }
       
        private function sendRequest() {                     
            
             $user_agent = $_SERVER['HTTP_USER_AGENT'];
             
            $request_url = "https://client.teamcyst.com/api_call.php";
       
            $curl = curl_init($request_url);
            
            curl_setopt( $curl, CURLOPT_CUSTOMREQUEST, "POST" );  
            curl_setopt( $curl, CURLOPT_POSTFIELDS, json_encode($this->MazzumaRequestOptions) );  
            curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );  
            curl_setopt( $curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
              ));

        //disable SSL check CURLOPT_SSL_VERIFYPEER => false
        //curl_setopt($curl, CURLOPT_CAINFO, $_SERVER['DOCUMENT_ROOT'] ."/cacert.pem");
        //Execute the request.
        $results = curl_exec($curl);
        
        $error = curl_error($curl);

        //Close the cURL handle.
        curl_close($curl);
        
        return array('data'=>$results,'error'=>$error);
    }
    
      
    private function getNetworkOption() {
            $option = '';            
            switch (Input::get('mm_network')){
                case 'airtel': 
                    $option = 'ratm';                  
                    break;
                case 'voda': 
                    $option = 'rvtm';                  
                    break;
                case 'tigo': 
                    $option = 'rttm';                  
                    break;
                default :
                    $option = 'rmtm';
                    break;
              }
              
              return $option;
        }

}
