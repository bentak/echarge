<?php

include_once 'dbconnect.php';
class TransactionsController extends \BaseController {

    
        /**
	 * Show the form for creating a new transaction
	 *
	 * @return Response
	 */
	public function apiPostOrigginCharge($amount)
	{
            $double_amount = doubleval($amount);
            
            if($double_amount<=0.00) {
                return Response::json(array(
                'success'=>'no',
                'status'=>400,
                'errors'=>'wrong value entered'));  
            }
            
            $fee = MomoTransation::getOrigginFee($amount);
            
            return Response::json(array(               
                'success'=>'yes',
                'status'=>200,
                'data'=>array(
                    'amount'=>number_format($double_amount,2,'.',','),
                    'origgin_charge'=>number_format($fee,2,'.',','),
                    'total'=> number_format($double_amount+$fee,2,'.',','))
                )
            ); 
	}
        
        /**
	 * returns the latest transaction
	 *
	 * @return Response
	 */
	public function recent($recentid)
	{       
            $db = new DBConnector();
            
            $query = "SELECT momo_transations.*,meter_code,meter_owner,location,customer_id,requsts.type_id as type_id,payment_name,phone ";
            $query .="FROM momo_transations JOIN requsts ON momo_transations.requst_id=requsts.id ";
            $query .= "JOIN payment_types ON payment_type=payment_id ";
            $query .= "JOIN customers ON customer_id=customers.id ";
            $query .= "WHERE momo_transations.is_sold=0 AND response_code='0000' AND momo_transations.id>$recentid";
            $new = $db->Select($query);
            //$new = MomoTransation::where('is_sold',0)->where('response_code','0000')->where('id','>',$recentid)->get();
                
            return Response::json(array(
                'status'=>'ok',
                'data'=>$new));                
	}
    
	/**
	 * Display a listing of transactions
	 *
	 * @return Response
	 */
	public function index()
	{
		$data['pagetab'] = 'transactions';
		$data['transactions'] = MomoTransation::where('is_sold',0)->where('is_refunded',0)->where('response_code','0000')->orderBy('id','DESC')->get();

		return View::make('transactions.index', $data);
	}

	/**
	 * Show the form for creating a new transaction
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('transactions.create');
	}

	/**
	 * Store a newly created transaction in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), Transaction::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		Transaction::create($data);

		return Redirect::route('transactions.index');
	}

	/**
	 * Display the specified transaction.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$transaction = MomoTransation::findOrFail($id);

		return View::make('momo_transations.show', compact('transaction'));
	}

	/**
	 * Show the form for editing the specified transaction.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$transaction = Transaction::find($id);

		return View::make('transactions.edit', compact('transaction'));
	}

	
	/**
	 * Update the specified transaction in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$transaction = Transaction::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Transaction::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$transaction->update($data);

		return Redirect::route('transactions.index');
	}

	/**
	 * Remove the specified transaction from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Transaction::destroy($id);

		return Redirect::route('transactions.index');
	}

}
