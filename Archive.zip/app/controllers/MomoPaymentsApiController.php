<?php

class MomoPaymentApiController extends \BaseController {
	
	public function hubtelMomoInitiate(){
		$receive_momo = array(
			  'CustomerName'=> 'Customer Name',
			  'CustomerMsisdn'=> '054XXXX',
			  'CustomerEmail'=> 'customer@gmail.com',
			  'Channel'=> 'mtn-gh',
			  'Amount'=> 0.8,
			  'PrimaryCallbackUrl'=> 'http://requestb.in/1minotz1',
			  'SecondaryCallbackUrl'=> 'http://requestb.in/1minotz1',
			  'Description'=> 'T Shirt',
			  'ClientReference'=> '23213',
		);

		$request_url = 'https://api.hubtel.com/v1/merchantaccount/merchants/HMXXXXXXX/receive/mobilemoney';
		$receive_momo_request = json_encode($receive_momo);

		$ch =  curl_init($request_url);  
				curl_setopt( $ch, CURLOPT_POST, true );  
				curl_setopt( $ch, CURLOPT_POSTFIELDS, $receive_momo_request);  
				curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );  
				curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
				    'Authorization: {base64 encoded Auth Key}',
				    'Cache-Control: no-cache',
				    'Content-Type: application/json',
				  ));

		$result = curl_exec($ch); 
		$err = curl_error($ch);
		curl_close($ch);

		if($err){
			echo $err;
		}else{
			echo $result;
		}
	}
}