<?php

class UserTypesController extends \BaseController {

	/**
	 * Display a listing of usertypes
	 *
	 * @return Response
	 */
	public function index()
	{
		$usertypes = Usertype::all();

		return View::make('usertypes.index', compact('usertypes'));
	}

	/**
	 * Show the form for creating a new usertype
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('usertypes.create');
	}

	/**
	 * Store a newly created usertype in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), Usertype::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		Usertype::create($data);

		return Redirect::route('usertypes.index');
	}

	/**
	 * Display the specified usertype.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$usertype = Usertype::findOrFail($id);

		return View::make('usertypes.show', compact('usertype'));
	}

	/**
	 * Show the form for editing the specified usertype.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$usertype = Usertype::find($id);

		return View::make('usertypes.edit', compact('usertype'));
	}

	/**
	 * Update the specified usertype in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$usertype = Usertype::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Usertype::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$usertype->update($data);

		return Redirect::route('usertypes.index');
	}

	/**
	 * Remove the specified usertype from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Usertype::destroy($id);

		return Redirect::route('usertypes.index');
	}

}
