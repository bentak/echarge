<?php

include_once 'dbconnect.php';
class TransactionsController extends \BaseController {

    
        /**
	 * Show the form for creating a new transaction
	 *
	 * @return Response
	 */
	public function apiPostOrigginCharge($amount)
	{
            $double_amount = doubleval($amount);
            
            if($double_amount<=0.00) {
                return Response::json(array(
                'success'=>'no',
                'status'=>400,
                'errors'=>'wrong value entered'));  
            }
            
            $fee = MomoTransation::getOrigginFee($amount);
            
            return Response::json(array(               
                'success'=>'yes',
                'status'=>200,
                'data'=>array(
                    'amount'=>number_format($double_amount,2,'.',','),
                    'origgin_charge'=>number_format($fee,2,'.',','),
                    'total'=> number_format($double_amount+$fee,2,'.',','))
                )
            ); 
	}
        
        /**
	 * returns the latest transaction
	 *
	 * @return Response
	 */
	public function recent($recentid)
	{       
            $db = new DBConnector();
            
            $query = "SELECT momo_transations.*,meter_code,meter_owner,location,customer_id,requsts.type_id as type_id,payment_name,phone ";
            $query .="FROM momo_transations JOIN requsts ON momo_transations.requst_id=requsts.id ";
            $query .= "JOIN payment_types ON payment_type=payment_id ";
            $query .= "JOIN customers ON customer_id=customers.id ";
            $query .= "WHERE momo_transations.is_sold=0 AND response_code='0000' AND momo_transations.id>$recentid";
            $new = $db->Select($query);
            //$new = MomoTransation::where('is_sold',0)->where('response_code','0000')->where('id','>',$recentid)->get();
                
            return Response::json(array(
                'status'=>'ok',
                'data'=>$new));                
	}
    
	/**
	 * Display a listing of transactions
	 *
	 * @return Response
	 */
	public function index()
	{
		$data['pagetab'] = 'transactions';
		$data['transactions'] = MomoTransation::where('is_sold',0)->where('is_refunded',0)->where('response_code','0000')->orderBy('id','DESC')->get();

		return View::make('transactions.index', $data);
	}

	/**
	 * Show the form for creating a new transaction
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('transactions.create');
	}

	/**
	 * Store a newly created transaction in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), Transaction::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		Transaction::create($data);

		return Redirect::route('transactions.index');
	}

	/**
	 * Display the specified transaction.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$transaction = MomoTransation::findOrFail($id);

		return View::make('momo_transations.show', compact('transaction'));
	}

	/**
	 * Show the form for editing the specified transaction.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$transaction = Transaction::find($id);

		return View::make('transactions.edit', compact('transaction'));
	}

	/**
	 * Show the form for adding as sale of the specified transaction.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function addAsSale($id)
	{
		$transaction = MomoTransation::find($id);

		if($transaction->requst && $transaction->is_sold == 0){
                    
                    if($transaction->partner() && strlen($transaction->partner())>0) {
                        $db = new DBConnector();
                        
                        $partner = Partner::find($transaction->partner_obj()->id);
                        $partner->quota_bal = $partner->quota_bal - $transaction->amount;
                        $partner->save();
                        
                        $update = array('is_refunded'=>0,'is_sold'=>1,'sold_at'=>date('Y-m-d H:i:s'));
                        $where = array('id'=>$id);                    
                        $db->Update($update, 'momo_transations', $where);
                        
                        $update1 = array('is_rejected'=>0,'is_sold'=>1,'sold_at'=>date('Y-m-d H:i:s'));
                        $where1 = array('id'=>$transaction->requst->id);                    
                        $db->Update($update1, 'requsts', $where1);
                        
                        
                        
                        
                    } else {
                        if($transaction->network=='mtn'){
                            $db = new DBConnector();                        
                            $update = array('is_refunded'=>0,'is_sold'=>1,'sold_at'=>date('Y-m-d H:i:s'));
                            $where = array('id'=>$id);                    
                            $db->Update($update, 'momo_transations', $where);

                            $update1 = array('is_rejected'=>0,'is_sold'=>1,'sold_at'=>date('Y-m-d H:i:s'));
                            $where1 = array('id'=>$transaction->requst->id);                    
                            $db->Update($update1, 'requsts', $where1);

                            //send sms
                            $sms = new Messaging();
                            $sms->sendSoldSMS($transaction->requst->customer->phone,
                                    $transaction->requst->meter_code,$transaction->ecg_amount);

                        } else {
                            $np = new NsanoPaymentController();
                            $r = $np->SendSuccessNotification($transaction->client_refrence);

                            if($r['sent'] == 'yes') {

                                $db = new DBConnector();                        
                                $update = array('is_refunded'=>0,'is_sold'=>1,'sold_at'=>date('Y-m-d H:i:s'));
                                $where = array('id'=>$id);                    
                                $db->Update($update, 'momo_transations', $where);

                                $update1 = array('is_rejected'=>0,'is_sold'=>1,'sold_at'=>date('Y-m-d H:i:s'));
                                $where1 = array('id'=>$transaction->requst->id);                    
                                $db->Update($update1, 'requsts', $where1);

                                //send sms
                                $sms = new Messaging();
                                $sms->sendSoldSMS($transaction->requst->customer->phone,
                                        $transaction->requst->meter_code,$transaction->ecg_amount);

                            }
                        }
                        	
                    }                   
                    		
		}
			//return View::make('transactions.add_as_sale', compact('transaction'));
		return Redirect::back();
                //return $r;
	}
		
	public function addAsRefund($id)
	{
		$transaction = MomoTransation::find($id);

		if($transaction->requst && $transaction->is_sold == 0 && $transaction->is_refunded == 0){
                    
                    if($transaction->partner() && strlen($transaction->partner())>0) {
                        $db = new DBConnector();                        
                        $update = array('is_refunded'=>1,'is_sold'=>0,'refunded_at'=>date('Y-m-d H:i:s'));
                        $where = array('id'=>$id);                    
                        $db->Update($update, 'momo_transations', $where);
                        
                        $update1 = array('is_rejected'=>1,'is_sold'=>0,'rejected_at'=>date('Y-m-d H:i:s'));
                        $where1 = array('id'=>$transaction->requst->id);                    
                        $db->Update($update1, 'requsts', $where1);
                        
                    } else {
                        
                        if($transaction->network=='mtn'){
                            
                            $np = new NsanoPaymentController();
                            $r = $np->SendMPayRefund($transaction);

                            if($r['sent'] == 'yes') {
                                
                                $db = new DBConnector();                        
                                $update = array('is_refunded'=>1,'is_sold'=>0,'refunded_at'=>date('Y-m-d H:i:s'));
                                $where = array('id'=>$id);                    
                                $db->Update($update, 'momo_transations', $where);

                                $update1 = array('is_rejected'=>1,'is_sold'=>0,'rejected_at'=>date('Y-m-d H:i:s'));
                                $where1 = array('id'=>$transaction->requst->id);                    
                                $db->Update($update1, 'requsts', $where1);

                                //send sms
                                $sms = new Messaging();
                                $sms->sendRefundSMS($transaction->requst->customer->phone,
                                        $transaction->requst->meter_code,$transaction->ecg_amount);

                            }
                            
                        } else {
                            $np = new NsanoPaymentController();
                            $r = $np->SendFailedNotification($transaction->client_refrence);

                            if($r['sent'] == 'yes') {
                                $db = new DBConnector();                        
                                $update = array('is_refunded'=>1,'is_sold'=>0,'refunded_at'=>date('Y-m-d H:i:s'));
                                $where = array('id'=>$id);                    
                                $db->Update($update, 'momo_transations', $where);

                                $update1 = array('is_rejected'=>1,'is_sold'=>0,'rejected_at'=>date('Y-m-d H:i:s'));
                                $where1 = array('id'=>$transaction->requst->id);                    
                                $db->Update($update1, 'requsts', $where1);

                                //send sms
                                $sms = new Messaging();
                                $sms->sendRefundSMS($transaction->requst->customer->phone,
                                        $transaction->requst->meter_code,$transaction->ecg_amount);
                            }
                        }
                        
                    }                    
                    			
		}
			//return View::make('transactions.add_as_sale', compact('transaction'));
		return Redirect::back();
                //return $r;
	}

	public function postAddAsSale($id){
		$transaction = MomoTransation::find($id);
		$request = $transaction->requst;
		$request->vendor_id = Input::get('vendor_id');
		$request->sold_by_id = Auth::user()->id;
		$request->is_sold = 1;
		$request->sold_at = date('Y-m-d H:i:s');
		$request->save();

		return Redirect::to('transactions');
	}

	/**
	 * Update the specified transaction in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$transaction = Transaction::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Transaction::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$transaction->update($data);

		return Redirect::route('transactions.index');
	}

	/**
	 * Remove the specified transaction from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Transaction::destroy($id);

		return Redirect::route('transactions.index');
	}

}
