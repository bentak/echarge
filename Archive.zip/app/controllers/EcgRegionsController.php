<?php

class EcgRegionsController extends \BaseController {

	/**
	 * Display a listing of ecgregions
	 *
	 * @return Response
	 */
	public function index()
	{
		$ecgregions = EcgRegion::all();
                $data['pagetab'] = 'location';
                $data['ecgregions'] = $ecgregions;
		return View::make('ecg_regions.index', $data);
	}

	/**
	 * Show the form for creating a new ecgregion
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('ecg_regions.create');
	}

	/**
	 * Store a newly created ecgregion in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), EcgRegion::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		EcgRegion::create($data);

		return Redirect::route('ecgregions.index');
	}

	/**
	 * Display the specified ecgregion.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$ecgregion = EcgRegion::findOrFail($id);

		return View::make('ecg_regions.show', compact('ecgregion'));
	}

	/**
	 * Show the form for editing the specified ecgregion.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$ecgregion = EcgRegion::find($id);

		return View::make('ecg_regions.edit', compact('ecgregion'));
	}

	/**
	 * Update the specified ecgregion in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$ecgregion = EcgRegion::findOrFail($id);

		$validator = Validator::make($data = Input::all(), EcgRegion::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$ecgregion->update($data);

		return Redirect::route('ecgregions.index');
	}

	/**
	 * Remove the specified ecgregion from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		EcgRegion::destroy($id);

		return Redirect::route('ecgregions.index');
	}

}
