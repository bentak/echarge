<?php
include_once 'dbconnect.php';

class LocationsController extends \BaseController {

	/**
	 * Display a listing of locations
	 *
	 * @return Response
	 */
	public function index()
	{
		$data['pagetab'] = 'location';
		$data['locations'] = Location::orderBy('name','ASC')->get();

		return View::make('locations.index', $data);
	}
        
	public function all()
	{
            $db = new DBConnector();
            $ValidLocations = $db->Select("SELECT id,name,description from locations order by name ASC");
            return  json_encode(array(
                     'success'=>'yes',
                     'status'=>200,
                     'data'=> $ValidLocations
                         ));
	}
        
        public function find($location)
	{
            $db = new DBConnector();
            $filter_key = trim($location);
            //check if location is valid smart meter location
            $ValidLocations = $db->Select("SELECT description as name,LOCATE('$filter_key', description) as p from locations where description RLIKE '$filter_key' ORDER BY p ASC LIMIT 10");

            return  json_encode(array(
                     'success'=>'yes',
                     'status'=>200,
                     'data'=> $ValidLocations
                         ));
	}

	/**
	 * Show the form for creating a new location
	 *
	 * @return Response
	 */
	public function create()
	{
            $data['regions'] = EcgRegion::orderBy('name','ASC')->get();	
            return View::make('locations.create',$data);
	}

	/**
	 * Store a newly created location in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
            $data = Input::all();
            
            $validator = Validator::make($data, Location::$rules);

            if ($validator->fails())
            {
                    return Redirect::back()->withErrors($validator)->withInput();
            }

            Location::create($data);

            return Redirect::route('locations.index');
	}

	/**
	 * Display the specified location.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$location = Location::findOrFail($id);

		return View::make('locations.show', compact('location'));
	}

	/**
	 * Show the form for editing the specified location.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$data['location'] = Location::find($id);
                $data['regions'] = EcgRegion::orderBy('name','ASC')->get();
                
		return View::make('locations.edit', $data);
	}

	/**
	 * Update the specified location in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$location = Location::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Location::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$location->update($data);

		return Redirect::route('locations.index');
	}

	/**
	 * Remove the specified location from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Location::destroy($id);

		return Redirect::route('locations.index');
	}

}
