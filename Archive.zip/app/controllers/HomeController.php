<?php

class HomeController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	public function home()
	{
		if(Auth::check()){
			$data['pagetab'] = 'dashboard';
			return View::make('home.index',$data);
		}
		return View::make('index.index');
	}

	public function get_upload_data()
	{
		return View::make('home.upload_data');
	}

	public function post_upload_data()
	{
		
		    $ok = true;
		    $file = $_FILES['data_file']['tmp_name'];
		    $handle = fopen($file, "r");
		    if ($file == NULL) {
		      error(_('Please select a file to import'));
		     return Redirect::back();
		    }
		    else {
		    	$data = array();
		      while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
		        {
		          //return $filesop[0];
		          $data['first_name'] = '';
		          $data['last_name'] = '';
		          $data['other_name'] = '';

		          $name = explode(' ',$filesop[2],3);
		          if(count($name)==1){
		          	$data['first_name'] = $name[0];
		          }
		          if(count($name)==2){
		          	$data['first_name'] = $name[0];
		          	$data['last_name'] = $name[1];
		          }
		          if(count($name)==3){
		          	$data['first_name'] = $name[0];
		          	$data['other_name'] = $name[1];
		          	$data['last_name'] = $name[2];
		          }
		          $data['code'] = $filesop[0];
		          $data['title'] = $filesop[1];

		          $data['gender_id'] = 1;

		          if($filesop[3]=='M') $data['gender_id'] = 2;
		          if($filesop[3]=='F') $data['gender_id'] = 3;
		          
		          $data['token'] = Customer::createCode();
		          $data['pin'] = Customer::createPin();
				  Customer::create($data);
		
		 // If the tests pass we can insert it into the database.       
		        
		      }

		     
		    }
		  
		Session::flash('mt', 'success');
		Session::flash('ms', 'Successfully done');
		return Redirect::back();
		 

	}

	public function apiGetEcgStatus(){
		return Response::json(array('ecg_status'=>EcgStatus::currentStatus(),'status'=>200));
	}

	public function ecgStatusToggle(){
		$currentStatus = EcgStatus::orderBy('created_at','DESC');

		$newStatus = 1;

		if (count($currentStatus->get()) > 0 && $currentStatus->first()->status) {
			$newStatus = 0;
		}

		EcgStatus::create(array('status'=>$newStatus));

		Session::flash('mt', 'success');
		Session::flash('ms', 'ECG Status successfully toggled');
		return Redirect::back();

	}

}
