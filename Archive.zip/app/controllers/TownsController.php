<?php

class TownsController extends \BaseController {

	/**
	 * Display a listing of towns
	 *
	 * @return Response
	 */
	public function index()
	{
		$towns = Town::all();

		return View::make('towns.index', compact('towns'));
	}

	/**
	 * Show the form for creating a new town
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('towns.create');
	}

	/**
	 * Store a newly created town in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), Town::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		Town::create($data);

		return Redirect::route('towns.index');
	}

	/**
	 * Display the specified town.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$town = Town::findOrFail($id);

		return View::make('towns.show', compact('town'));
	}

	/**
	 * Show the form for editing the specified town.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$town = Town::find($id);

		return View::make('towns.edit', compact('town'));
	}

	/**
	 * Update the specified town in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$town = Town::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Town::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$town->update($data);

		return Redirect::route('towns.index');
	}

	/**
	 * Remove the specified town from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Town::destroy($id);

		return Redirect::route('towns.index');
	}

}
