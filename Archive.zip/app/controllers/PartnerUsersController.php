<?php
include_once 'dbconnect.php';

class PartnerUsersController extends \BaseController {

    private $table = "partner_users";
    /**
	 * Display a listing of users
	 *
	 * @return Response
	 */
	public function index()
	{
		$users = PartnerUser::all();

		return View::make('partner_users.index', compact('users'));
	}

	/**
	 * Show the form for creating a new user
	 *
	 * @return Response
	 */
	public function create()
	{
            return View::make('partner_users.create');
	}

       function filterUserAPI($user_id,$api_key) {

           
            $rows = Input::get('_display');
            $from_date = Input::get('from_date');
            $to_date = Input::get('to_date');
            $filter = Input::get('filter');
            $filter_key = Input::get('filter_key');
            $offset = Input::get('offset');

            $temp = Partner::where('api_key',$api_key);

            if(count($temp->get())==0){               
                return json_encode(array(
                    'success'=>'no',                    
                    'status'=>400,
                    'message' =>'Invalid API Key'                                
                    )
                        );                
            } 

            $partner = $temp->first();
            
            
            $temp2 = PartnerUser::where('user_id',$user_id);
                
            if(count($temp2->get())==0){               
                return json_encode(array(
                    'success'=>'no',                    
                    'status'=>400,
                    'message' =>'Unauthorized request.'                                
                    )
                        );                
            } 
            
            $user = $temp2->first();

            $limit = $offset + $rows;

            switch ($filter) {
                case 1:
                    $filter_sring = strlen($filter_key)>0? "user_name RLIKE '$filter_key'":'';                
                    break;
                case 2:
                    $filter_sring = strlen($filter_key)>0? "branch_name RLIKE '$filter_key'":'';                
                    break;
                
                default:
                    $filter_sring='';
                    break;
            }

            //string for date 
            $date_string ='';
            if(strlen($from_date)>0 && strlen($to_date)>0){
                $date_string = "DATE($this->table.created_at) BETWEEN '$from_date' AND '$to_date'";
            } elseif (strlen($from_date)>0) {            
                $date_string = "DATE($this->table.created_at) BETWEEN '$from_date' AND '$from_date'";
            } elseif(strlen($to_date)>0) {
                $date_string = "DATE($this->table.created_at) BETWEEN '$to_date' AND '$to_date'";
            }


            $where = strlen($filter_sring)>0 ? "WHERE user_partner=$partner->id AND $filter_sring ".($user->account_level==0?'':' AND user_branch='.$user->user_branch.' AND account_level>='.$user->account_level):"WHERE user_partner=$partner->id ".($user->account_level==0?'':' AND user_branch='.$user->user_branch.' AND account_level>='.$user->account_level);

            if (strlen($date_string)>0 && strlen($where)>0 ){
                $where .= " AND $date_string";
            } elseif (strlen($date_string)>0 && strlen($where)==0) {
                $where .= "WHERE $date_string";
            }

            $q = "SELECT $this->table.*,branch_name,branch_location FROM $this->table "
                    . "JOIN partner_branches ON user_branch=branch_id  $where ORDER BY user_id DESC";
          

            $db = new DBConnector(); 

            $res = $db->Select($q);

            if(is_array($res)){
                if(count($res)>0) {
                    echo json_encode(array('status'=>'ok','message'=>count($res).' results found.','data'=>$res));
                }
                else {
                    echo json_encode(array('status'=>'ok','message'=>'No Resulsts found.','data'=>$res));
                }  
            } else {
                echo json_encode(array('status'=>'error','message'=>$res));
            }


        } 
        
       function addUserAPI($api_key) {
        
        $data = Input::all();
        
        $temp = Partner::where('api_key',$api_key);

        if(count($temp->get())==0){               
            return json_encode(array(
                'success'=>'no',                    
                'status'=>400,
                'message' =>'Invalid API Key'                                
                )
                    );                
        }
        
        $partner = $temp->first();
            
        $user = array ('user_name'=> $data['user_name'],
            'user_partner'=>$partner->id,
            'user_phone'=> $data['user_phone'],
            'user_branch'=> $data['user_branch'],
            'user_password'=> md5($data['user_password'] . 'KANE->2018.Worla') ,
            'account_level'=> $data['account_level'],
                );
        $validator = Validator::make($data, PartnerUser::$rules);

        if ($validator->fails())
        {
            return json_encode(array(
                'success'=>'no',                    
                'status'=>400,
                'message' =>$validator->messages()                                
                )
                    ); 
               
        }
        
        $permissions = $this->getPermissions();
        
        $created = PartnerUser::create($user);
        $permissions['user_account'] = $created->id;
        
        PartnerUserPermission::create($permissions);

        return json_encode(array(
                'success'=>'yes',                    
                'status'=>200,
                'message' =>'User Added Successfully.'                                
                )
                    );
           
        
    }
    
    function updateUserAPI($id,$api_key) {
        
        $data = Input::all();
        
        $temp = Partner::where('api_key',$api_key);

        if(count($temp->get())==0){               
            return json_encode(array(
                'success'=>'no',                    
                'status'=>400,
                'message' =>'Invalid API Key'                                
                )
                    );                
        }        
        //$partner = $temp->first();
        
        $btemp = PartnerUser::where('user_id',$id);

        if(count($btemp->get())==0){               
            return json_encode(array(
                'success'=>'no',                    
                'status'=>400,
                'message' =>'Invalid user ID.'                                
                )
                    );                
        }        
        $user = $temp->first();        
            
        $input = array ('user_name'=> $data['user_name'],           
            'user_phone'=> $data['user_phone'],
            'user_branch'=> $data['user_branch'],
            'account_level'=> $data['account_level'],
                );
        
        if(strlen(trim($data['user_password']))>0) {
            $input["user_password"] = md5($data['user_password'] . 'KANE->2018.Worla');
        }

        $validator = Validator::make($input, PartnerUser::$updaterules);
        
        if ($validator->fails())
        {
            return json_encode(array(
                'success'=>'no',                    
                'status'=>400,
                'message' =>$validator->messages()                                
                )
                    ); 
               
        }
        
        $cond = array('user_id'=>$id);
        
        $db = new DBConnector();
        $db->Update($input, 'partner_users', $cond);
        
        //$user->update($input);
        
        $permissions = $this->getPermissions();
        
        $user_permissions = PartnerUserPermission::where('user_account',$id);       
        
        $user_permissions->update($permissions);

        return json_encode(array(
                'success'=>'yes',                    
                'status'=>200,
                'message' =>'User updated Successfully.'                                
                )
                    );
           
        
    } 
       
        
	/**
	 * Store a newly created user in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		

		$validator = Validator::make($data = Input::all(), User::$rules);

		if ($validator->fails())
		{
			Session::flash('mt', 'warning');
			Session::flash('ms', 'Please check error(s) indicated and try again.');
			return Redirect::back()->withErrors($validator)->withInput();
		}

		PartnerUser::create($data);

		Session::flash('mt', 'success');
		Session::flash('ms', 'User successfully registered.');
		return Redirect::route('partner_users.index');
	}

	/**
	 * Display the specified user.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$user = User::findOrFail($id);

		return View::make('users.show', compact('user'));
	}

	/**
	 * Show the form for editing the specified user.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		

		$user = User::find($id);

		return View::make('users.edit', compact('user'));
	}
	

	/**
	 * Remove the specified user from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		

		User::destroy($id);

		Session::flash('mt', 'success');
		Session::flash('ms', 'Successfully deleted user');
		return Redirect::route('users.index');
	}
	

	public function changePassword()
	{
		$user = User::findOrFail(Auth::user()->id);

		$data = Input::all();

		$validator = Validator::make($data, User::$pc_rules);

		if ($validator->fails())
		{
			Session::flash('mt', 'warning');
			Session::flash('ms', 'Please check error(s) indicated and try again.');
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$user->update($data);

		Session::flash('mt', 'success');
		Session::flash('ms', 'Password successfully changed');
		return Redirect::back();
	}


	public function apiLogin(){
		
		$username     = Input::get('username');
		$password     = Input::get('password');
		
		if (Auth::attempt(array('username' => $username, 'password' => $password))){
			return json_encode(array('user_exists'=>'yes','status'=>200,'user_id'=>Auth::user()->id));
		}

		return json_encode(array('user_exists'=>'no','status'=>200));
	}
        
        
   private function getPermissions() {
        return array( 'can_add_sales'=>Input::get('can_add_sales')=='1'?1:0,
   'can_view_transactions'=> Input::get('can_view_transactions')=='1'?1:0,
   'can_view_branches'=> Input::get('can_view_branches')=='1'?1:0,
   'can_edit_branches'=> Input::get('can_edit_branches')=='1'?1:0,
   'can_delete_branches'=> Input::get('can_delete_branches')=='1'?1:0,
   'can_view_report'=> Input::get('can_view_report')=='1'?1:0,
   'can_view_topups'=> Input::get('can_view_topups')=='1'?1:0,
   'can_view_users'=> Input::get('can_view_users')=='1'?1:0,
   'can_edit_users'=> Input::get('can_edit_users')=='1'?1:0,
   'can_add_users'=> Input::get('can_add_users')=='1'?1:0,
   'can_delete_users'=> Input::get('can_delete_users')=='1'?1:0,
   'can_update_all'=> Input::get('can_update_all')=='1'?1:0,
   'can_add_branches'=> Input::get('can_add_branches')=='1'?1:0, 
            );
    }

}
