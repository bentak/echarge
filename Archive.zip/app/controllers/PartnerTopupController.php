<?php
include_once 'dbconnect.php';

class PartnerTopupController extends \BaseController {
    private $table = 'partner_topups';
	/**
	 * Display a listing of locations
	 *
	 * @return Response
	 */
	public function index($from="",$to="")
	{
		$data['pagetab'] = 'topups';		    
               
		$data['topups'] = PartnerTopup::orderBy('id','DESC')->get();  
                $data['topups'] = strlen($from)==0 && strlen($to)==0 ?
                    PartnerTopup::where('created_at','>=',date('Y-m-d 00:00:00'))->where('created_at','<=',date('Y-m-d 23:59:59'))->orderBy('id','DESC')->get():                    
                    PartnerTopup::where('created_at','>=',date($from.' 00:00:00'))->where('created_at','<=',date($to.' 23:59:59'))->orderBy('id','DESC')->get();

                $data['from'] = strlen($from)==0?date('Y-m-d'): $from;
                $data['to'] = strlen($to)==0?date('Y-m-d'): $to;

		return View::make('topup.index', $data);
	}
        
        
         function filterTopupAPI($api_key) {
          
            $rows = Input::get('_display');
            $from_date = Input::get('from_date');
            $to_date = Input::get('to_date');
            $filter = Input::get('filter');
            $filter_key = Input::get('filter_key');
            $offset = Input::get('offset');
            
            $temp = Partner::where('api_key',$api_key);
                
            if(count($temp->get())==0){               
                return json_encode(array(
                    'success'=>'no',                    
                    'status'=>400,
                    'message' =>'Invalid API Key'                                
                    )
                        );                
            } 
            
            $partner = $temp->first();
            
            $limit = $offset + $rows;
            
            $gt_pos = strpos($filter_key, ">");
            $lt_pos = strpos($filter_key, "<");
        
        switch ($filter) {
            case 0:
                $filter_sring = strlen($filter_key)>0?($gt_pos>=0||$lt_pos>=0?"amount_paid'$filter_key'":"amount_paid='$filter_key'") :'';                
                break;
            case 1:
                $filter_sring = strlen($filter_key)>0? ($gt_pos>=0||$lt_pos>=0?"ecg_quota'$filter_key'":"ecg_quota='$filter_key'"):'';                
                break;
            case 2:
                $filter_sring = strlen($filter_key)>0? ($gt_pos>=0||$lt_pos>=0?"quota_commission'$filter_key'":"quota_commission='$filter_key'"):'';                
                break;
           
            default:
                $filter_sring='';
                break;
        }
        
        //string for date 
        $date_string ='';
        if(strlen($from_date)>0 && strlen($to_date)>0){
            $date_string = "DATE($this->table.created_at) BETWEEN '$from_date' AND '$to_date'";
        } elseif (strlen($from_date)>0) {            
            $date_string = "DATE($this->table.created_at) BETWEEN '$from_date' AND '$from_date'";
        } elseif(strlen($to_date)>0) {
            $date_string = "DATE($this->table.created_at) BETWEEN '$to_date' AND '$to_date'";
        }
      
        
        $where = strlen($filter_sring)>0 ? "WHERE topup_partner=$partner->id AND $filter_sring":"WHERE topup_partner=$partner->id ";
        
        if (strlen($date_string)>0 && strlen($where)>0 ){
            $where .= " AND $date_string";
        } elseif (strlen($date_string)>0 && strlen($where)==0) {
            $where .= "WHERE $date_string";
        }
        
        $q = "SELECT partner_topups.*,partner_name FROM partner_topups "
                . "JOIN partners ON topup_partner=partners.id ";
        $q .= " $where ORDER BY partner_topups.id DESC";
        
                
        $db = new DBConnector(); 
             
        $res = $db->Select($q);
        
        if(is_array($res)){
            if(count($res)>0) {
                echo json_encode(array('status'=>'ok','message'=>count($res).' results found.','data'=>$res));
            }
            else {
                echo json_encode(array('status'=>'ok','message'=>'No Transactions found.','data'=>$res));
            }  
        } else {
            echo json_encode(array('status'=>'error','message'=>$res));
        }
        
          
    } 
        

	/**
	 * Show the form for creating a new location
	 *
	 * @return Response
	 */
	public function create()
	{
            $data['partners'] = Partner::orderBy('partner_name','ASC')->get();		
            return View::make('topup.create',$data);
	}

	/**
	 * Store a newly created location in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
            $data = Input::all();
            
            $topup = array ('amount_paid'=> str_replace(',', '', $data['amount_paid']),
                'topup_partner'=>$data['topup_partner'],
                'ecg_quota'=> str_replace(',', '', $data['ecg_quota']),
                    );
            $temp = Partner::where('id',$data['topup_partner']);
            
            if(count($temp->get())>0){
                $partner = $temp->first();
                
                $comm = $topup['amount_paid'] * 0.019;
                $topup['quota_commission'] = 0.00;                

                if($partner->is_reseller==1) {
                    $topup['quota_commission'] = $comm;
                    $topup['partner_commission'] = $comm * 0.5;
                    $topup['origgin_commission'] = $comm * 0.3;
                    $topup['vendor_commission'] = $comm * 0.2;
                } else {
                    if($topup['amount_paid']<9999) { 
                        $topup['origgin_commission'] = $topup['amount_paid'] * 0.03;
                    } elseif ($topup['amount_paid']<49999) {                        
                        $topup['origgin_commission'] = $topup['amount_paid'] * 0.025;
                    } elseif ($topup['amount_paid']<99999) {
                        $topup['origgin_commission'] = $topup['amount_paid'] * 0.018;
                    }
                }
                
                $validator = Validator::make($topup, PartnerTopup::$rules);

                if ($validator->fails())
                {
                        return Redirect::back()->withErrors($validator)->withInput();
                }
                               
                
                $created = PartnerTopup::create($topup);
                
                $partner->quota_bal = $partner->quota_bal + $created->ecg_quota;
                $partner->save();
            }            
           
            return Redirect::route('topups.index');
	}

	/**
	 * Display the specified location.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$location = PartnerTopup::findOrFail($id);

		return View::make('topup.show', compact('location'));
	}

	/**
	 * Show the form for editing the specified location.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
            $data['partners'] = Partner::orderBy('partner_name','ASC')->get();	
            $data['topup'] = PartnerTopup::find($id);

		return View::make('topup.edit', $data);
	}

	/**
	 * Update the specified location in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
            $pt = PartnerTopup::findOrFail($id);

            $data = Input::all();

            $validator = Validator::make($data, PartnerTopup::$rules);

            if ($validator->fails())
            {
                    return Redirect::back()->withErrors($validator)->withInput();
            }
                
            $temp = Partner::where('id',$data['topup_partner']);
            
            if(count($temp->get())>0){
            
            $partner = $temp->first();
            
            $topup = array ('amount_paid'=> str_replace(',', '', $data['amount_paid']),
                'topup_partner'=>$data['topup_partner'],
                'ecg_quota'=> str_replace(',', '', $data['ecg_quota']),
                'quota_commission'=>0.00,
                'partner_commission'=> 0.00,
                'origgin_commission'=> 0.00,
                'vendor_commission'=> 0.00                
                    );                
                
            $comm = $topup['amount_paid'] * 0.019;            

            if($partner->is_reseller==1) {
                $topup['quota_commission'] = $comm;
                $topup['partner_commission'] = $comm * 0.5;
                $topup['origgin_commission'] = $comm * 0.3;
                $topup['vendor_commission'] = $comm * 0.2;
            } else {
                if($topup['amount_paid']<=9999) { 
                    $topup['origgin_commission'] = $topup['amount_paid'] * 0.03;
                } elseif ($topup['amount_paid']<=49999) {                        
                    $topup['origgin_commission'] = $topup['amount_paid'] * 0.025;
                } elseif ($topup['amount_paid']<=99999) {
                    $topup['origgin_commission'] = $topup['amount_paid'] * 0.018;
                }
            }            
            
            if($pt->topup_partner==$partner->id) {
                $partner->quota_bal = $partner->quota_bal - ($pt->amount_paid+$pt->partner_commission);
                $partner->quota_bal = $partner->quota_bal + ($topup['amount_paid']+$topup['partner_commission']);                
            } else {
                $partner->quota_bal = $partner->quota_bal - ($pt->amount_paid+$pt->partner_commission);
                
                $partner = Partner::where('id',$pt->topup_partner)->first();
                $partner->quota_bal = $partner->quota_bal + ($topup['amount_paid']+$topup['partner_commission']);
            }

            $pt->update($topup);
            $partner->save();           
            
            return Redirect::route('topups.index');
            }
            
            return Redirect::back();
	}

	/**
	 * Remove the specified location from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		PartnerBranch::destroy($id);

		return Redirect::route('topup.index');
	}

}
