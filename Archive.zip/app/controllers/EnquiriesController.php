<?php

class EnquiriesController extends \BaseController {

	/**
	 * Display a listing of enquiries
	 *
	 * @return Response
	 */
	public function index()
	{
		$data['pagetab'] = 'enquiries';
		$data['enquiries'] = Enquiry::with('customer')->where('is_confirmed',0)->orderBy('updated_at','DECS')->get();

		return View::make('enquiries.index', $data);
	}

	public function getRespond($id)
	{
		$data['pagetab'] = 'enquiries';
		$enquiry = Enquiry::with('customer')->findOrFail($id);
		$data['enquiry'] = $enquiry;
		if($enquiry->type=='BALANCE ENQUIRY'){
			$data['field'] = 'Balance';
			$data['message'] = "Dear Customer,\n\nDetails of the balance as requested are as follows:\nMeter Code: ".$enquiry->meter_code."\nBalance: GHS %%0.00%%\nDate: ".date('l, jS \of F, Y.')."\nTime: ".date('h:i:s A')."\n\nThank you.\n\nThe Origgin Technologies Team";
		} else {
			$data['field'] = 'Consumption';
			$data['message'] = "Dear Customer,\n\nDetails of the consumption report as requested are as follows:\nMeter Code: ".$enquiry->meter_code."\nConsumption: GHS %%0.00%%\nPeriod: Last 3 months\nDate: ".date('l, jS \of F, Y.')."\nTime: ".date('h:i:s A')."\n\nThank you.\n\nThe Origgin Technologies Team";
		}
		

		return View::make('enquiries.repond', $data);
	}

	public function postRespond($id){
		$data = Input::all();
		$enquiry = Enquiry::findOrFail($id);
		
		// use wordwrap() if lines are longer than 70 characters
		$msg = wordwrap($data['message'],70);

		// if(!$enquiry->customer) {
		// 	return Redirect::back();
		// }

		try {
		  // send email
		mail($enquiry->customer->email,$enquiry->type.' response',$msg);
		}

		//catch exception
		catch(Exception $e) {
		  return Redirect::back();
		}

		
	}

	/**
	 * Show the form for creating a new enquiry
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('enquiries.create');
	}

	/**
	 * Store a newly created enquiry in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), Enquiry::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		Enquiry::create($data);

		return Redirect::route('enquiries.index');
	}

	/**
	 * Display the specified enquiry.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$data['enquiry'] = Enquiry::findOrFail($id);


		return View::make('enquiries.show', $data);
	}

	/**
	 * Show the form for editing the specified enquiry.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$enquiry = Enquiry::find($id);

		return View::make('enquiries.edit', compact('enquiry'));
	}

	/**
	 * Update the specified enquiry in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$enquiry = Enquiry::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Enquiry::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$enquiry->update($data);

		return Redirect::route('enquiries.index');
	}

	/**
	 * Remove the specified enquiry from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Enquiry::destroy($id);

		return Redirect::route('enquiries.index');
	}

	public function apiPostInitiateEnquiry($meter_code, $token)
	{
		$customer = Customer::where('customer_token',$token);

		if(count($customer->get())>0){
			$customer = $customer->first();

			$data = array('meter_code'=>$meter_code,'customer_token'=>$token);

			$validator = Validator::make($data, Enquiry::$rules);

			if ($validator->fails())
			{
				return json_encode(array('enquiry_initiated'=>'no','validation'=>'no','status'=>400,'errors'=>$validator->messages()));
			}

			Enquiry::create($data);

			//return Redirect::route('enquiries.index');
			return Response::json(array('customer_exists'=>'yes','validation'=>'yes','status'=>200));
		}

		return json_encode(array('customer_exists'=>'no','status'=>400));

		
	}

	public function apiPostConsumptionEnquiry($meter_code, $token)
	{
		$customer = Customer::where('customer_token',$token);

		if(count($customer->get())>0){
			$customer = $customer->first();

			$data = array('meter_code'=>$meter_code,'customer_token'=>$token);

			$validator = Validator::make($data, Enquiry::$rules);

			if ($validator->fails())
			{
				return json_encode(array('enquiry_initiated'=>'no','validation'=>'no','status'=>400,'errors'=>$validator->messages()));
			}

			$data['type'] = 'Consumption Report';
			Enquiry::create($data);

			//return Redirect::route('enquiries.index');
			return Response::json(array('customer_exists'=>'yes','validation'=>'yes','status'=>200));
		}

		return json_encode(array('customer_exists'=>'no','status'=>400));

		
	}

	public function apiGetConfirmEnquiry($meter_code, $token)
	{
		$customer = Customer::where('customer_token',$token);

		if(count($customer->get())>0){
			$customer = $customer->first();

			$enquiry = Enquiry::where('meter_code',$meter_code)->where('customer_token',$token)->orderBy('created_at','DESC');

			if(count($enquiry->get())>0){
				$enquiry = $enquiry->first();
				return Response::json(array('customer_exists'=>'yes','status'=>200,'enquiry'=>'yes','balance'=>number_format($enquiry->balance,2,'.',',')));
			}

			//return Redirect::route('enquiries.index');
			return Response::json(array('customer_exists'=>'yes','status'=>400,'enquiry'=>'no','balance'=>0));
		}

		return json_encode(array('customer_exists'=>'no','status'=>400));

		
	}

}
