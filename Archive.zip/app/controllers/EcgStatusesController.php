<?php

class EcgStatusesController extends \BaseController {

	/**
	 * Display a listing of ecgstatuses
	 *
	 * @return Response
	 */
	public function index()
	{
		$ecgstatuses = Ecgstatus::all();

		return View::make('ecgstatuses.index', compact('ecgstatuses'));
	}

	/**
	 * Show the form for creating a new ecgstatus
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('ecgstatuses.create');
	}

	/**
	 * Store a newly created ecgstatus in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), Ecgstatus::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		Ecgstatus::create($data);

		return Redirect::route('ecgstatuses.index');
	}

	/**
	 * Display the specified ecgstatus.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$ecgstatus = Ecgstatus::findOrFail($id);

		return View::make('ecgstatuses.show', compact('ecgstatus'));
	}

	/**
	 * Show the form for editing the specified ecgstatus.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$ecgstatus = Ecgstatus::find($id);

		return View::make('ecgstatuses.edit', compact('ecgstatus'));
	}

	/**
	 * Update the specified ecgstatus in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$ecgstatus = Ecgstatus::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Ecgstatus::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$ecgstatus->update($data);

		return Redirect::route('ecgstatuses.index');
	}

	/**
	 * Remove the specified ecgstatus from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Ecgstatus::destroy($id);

		return Redirect::route('ecgstatuses.index');
	}

}
