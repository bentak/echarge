<?php

class SalesController extends \BaseController {

	/**
	 * Display a listing of sales
	 *
	 * @return Response
	 */
	public function index()
	{
		$data['pagetab'] = 'sales';
		$q = MomoTransation::where('amount','>',0);
		$data['sold'] = $q->where('is_sold',1)->orderBy('id','DESC')->paginate(20);
		$data['refunded'] = $q->where('is_refunded',1)->orderBy('id','DESC')->paginate(20);

		return View::make('sales.index', $data);
	}
	
	public function today()
	{
		$data['pagetab'] = 'sales';
		$q = MomoTransation::where('amount','>',0);
		$data['sold'] = $q->where('sold_at','>=',date('Y-m-d 00:00:00'))->where('sold_at','<=',date('Y-m-d 23:59:59'))->where('is_sold',1)->orderBy('id','DESC')->get();
		$data['refunded'] = $q->where('refunded_at','>=',date('Y-m-d 00:00:00'))->where('refunded_at','<=',date('Y-m-d 23:59:59'))->where('is_refunded',1)->orderBy('id','DESC')->get();

		return View::make('sales.today', $data);
	}
	
	public function forPeriod($from=0, $to=0)
	{
		if($from==0 || $to==0){
			return Redirect::to('sales/today');
		}

		$data['pagetab'] = 'sales';
		$data['from'] = $from;
		$data['to'] = $to;
		$q = MomoTransation::where('amount','>',0);
		$data['sold'] = $q->where('sold_at','>=',date($from.' 00:00:00'))->where('sold_at','<=',date($to.' 23:59:59'))->where('is_sold',1)->orderBy('id','DESC')->get();
		$data['refunded'] = $q->where('refunded_at','>=',date($from.' 00:00:00'))->where('refunded_at','<=',date($to.' 23:59:59'))->where('is_refunded',1)->orderBy('id','DESC')->get();

		return View::make('sales.for_period', $data);
	}

	/**
	 * Show the form for creating a new sale
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('sales.create');
	}

	/**
	 * Store a newly created sale in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), MomoTransation::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		MomoTransation::create($data);

		return Redirect::route('sales.index');
	}

	/**
	 * Display the specified sale.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$sale = MomoTransation::findOrFail($id);

		return View::make('sales.show', compact('sale'));
	}

	/**
	 * Show the form for editing the specified sale.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$sale = MomoTransation::find($id);

		return View::make('sales.edit', compact('sale'));
	}

	/**
	 * Update the specified sale in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$sale = MomoTransation::findOrFail($id);

		$validator = Validator::make($data = Input::all(), MomoTransation::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$sale->update($data);

		return Redirect::route('sales.index');
	}

	/**
	 * Remove the specified sale from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		MomoTransation::destroy($id);

		return Redirect::route('sales.index');
	}

}
