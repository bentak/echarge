<?php

class PaymentTypeController extends \BaseController {

	/**
	 * Display a listing of locations
	 *
	 * @return Response
	 */
	public function index()
	{
		$data['pagetab'] = 'configurations';
		$data['payments'] = PaymentType::all();

		return View::make('payment_type.index', $data);
	}

	/**
	 * Show the form for creating a new location
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('payment_type.create');
	}

	/**
	 * Store a newly created location in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($data = Input::all(), PaymentType::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		PaymentType::create($data);

		return Redirect::route('payment_type.index');
	}

	/**
	 * Display the specified location.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$location = PaymentType::findOrFail($id);

		return View::make('payment_type.show', compact('location'));
	}

	/**
	 * Show the form for editing the specified location.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$location = PaymentType::find($id);

		return View::make('payment_type.edit', compact('location'));
	}

	/**
	 * Update the specified location in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$location = PaymentType::findOrFail($id);

		$validator = Validator::make($data = Input::all(), PaymentType::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$location->update($data);

		return Redirect::route('payment_type.index');
	}

	/**
	 * Remove the specified location from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		PaymentType::destroy($id);

		return Redirect::route('payment_type.index');
	}

}
