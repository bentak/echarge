DATABASE NAME [origginprepaid];

ALTER TABLE requsts ADD partner INT, ADD user_id INT, ADD branch_id INT;

DROP TABLE IF EXISTS partners;CREATE TABLE partners (
    id int not null auto_increment primary key,
    partner_name VARCHAR(100) NOT NULL,
    partner_phone varchar(30) not null,    
    partner_email VARCHAR(100) NOT NULL,
    api_key VARCHAR(250) NOT NULL,
    quota_bal DECIMAL(12,2) DEFAULT 0.00,
    is_reseller tinyint default 0,
    is_active tinyint default 1,
    created_at timestamp default current_timestamp,
    updated_at timestamp default current_timestamp on update current_timestamp   
);


DROP TABLE IF EXISTS partner_branches;CREATE TABLE partner_branches (
    branch_id int not null auto_increment primary key,
    branch_name VARCHAR(100) NOT NULL,    
    branch_location VARCHAR(100) NOT NULL,   
    branch_partner int not null,
    is_active tinyint default 1,
    created_at timestamp default current_timestamp,
    updated_at timestamp default current_timestamp on update current_timestamp,
    FOREIGN KEY (branch_partner) REFERENCES `partners` (id) ON DELETE CASCADE ON UPDATE CASCADE
);

DROP TABLE IF EXISTS partner_users;CREATE TABLE partner_users (
    user_id int not null auto_increment primary key,
    user_name VARCHAR(100) NOT NULL,    
    user_password VARCHAR(250) NOT NULL,
    user_phone VARCHAR(20),
    user_partner int not null,
    user_branch int not null default 0,
    account_level int not null, # [0=admin,1=manager,2=employee]
    is_active tinyint default 1,
    created_at timestamp default current_timestamp,
    updated_at timestamp default current_timestamp on update current_timestamp,
    FOREIGN KEY (user_partner) REFERENCES `partners` (id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (user_branch) REFERENCES `partner_branches` (branch_id) ON DELETE CASCADE ON UPDATE CASCADE
);

DROP TABLE IF EXISTS partner_user_permissions;CREATE TABLE partner_user_permissions (
    permission_id int not null auto_increment primary key,    
    user_account int not null,
    can_add_sales tinyint(4) DEFAULT '0',    
    can_view_transactions tinyint(4) DEFAULT '0',
    can_view_branches tinyint(4) DEFAULT '0',
    can_edit_branches tinyint(4) DEFAULT '0',
    can_delete_branches tinyint(4) DEFAULT '0',
    can_add_branches tinyint(4) DEFAULT '0',
    can_view_report tinyint(4) DEFAULT '0',
    can_view_topups tinyint(4) DEFAULT '0',    
    can_view_users tinyint(4) DEFAULT '0',
    can_edit_users tinyint(4) DEFAULT '0',
    can_add_users tinyint(4) DEFAULT '0',
    can_delete_users tinyint(4) DEFAULT '0',    
    can_update_all tinyint(4) DEFAULT '0',
    created_at timestamp default current_timestamp,
    updated_at timestamp default current_timestamp on update current_timestamp,
    FOREIGN KEY (user_account) REFERENCES `partner_users` (user_id) ON DELETE CASCADE ON UPDATE CASCADE
);

DROP TABLE IF EXISTS partner_topups;CREATE TABLE partner_topups (
    id int not null auto_increment primary key,
    topup_partner int not null,
    amount_paid DECIMAL(12,2) DEFAULT 0.00,
    ecg_quota DECIMAL(12,2) DEFAULT 0.00,
    quota_commission DECIMAL(12,2) DEFAULT 0.00,
    vendor_commission DECIMAL(12,2) DEFAULT 0.00,
    origgin_commission DECIMAL(12,2) DEFAULT 0.00,
    partner_commission decimal(12,2) default 0.00;
    before_topup decimal(12,2) default 0.00;
    after_topup decimal(12,2) default 0.00;
    created_at timestamp default current_timestamp,
    updated_at timestamp default current_timestamp on update current_timestamp,
    FOREIGN KEY (topup_partner) REFERENCES `partners` (id) ON DELETE CASCADE ON UPDATE CASCADE
);

DELIMITER ;;
CREATE TRIGGER _topup BEFORE INSERT ON partner_topups 
FOR EACH ROW 
BEGIN 
SET @bal = (SELECT quota_bal FROM partners WHERE id=NEW.topup_partner);
SET NEW.before_topup = bal; 
SET NEW.after_topup=bal+NEW.ecg_quota;
END;;;

CREATE TRIGGER topup_ BEFORE UPDATE ON partner_topups 
FOR EACH ROW 
BEGIN 
SET @bal = (SELECT quota_bal FROM partners WHERE id=NEW.topup_partner);
SET NEW.before_topup = @bal-(OLD.ecg_quota); 
SET NEW.after_topup=NEW.before_topup+NEW.ecg_quota;
END;;;

DELIMITER ;

DROP TABLE IF EXISTS blocked_lists;CREATE TABLE blocked_list (
    block_id int not null auto_increment primary key,
    blocked_customer int not null,
    blocked_contact varchar(30) not null,    
    block_status tinyint default 1,    
    created_at timestamp default current_timestamp,
    updated_at timestamp default current_timestamp on update current_timestamp,
    FOREIGN KEY (blocked_customer) REFERENCES `customers` (id) ON DELETE CASCADE ON UPDATE CASCADE
);


DROP TABLE IF EXISTS block_exceptions;CREATE TABLE block_exceptions (
    exception_id int not null auto_increment primary key,
    exception_customer int not null,
    exception_contact varchar(30) not null,
    created_at timestamp default current_timestamp,
    updated_at timestamp default current_timestamp on update current_timestamp,
    FOREIGN KEY (exception_customer) REFERENCES `customers` (id) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE IF NOT EXISTS `denied_requests` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,  
  `type_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `meter_code` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `amount` DECIMAL(9,2) NOT NULL DEFAULT 0.00,
  `location` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `meter_owner` varchar(64) COLLATE utf8_unicode_ci NOT NULL,  
  `customer_id` int(10) UNSIGNED NOT NULL DEFAULT '1',  
  `reject_reason` VARCHAR(50) NOT NULL DEFAULT '',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES `customers` (id) ON DELETE CASCADE ON UPDATE CASCADE
);

DROP TABLE IF EXISTS password_ressets;CREATE TABLE password_ressets (
    resset_id int not null auto_increment primary key,
    resset_customer int not null,
    resset_contact varchar(30) not null,
    resset_token varchar(240) not null,
    is_resset tinyint default 0,
    is_verified tinyint default 0,  
    verify_code varchar(10) not null,
    created_at timestamp default current_timestamp,
    updated_at timestamp default current_timestamp on update current_timestamp,
    FOREIGN KEY (resset_customer) REFERENCES `customers` (id) ON DELETE CASCADE ON UPDATE CASCADE
);

DROP TABLE IF EXISTS account_verifications;CREATE TABLE account_verifications (
    verify_id int not null auto_increment primary key,
    verify_customer int not null,
    verify_contact varchar(30) not null,    
    is_verified tinyint default 0,  
    is_expired tinyint default 0,  
    verify_code varchar(10) not null,
    created_at timestamp default current_timestamp,
    updated_at timestamp default current_timestamp on update current_timestamp,
    FOREIGN KEY (verify_customer) REFERENCES `customers` (id) ON DELETE CASCADE ON UPDATE CASCADE
);

DROP TABLE IF EXISTS payment_verifications;CREATE TABLE payment_verifications (
    verify_id int not null auto_increment primary key,
    verify_customer int not null,
    verify_contact varchar(30) not null,    
    is_verified tinyint default 0,  
    is_expired tinyint default 0,  
    verify_code varchar(10) not null,
    created_at timestamp default current_timestamp,
    updated_at timestamp default current_timestamp on update current_timestamp,
    FOREIGN KEY (verify_customer) REFERENCES `customers` (id) ON DELETE CASCADE ON UPDATE CASCADE
);






INSERT INTO app_settings (appname,applocation,appicon,contact) VALUES('my app','new location','','0244345678');

DROP TABLE IF EXISTS users; CREATE TABLE users (
    user_id INT NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    logname VARCHAR(50) UNIQUE NOT NULL,
    logpass VARCHAR(250) UNIQUE NOT NULL,
    tel varchar(20) not null,
    active TINYINT DEFAULT 1,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id,logpass)
);

DROP TABLE IF EXISTS user_permissions;CREATE TABLE user_permissions (
    perm_id int AUTO_INCREMENT NOT NULL,
    user int(11) NOT NULL,
    can_add_property tinyint(4) DEFAULT '0',
    can_edit_property tinyint(4) DEFAULT '0',
    can_delete_property tinyint(4) DEFAULT '0',
    can_view_property tinyint(4) DEFAULT '0',
    can_view_locations tinyint(4) DEFAULT '0',
    can_edit_locations tinyint(4) DEFAULT '0',
    can_delete_locations tinyint(4) DEFAULT '0',
    can_edit_modes tinyint(4) DEFAULT '0',
    can_view_modes tinyint(4) DEFAULT '0',
    can_delete_modes tinyint(4) DEFAULT '0',
    can_add_modes tinyint(4) DEFAULT '0',    
    can_add_clients tinyint(4) DEFAULT '0',
    can_edit_clients tinyint(4) DEFAULT '0',
    can_view_clients tinyint(4) DEFAULT '0',
    can_delete_clients tinyint(4) DEFAULT '0',
    can_add_riders tinyint(4) DEFAULT '0',
    can_edit_riders tinyint(4) DEFAULT '0',
    can_view_riders tinyint(4) DEFAULT '0',
    can_delete_riders tinyint(4) DEFAULT '0',
    can_add_vehicles tinyint(4) DEFAULT '0',
    can_edit_vehicles tinyint(4) DEFAULT '0',
    can_view_vehicles tinyint(4) DEFAULT '0',
    can_delete_vehicles tinyint(4) DEFAULT '0',
    can_edit_contents tinyint(4) DEFAULT '0',
    can_add_contents tinyint(4) DEFAULT '0',
    can_view_contents tinyint(4) DEFAULT '0',
    can_delete_contents tinyint(4) DEFAULT '0',
    can_view_records tinyint(4) DEFAULT '0',
    can_view_users tinyint(4) DEFAULT '0',
    can_edit_users tinyint(4) DEFAULT '0',
    can_add_users tinyint(4) DEFAULT '0',
    can_delete_users tinyint(4) DEFAULT '0',
    can_add_loans tinyint(4) DEFAULT '0',
    can_view_loans tinyint(4) DEFAULT '0',
    can_edit_loans tinyint(4) DEFAULT '0',
    can_delete_loans tinyint(4) DEFAULT '0',
    can_view_rentals tinyint(4) DEFAULT '0',
    can_edit_rentals tinyint(4) DEFAULT '0',
    can_add_rentals tinyint(4) DEFAULT '0',
    can_delete_rentals tinyint(4) DEFAULT '0',
    can_view_hirings tinyint(4) DEFAULT '0',
    can_delete_hirings tinyint(4) DEFAULT '0',
    can_edit_hirings tinyint(4) DEFAULT '0',
    can_add_hirings tinyint(4) DEFAULT '0',
    can_view_partners tinyint(4) DEFAULT '0',
    can_delete_partners tinyint(4) DEFAULT '0',
    can_edit_partners tinyint(4) DEFAULT '0',
    can_add_partners tinyint(4) DEFAULT '0',
    can_view_settings tinyint(4) DEFAULT '0',
    can_edit_settings tinyint(4) DEFAULT '0',
    can_update_all tinyint(4) DEFAULT '0',
    PRIMARY KEY (perm_id,user),KEY user_id (user),
    FOREIGN KEY (user) REFERENCES `users` (user_id) ON DELETE CASCADE ON UPDATE CASCADE);


CREATE TABLE clients (
    client_id INT NOT NULL AUTO_INCREMENT,
    f_name VARCHAR(100) NOT NULL,
    l_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    tel VARCHAR(20) NOT NULL UNIQUE,
    logpass VARCHAR(250) UNIQUE NOT NULL,
    logimage INT NOT NULL, 
    ref_number VARCHAR(6) NOT NULL,
    parent INT,
    gpost VARCHAR(20) NOT NULL,
    loc_lat VARCHAR(250),
    loc_lng VARCHAR(250),
    rating INT DEFAULT 1,
    active tinyint default 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    subs_expires TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_modified timestamp default current_timestamp on update current_timestamp,
    PRIMARY KEY (client_id,ref_number)
);


CREATE TABLE next_of_kings (
    king_id INT NOT NULL AUTO_INCREMENT,
    client INT NOT NULL,
    f_name VARCHAR(100) NOT NULL,
    l_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    tel VARCHAR(20) NOT NULL UNIQUE,
    logpass VARCHAR(250) UNIQUE NOT NULL,    
    active tinyint default 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_modified timestamp default current_timestamp on update current_timestamp,
    PRIMARY KEY (client_id,ref_number)
);


CREATE TABLE property (
    prop_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    prop_by INT NOT NULL,
    reg_title VARCHAR(150) NOT NULL,
    prop_value DECIMAL(9,2) DEFAULT 0.00,
    prop_size varchar(20),
    prop_desc VARCHAR(250),
    prop_type INT NOT NULL,
	ref_code VARCHAR(10) DEFAULT '',
    prop_rate int default 1,
    owner_status ENUM('PN','TL') DEFAULT 'PN',
    is_verified tinyint(1) default 0,
    verified_by int,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,    
   
    FOREIGN KEY (prop_by) REFERENCES clients(client_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (prop_type) REFERENCES prop_types(type_id) ON DELETE CASCADE ON UPDATE CASCADE
);

#table to log all delivery requests

CREATE TABLE locations (
    loc_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    property_id INT NOT NULL,
    gpost_add VARCHAR(20) NOT NULL,
    loc_lng VARCHAR(250),
    loc_lat VARCHAR(250)
    
);

CREATE TABLE login_images (
    image_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    image_desc VARCHAR(150),
    image_data VARCHAR(250) NOT NULL    
);

CREATE TABLE subscriptions (
    sup_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    sup_name VARCHAR(150),
    sup_period INT NOT NULL,
    sup_cost DECIMAL(9,2) NOT NULL,
);

CREATE TABLE client_subs (
    cl_subs_id INT NOT NULL AUTO_INCREMENT,
    subs_by INT NOT NULL,
    subs_price DECIMAL(9,2) NOT NULL,
    subs_type INT NOT NULL,
    quantity INT NOT NULL,
    subs_total DECIMAL(9,2) NOT NULL,    
    subs_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,    
    FOREIGN KEY (subs_by) REFERENCES clients (client_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (subs_type) REFERENCES subscriptions(sup_id) ON DELETE CASCADE ON UPDATE CASCADE,
    PRIMARY KEY (cl_subs_id)
);


CREATE TABLE transfers (
    trans_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    trans_form INT NOT NULL,
    trans_to INT NOT NULL,    
    trans_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);



CREATE TABLE property_types (
    type_id INT NOT NULL AUTO_INCREMENT,
    type_name VARCHAR(100) NOT NULL UNIQUE,
    type_desc VARCHAR(150),
    title_rate int NOT NULL,
    process_rate int NOT NULL,    
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (type_id)
);


    partner_id INT NOT NULL AUTO_INCREMENT,
    partner_name VARCHAR(50) NOT NULL UNIQUE,
    partner_contact VARCHAR(30) NOT NULL,
    partner_email VARCHAR(150),
    partner_address VARCHAR(150),
    active TINYINT DEFAULT 1,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (partner_id)
);









CREATE TABLE sliders (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    caption VARCHAR(50) DEFAULT '',
    link VARCHAR(100) DEFAULT '',
    description VARCHAR(150) DEFAULT '',
    image VARCHAR(250) NOT NULL UNIQUE,
    active TINYINT DEFAULT 1,
    last_modified TIMESTAMP ON UPDATE CURRENT_TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

#TABLE FOR VARIOUS PRODUCTS AND SERVICES
CREATE TABLE products (
    prod_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    prod_name VARCHAR(50) DEFAULT '',
    prod_desc VARCHAR(250) DEFAULT '',
    prod_features VARCHAR(250) DEFAULT '',
    prod_image VARCHAR(250) NOT NULL UNIQUE,
    prod_type ENUM('PR','SR') DEFAULT 'PR',
    active TINYINT DEFAULT 1,
    last_modified TIMESTAMP ON UPDATE CURRENT_TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

#TABLE FOR FEATURES OF PRODUCTS AND SERVICES
CREATE TABLE prod_features (
    feat_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    feat_name VARCHAR(50) DEFAULT '',
    feat_desc VARCHAR(250) DEFAULT '',
    prod_id INT NOT NULL,
    feat_image VARCHAR(250) NOT NULL UNIQUE,    
    active TINYINT DEFAULT 1,
    last_modified TIMESTAMP ON UPDATE CURRENT_TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

#TABLE FOR ABOUT, THIS WILL CONTAIN ELEMENTS/ENTRIES FOR ABOUT US
CREATE TABLE about (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    caption VARCHAR(100) NOT NULL,
    title VARCHAR(100) NOT NULL,
    content text NOT NULL,
    image VARCHAR(150),
    active TINYINT DEFAULT 1,
    last_modified TIMESTAMP ON UPDATE CURRENT_TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

#TABLE FOR CONTACT, THIS WILL CONTAIN ELEMENTS/ENTRIES FOR CONTACT INFO
CREATE TABLE contact (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    caption VARCHAR(100) NOT NULL,
    title VARCHAR(100) NOT NULL,
    content text NOT NULL,
    image VARCHAR(150),
    active TINYINT DEFAULT 1,
    last_modified TIMESTAMP ON UPDATE CURRENT_TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

#TABLE FOR VARIOUS VIDEO CAPTIONS/CATEGORIES
#CREATE TABLE category (
#   cat_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
#    cat_name VARCHAR(50) DEFAULT '',
#    cat_desc VARCHAR(150) DEFAULT '',
#    cat_image VARCHAR(250) NOT NULL UNIQUE,
#    active TINYINT DEFAULT 1,
#    last_modified TIMESTAMP ON UPDATE CURRENT_TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#);

#TABLE FOR VIDEO CONTENT
CREATE TABLE videos (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    caption VARCHAR(150) NOT NULL,
    image VARCHAR(250) NOT NULL UNIQUE,
    description varchar(250),
    section int not null,
    active TINYINT DEFAULT 1,
    media_type enum('IMG','AUD','VID') default 'IMG',
    istrue tinyint default 0,
    last_modified TIMESTAMP ON UPDATE CURRENT_TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

#TABLE FOR CHURCH ACTIVITIES
CREATE TABLE activity (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    schedule VARCHAR(50),
    notes VARCHAR(250),
    active TINYINT DEFAULT 1,
    last_modified TIMESTAMP ON UPDATE CURRENT_TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

#TABLE FOR NEWS PUBLICATIONS 
CREATE TABLE news (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    schedule VARCHAR(50),
    image VARCHAR(250) NOT NULL UNIQUE,
    notes VARCHAR(250),
    active TINYINT DEFAULT 1,
    last_modified TIMESTAMP ON UPDATE CURRENT_TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE user_permissions ADD can_delete_rentals tinyint(4) DEFAULT '0' after can_add_rentals, ADD can_delete_clients tinyint(4) DEFAULT '0' after can_view_clients, ADD can_delete_riders tinyint(4) DEFAULT '0' after can_view_riders, ADD can_delete_vehicles tinyint(4) DEFAULT '0' after can_view_vehicles,ADD can_delete_contents tinyint(4) DEFAULT '0' after can_view_contents,ADD can_delete_hirings tinyint(4) DEFAULT '0' after can_view_hirings,ADD can_delete_partners tinyint(4) DEFAULT '0' after can_view_partners,ADD can_edit_settings tinyint(4) DEFAULT '0' after can_view_settings;
can_edit_deliverylogs tinyint(4) DEFAULT '0',
    can_delete_deliverylogs

insert into users

    INSERT INTO user_permissions VALUES(1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1);