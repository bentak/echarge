$(function () {
	
	
	$('.subnavbar').find ('li').each (function (i) {
	
		var mod = i % 3;
		
		if (mod === 2) {
			$(this).addClass ('subnavbar-open-right');
		}
		
	});
	
	
	
});


function post(url, data, callback) {
          var req = new XMLHttpRequest();
          req.open("POST", url, true);
          req.onload= function() {
            if (req.status === 200){
                if(req.responseText===""){callback(null,new Error("Empty response"));}else
                {callback(req.responseText);}
            } else
              callback(null, new Error("Request failed: " + req.statusText));
          };
          req.addEventListener("error", function() {
            callback(null, new Error("Network error"));
          });
             req.addEventListener("abort", function() {
            callback(null, new Error("Request Cancelled"));
          });

             req.addEventListener("timeout", function() {
            callback(null, new Error("Request taking too long"));
          });

          req.setRequestHeader("Content-type","application/x-www-form-urlencoded");
          req.send(data);
    };
    
    function getNewTransactions(){
        var table_body = document.querySelector("#translist tbody");
        var first_row = table_body.children[0];
        var recentid = first_row.getAttribute('data-id');
        
        
        post('http://eprepaid.origgin.net/transactions/new/'+(recentid==null?0:recentid),null,function(s,f){
            if(s!==null) {
                        try{
                            var json = JSON.parse(s);
                            if(json.status === "ok" && typeof json.data === "object" && json.data.length>0){
                                addRecentToList(json.data);
                                palyer.play();
                                if(recentid==null){
                                    table_body.removeChild(first_row);
                                }
                                    
                            }  
                        }catch(ex) {
                           console.log(ex);
                        }                        
                        
                    } else {
                        console.log(f);
                    }
        });
    }
    
    function getNewRequests(){
        var table_body = document.querySelector("#translist tbody");
        var first_row = table_body.children[0];
        var recentid = first_row.getAttribute('data-id');
        
        
        post('http://eprepaid.origgin.net/requests/new/'+(recentid==null?0:recentid),null,function(s,f){
            if(s!==null) {
                        try{
                            var json = JSON.parse(s);
                            if(json.status === "ok" && typeof json.data === "object" && json.data.length>0){
                                addRecentRequestsToList(json.data);
                                if(recentid==null){
                                    table_body.removeChild(first_row);
                                }
                                    
                            }  
                        }catch(ex) {
                           console.log(ex);
                        }                        
                        
                    } else {
                        console.log(f);
                    }
        });
    }
    
    function addRecentToList(data) {
        var row_text ='';
        var table_body = document.querySelector("#translist tbody");
        var first_row = table_body.children[0];
        
        for(var i = 0, len = data.length; i < len; i++){
            var item = data[i];
           row_text = '<td>'+item["created_at"]+'</td>';             
           row_text += '<td>'+item["meter_code"]+'</td>';
           row_text += '<td>'+item["ecg_amount"]+'</td>';
           row_text +='<td>'+item["origgin_charge"]+'</td>';
           row_text += '<td>'+item["meter_owner"]+'</td>';
           row_text +='<td>'+item["location"]+'</td>';
           row_text +='<td>'+item["phone"]+'</td>';
           row_text +='<td>'+item["pay_number"]+'</td>';
           row_text +='<td>'+(item["type_id"]==1?'Prepaid Credit':'Credit Balance')+'</td>';
           row_text +='<td>'+item["payment_name"]+'</td>';
           row_text += '<td style="text-align: center;" class="dropdown">';
           row_text +='<a title="Sold" href="http://eprepaid.origgin.net/transactions/'+item["id"]+'/add_as_sale" class=""><i class="icon-check"></i></a>';
           row_text +='<a title="Refund" href="http://eprepaid.origgin.net/transactions/'+item["id"]+'/add_as_refund" class=""><i class="icon-retweet"></i></a>';
           row_text +='</td>';
           
           //create new row element
           var new_row = document.createElement("tr");
           new_row.setAttribute('data-id',item["id"]);
           
           new_row.innerHTML = row_text;
           
           table_body.insertBefore(new_row,first_row);
           
           

        }
        
    }
    
    
    function addRecentRequestsToList(data) {
        var row_text ='';
        var table_body = document.querySelector("#translist tbody");
        var first_row = table_body.children[0];
        
        for(var i = 0, len = data.length; i < len; i++){
            var item = data[i];
           row_text = '<td>'+item["created_at"]+'</td>';             
           row_text += '<td>'+item["request_id"]+'</td>';
           row_text += '<td>'+item["meter_code"]+'</td>';
           row_text +='<td>'+item["meter_owner"]+'</td>';
           row_text += '<td>'+item["amount"]+'</td>';
           row_text +='<td>'+(item["name"]=='-'?item["email"]:item["name"])+'</td>';
           row_text +='<td>'+item["phone"]+'</td>';
           row_text +='<td>'+item["location"]+'</td>';
           row_text +='<td>'+(item["type_id"]==1?'Prepaid Credit':'Credit Balance')+'</td>';
           
           
           //create new row element
           var new_row = document.createElement("tr");
           new_row.setAttribute('data-id',item["id"]);
           
           new_row.innerHTML = row_text;
           
           table_body.insertBefore(new_row,first_row);
           
           

        }
        
    }