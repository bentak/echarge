-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 06, 2018 at 03:55 PM
-- Server version: 5.6.39-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `origginprepaid`
--
CREATE DATABASE IF NOT EXISTS `origginprepaid` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `origginprepaid`;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL DEFAULT '1',
  `phone` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `phone_alt` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `user_type_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `customer_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_email_unique` (`email`),
  KEY `customers_user_type_id_index` (`user_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2170 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `type_id`, `phone`, `phone_alt`, `password`, `email`, `user_type_id`, `customer_token`, `deleted_at`, `created_at`, `updated_at`) VALUES
(2, 1, '0269441746', '', 'be0a5b32537267fbe546fb20eff6fc15', 'elisha23@origgin.net', 1, 'jAP4gsydeV674RBkguhceNoz3DkbikhATjAUjtvkTJ1IiF53oWc1QTD1I54tPfje', NULL, '2018-01-10 23:54:08', '2018-01-10 23:54:08'),
(3, 1, '0554889942', '', '215407c0ab85908a8a9229b3494445d5', 'ewudzieemmanuel@gmail.com', 1, 'KrsfAJm8oGicRl27xMFnbxHkYWlyzJsmZmprAOZIrMXtCWAAjCoPhntpC8Hb6LrW', NULL, '2018-01-10 23:55:12', '2018-01-10 23:55:12'),
(4, 1, '0244549366', '', '038c8d20f8a0c21aa131b766bcd22df4', 'kane@origgin.net', 1, 'vGiIMv8woHUTKivT8VZJZ1RMNsLW3Al1WwyREDlWICZW6X2itCQpYlttr0vyeuHe', NULL, '2018-03-07 19:11:29', '2018-03-07 19:11:29'),
(5, 1, '0244549366', '', '91f0c5ea836238f6f18639a1a005333c', 'origginlimited@gmail.com', 1, 'Sz9wulOLU8suQPpSCpCSwi2nWyBJK62n6YSEEiYNrDatEU68HGDATdecWvh6y3zi', NULL, '2018-03-07 19:15:11', '2018-03-07 19:15:11')
-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
CREATE TABLE IF NOT EXISTS `districts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `ecg_region_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:10',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `districts_ecg_region_id_index` (`ecg_region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ecg_regions`
--

DROP TABLE IF EXISTS `ecg_regions`;
CREATE TABLE IF NOT EXISTS `ecg_regions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `region_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:09',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ecg_regions_region_id_index` (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ecg_regions`
--

INSERT INTO `ecg_regions` (`id`, `name`, `description`, `region_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Accra', 'Greater Accra', 1, NULL, '2018-01-03 23:53:00', '2018-08-03 16:53:59');

-- --------------------------------------------------------

--
-- Table structure for table `ecg_statuses`
--

DROP TABLE IF EXISTS `ecg_statuses`;
CREATE TABLE IF NOT EXISTS `ecg_statuses` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:02',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enquiries`
--

DROP TABLE IF EXISTS `enquiries`;
CREATE TABLE IF NOT EXISTS `enquiries` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `meter_code` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(16) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'BALANCE ENQUIRY',
  `response` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `customer_token` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `is_confirmed` tinyint(1) NOT NULL,
  `confirmed_at` datetime NOT NULL,
  `confirmed_by_id` int(10) UNSIGNED NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:12',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `enquiries_confirmed_by_id_index` (`confirmed_by_id`)
) ENGINE=InnoDB AUTO_INCREMENT=405 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
CREATE TABLE IF NOT EXISTS `locations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `region_id` int(10) UNSIGNED NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `locations_region_id_index` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `momo_transations`
--

DROP TABLE IF EXISTS `momo_transations`;
CREATE TABLE IF NOT EXISTS `momo_transations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL,
  `charges` double NOT NULL,
  `ecg_amount` double NOT NULL,
  `origgin_charge` double NOT NULL,
  `amount_after_charges` double NOT NULL,
  `transaction_id` varchar(124) COLLATE utf8_unicode_ci NOT NULL,
  `response_code` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `client_refrence` varchar(124) COLLATE utf8_unicode_ci NOT NULL,
  `external_transaction_id` varchar(124) COLLATE utf8_unicode_ci NOT NULL,
  `requst_id` int(10) UNSIGNED NOT NULL,
  `is_sold` tinyint(1) NOT NULL,
  `sold_at` datetime NOT NULL,
  `is_refunded` tinyint(1) NOT NULL DEFAULT '0',
  `refunded_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:07',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `momo_transations_transaction_id_unique` (`transaction_id`),
  KEY `momo_transations_requst_id_index` (`requst_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55501 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

DROP TABLE IF EXISTS `regions`;
CREATE TABLE IF NOT EXISTS `regions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:01',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `requsts`
--

DROP TABLE IF EXISTS `requsts`;
CREATE TABLE IF NOT EXISTS `requsts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `request_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `meter_code` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `location` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `meter_owner` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `location_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `customer_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `is_confirmed` tinyint(1) NOT NULL,
  `confirmed_at` datetime NOT NULL,
  `is_rejected` tinyint(1) NOT NULL,
  `rejected_at` datetime NOT NULL,
  `is_paid` tinyint(1) NOT NULL,
  `paid_at` datetime NOT NULL,
  `is_sold` tinyint(1) NOT NULL,
  `sold_at` datetime NOT NULL,
  `sold_by_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `vendor_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2018-01-10 16:11:02',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `requsts_type_id_index` (`type_id`),
  KEY `requsts_location_id_index` (`location_id`),
  KEY `requsts_customer_id_index` (`customer_id`),
  KEY `requsts_sold_by_id_index` (`sold_by_id`),
  KEY `requsts_vendor_id_index` (`vendor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=64615 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `towns`
--

DROP TABLE IF EXISTS `towns`;
CREATE TABLE IF NOT EXISTS `towns` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `username` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `user_type_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `balance` double NOT NULL DEFAULT '0',
  `recustomer_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_user_type_id_index` (`user_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `type_id`, `username`, `password`, `email`, `user_type_id`, `balance`, `recustomer_token`, `deleted_at`, `created_at`, `updated_at`) VALUES
(2, 2, 'elisha', '$2y$10$.49xAlp.tFpxqd4loe8g6uro.E7NC.pgunLMIeTXFQqhnMEDdBERm', 'mailelikem@gmail.com', 2, 0, '', NULL, '2017-08-28 15:07:43', '2017-08-28 15:07:43'),
(3, 2, 'caleb', '$2y$10$a1djwpwqkBVXDDQGgtXNAe6Zug6HmGG5T71rhZ8TTFnsJYdJqdEG6', 'calebston@gmail.com', 3, 0, '', NULL, '2017-08-28 15:07:44', '2017-08-28 15:07:44'),
(5, 1, 'Kane', '$2y$10$ILVOthxd449scij22mjFmOvbOHSyuzfh73QE/6EEpdj8gCTjdGCWK', 'eprepaid@origgin.net', 1, 0, '', NULL, '2017-08-28 15:07:43', '2017-08-28 15:07:43');

-- --------------------------------------------------------

--
-- Table structure for table `user_types`
--

DROP TABLE IF EXISTS `user_types`;
CREATE TABLE IF NOT EXISTS `user_types` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2017-08-28 15:07:31',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

DROP TABLE IF EXISTS `vendors`;
CREATE TABLE IF NOT EXISTS `vendors` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ecg_region_id` int(11) NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `telephone_alt` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `balance` double NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '2017-08-28 15:07:37',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendors_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `ecg_region_id`, `name`, `address`, `telephone`, `telephone_alt`, `email`, `balance`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'East Legon Woman', 'American House, East Legon, Accra', '0502369854', '0244715689', 'vendor1@gmail.com', 0, NULL, '2017-08-28 15:07:47', '2017-08-28 15:07:47');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
